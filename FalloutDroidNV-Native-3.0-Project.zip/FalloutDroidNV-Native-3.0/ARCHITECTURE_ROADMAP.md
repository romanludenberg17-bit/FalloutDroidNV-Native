# Fallout Droid NV Native 3.0 — Technical Roadmap & Honest Status

## Architectural Lessons from NVForever (Clean-Room Reference)
Studied `https://github.com/LootJunkieAzza/NVForever` (clean-room Rust/Bevy engine):
- Layered subsystem isolation: Layer 0/1 (BSA v104 + ESM/ESP parsers & load order) -> Assets -> World/Rendering -> Unified Audio & UI.
- Unified audio routing across music, radio, ambient, dialogue, and SFX prevents the classic split-route bug where dialogue works while SFX/radio stay silent.
- Strict clean-room boundary: zero Bethesda assets bundled, zero Rust/Bevy code copied into C++/Unicorn.

## Stage 1 — Completed & Verified (This Delivery)
- Full C++17 NDK + CMake project (`libfnv3.so`, `arm64-v8a`, Android 10–17).
- **Audio Engine**: `AudioMixer` (48 kHz stereo float32, DirectSound8 + DirectSound3D + XAudio2 unified voice pool, linear resampler, constant-power 3D pan & rolloff, NaN sanitizer, soft limiter, live `AudioDiagnostics`) + `OboeAudioBackend` (`com.google.oboe:oboe:1.9.3` with auto-restart on audio route disconnect).
- **PC Touch Controller & Input Engine**: `InputEngine` (Win32 VK + DIK scancodes, ref-counted multitouch zero-stuck-keys, WASD dead zone, Game relative mouse vs Menu cursor) + standalone `PcTouchControllerView`, `TouchLayoutEditorScreen` (drag/resize/opacity/remap/JSON profiles per game), and `HardwareInputHandler` (Xbox/DualSense/DualShock/Keyboard).
- **Filesystem & PE32**: real BSA v104 reader with zlib decompression, `TES4` ESM/DLC validation, Win32 PE32 (x86) loader + IAT parser.
- **Unicorn 2.1.4 & Vulkan**: `UnicornCpuBackend` (x86-32 + IAT stub hook) and `VulkanRenderer` (instance/device/Android surface).
- **Material 3 Android UI**: 10 screens (`Home`, `Game Library`, `Game Settings`, `Graphics`, `Audio`, `Controls`, `Controller`, `Performance`, `Diagnostics`, `File Manager`).
- **CI/CD & Tests**: `.github/workflows/build-release.yml` + `tests/engine_tests.cpp` (compiled with `g++ -std=c++17 -Wall -Wextra -Werror` and passed 4/4 suites on host).

## Stages 2–4 — Remaining Work Required to Boot Full Retail Fallout: New Vegas
- **Stage 2 (Win32 & COM Coverage)**: Implement full `kernel32`, `user32`, `advapi32`, `ole32`, `dinput8` COM vtables, Win32 threading (`CreateThread`/TLS/TEB/PEB), and `DirectShow`/MP3/Vorbis streaming hooks required by `FalloutNV.exe`.
- **Stage 3 (Direct3D 9 -> Vulkan Backend)**: Implement `IDirect3D9` / `IDirect3DDevice9` COM vtable, HLSL SM3.0 -> SPIR-V shader translation, vertex/index buffers, DDS/BC1-BC3 texture upload, and swapchain present loop.
- **Stage 4 (On-Device Gameplay Verification)**: Build `FalloutDroidNV-Native-v3.0.0.apk` via GitHub Actions, install on Android `arm64-v8a`, and run live gameplay tests (combat, radio, Pip-Boy, dialogue, saves, Bluetooth controllers).
