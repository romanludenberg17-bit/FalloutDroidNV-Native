# Fallout Droid NV Native 3.0

Clean-slate Android NDK (C++17 + CMake + Unicorn Engine 2.1.4 + Google Oboe + Vulkan) and Jetpack Compose Material 3 architecture for porting *Fallout: New Vegas* (`arm64-v8a`, Android 10–17).

## Building the Release APK
1. Push this repository to GitHub.
2. GitHub Actions (`.github/workflows/build-release.yml`) automatically:
   - Runs the C++17 host unit test suite (`make -C tests test`).
   - Clones Unicorn Engine `2.1.4` into `third_party/unicorn`.
   - Builds `libfnv3.so` (`arm64-v8a`) with Android NDK r27, CMake 3.22.1, Google Oboe `1.9.3`, and Vulkan.
   - Aligns (`zipalign`), signs (`apksigner` v1+v2+v3), and outputs `FalloutDroidNV-Native-v3.0.0.apk` + `FalloutDroidNV-Native-v3.0.0.sha256`.

## Running Local C++17 Unit Tests
```bash
make -C tests test
```
