# Fallout Droid NV Native 3.0 — Stage 2 API & Diagnostics Report

## Implemented Win32 / COM / DirectX APIs (76 entries across 13 DLLs)
- **kernel32.dll**: `GetTickCount`, `QueryPerformanceCounter`, `QueryPerformanceFrequency`, `VirtualAlloc`, `VirtualFree`, `GetProcessHeap`, `HeapCreate`, `HeapAlloc`, `HeapReAlloc`, `HeapFree`, `TlsAlloc`, `TlsFree`, `TlsGetValue`, `TlsSetValue`, `InitializeCriticalSection`, `EnterCriticalSection`, `LeaveCriticalSection`, `DeleteCriticalSection`, `CreateEventA/W`, `SetEvent`, `ResetEvent`, `CreateMutexA/W`, `ReleaseMutex`, `WaitForSingleObject`, `CreateThread`, `GetCurrentThreadId`, `GetCurrentProcessId`, `Sleep`, `CloseHandle`, `GetLastError`, `SetLastError`, `CreateFileA`, `ReadFile`, `WriteFile`, `SetFilePointer`, `GetFileSize`, `GetFileAttributesA`, `GetEnvironmentVariableA`, `SetEnvironmentVariableA`, `GetModuleHandleA`, `LoadLibraryA`, `GetProcAddress`, `SetUnhandledExceptionFilter`.
- **user32.dll**: `GetAsyncKeyState`, `GetKeyState`, `GetCursorPos`, `ShowCursor`, `PeekMessageA`, `GetSystemMetrics`.
- **advapi32.dll**: `RegOpenKeyExA`, `RegCreateKeyExA`, `RegQueryValueExA`, `RegSetValueExA`, `RegCloseKey`.
- **ole32.dll / oleaut32.dll**: `CoInitializeEx`, `CoInitialize`, `CoUninitialize`, `CoCreateInstance`, `SysAllocString`, `SysFreeString`.
- **shell32.dll / ws2_32.dll / winmm.dll / version.dll / shlwapi.dll**: `SHGetFolderPathA`, `WSAStartup`, `WSACleanup`, `timeGetTime`, `timeBeginPeriod`, `timeEndPeriod`, `GetFileVersionInfoSizeA`, `GetFileVersionInfoA`, `PathFileExistsA`.
- **dinput8.dll**: `DirectInput8Create`, `IDirectInput8::CreateDevice`, `IDirectInputDevice8::SetDataFormat/SetCooperativeLevel/Acquire/Unacquire/GetDeviceState/GetDeviceData` (wired to Stage 1 `InputEngine`).
- **dsound.dll**: `DirectSoundCreate8`, `IDirectSound8`, `IDirectSoundBuffer8` (`Lock/Unlock/Play/Stop/SetVolume/SetPan/SetFrequency/GetCurrentPosition/SetCurrentPosition/GetStatus`), `IDirectSound3DBuffer8`, `IDirectSound3DListener8`, `IDirectSoundNotify` (wired to Stage 1 `AudioMixer`).
- **xaudio2_7.dll**: `XAudio2Create`, `IXAudio2`, `IXAudio2SourceVoice` (wired to Stage 1 `AudioMixer`).

## Remaining Missing APIs (Scheduled for Stage 3)
- **d3d9.dll**: `Direct3DCreate9`, `IDirect3D9`, `IDirect3DDevice9` -> Vulkan translation pipeline.
- **quartz.dll / ole32 DirectShow**: `IGraphBuilder`, `IMediaControl`, `IBasicAudio` -> Android `AMediaExtractor`/`AMediaCodec` bridge for full MP3/OGG/XWMA streaming.
- **binkw32.dll**: Bink video playback/skip shims.
- **steam_api.dll**: Offline SteamAPI compatibility layer.
- **Full Win32 WndProc / GDI32 / wide-char (`*W`) file & registry variants** as discovered when validating against a real retail `FalloutNV.exe` IAT.
