cmake_minimum_required(VERSION 3.22.1)
project(falloutdroid_nv3 LANGUAGES C CXX)

set(CMAKE_CXX_STANDARD 17)
set(CMAKE_CXX_STANDARD_REQUIRED ON)

find_package(oboe REQUIRED CONFIG)

set(UNICORN_ARCH "x86" CACHE STRING "" FORCE)
set(UNICORN_BUILD_TESTS OFF CACHE BOOL "" FORCE)
set(UNICORN_INSTALL OFF CACHE BOOL "" FORCE)
set(UNICORN_BUILD_SHARED OFF CACHE BOOL "" FORCE)
set(BUILD_SHARED_LIBS OFF CACHE BOOL "" FORCE)
add_subdirectory(${CMAKE_CURRENT_SOURCE_DIR}/../../../../third_party/unicorn unicorn_build)

add_library(fnv3 SHARED
    src/audio_mixer.cpp
    src/audio_decoder.cpp
    src/oboe_backend.cpp
    src/input_engine.cpp
    src/bsa_reader.cpp
    src/pe_loader.cpp
    src/com_runtime.cpp
    src/dinput8_compat.cpp
    src/dsound_compat.cpp
    src/win32_compat.cpp
    src/unicorn_cpu.cpp
    src/vulkan_renderer.cpp
    src/engine_core.cpp
    src/jni_bridge.cpp
)

target_include_directories(fnv3 PRIVATE
    ${CMAKE_CURRENT_SOURCE_DIR}/include
    ${CMAKE_CURRENT_SOURCE_DIR}/../../../../third_party/unicorn/include
)

target_link_libraries(fnv3
    unicorn
    oboe::oboe
    vulkan
    mediandk
    android
    log
    z
)

target_link_options(fnv3 PRIVATE "-Wl,-z,max-page-size=16384")
