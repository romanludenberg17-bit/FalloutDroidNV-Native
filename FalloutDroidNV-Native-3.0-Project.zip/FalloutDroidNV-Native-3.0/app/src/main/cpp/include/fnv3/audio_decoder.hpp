#pragma once
#include "fnv3/audio_mixer.hpp"
#include <cstdint>
#include <string>
#include <vector>

namespace fnv3::audio {

enum class AudioFormatKind : uint8_t {
    Unknown = 0,
    WavPcm,
    Mp3,
    OggVorbis,
    Xwma
};

struct DecodedAudio {
    AudioFormatKind format = AudioFormatKind::Unknown;
    uint32_t sampleRate = 44100;
    uint16_t channels = 1;
    uint16_t bitsPerSample = 16;
    std::vector<uint8_t> pcmBytes;
};

class AudioDecoder {
public:
    static AudioFormatKind detectFormat(const std::vector<uint8_t>& data);
    static bool decodeWavPcm(const std::vector<uint8_t>& data, DecodedAudio& out, std::string& outError);
    static bool probeCompressedHeader(const std::vector<uint8_t>& data, DecodedAudio& outMeta, std::string& outError);
    static bool decodeToPcm(const std::vector<uint8_t>& data, DecodedAudio& out, std::string& outError);
};

class AudioStreamPlayer {
public:
    explicit AudioStreamPlayer(AudioMixer& mixer);

    uint32_t openStream(const DecodedAudio& audio, AudioCategory category, bool loop);
    bool feedNextChunk(uint32_t handle, size_t maxBytes);
    bool isFinished(uint32_t handle) const;

private:
    struct StreamState {
        uint32_t voiceHandle = 0;
        std::vector<uint8_t> sourcePcm;
        size_t cursorBytes = 0;
        bool loop = false;
    };
    AudioMixer& mMixer;
    std::vector<StreamState> mStreams;
};

} // namespace fnv3::audio
