#pragma once
#include <array>
#include <atomic>
#include <cstdint>
#include <mutex>
#include <string>
#include <vector>

namespace fnv3::audio {

enum class AudioCategory : uint8_t {
    UI = 0,
    WeaponFire,
    Reload,
    Footsteps,
    Ambient,
    Music,
    Radio,
    PipBoy,
    Dialogue,
    NpcSfx,
    Spatial3D,
    Count
};

struct Vec3 {
    float x = 0.0f;
    float y = 0.0f;
    float z = 0.0f;
};

struct Listener3D {
    Vec3 position{0.0f, 0.0f, 0.0f};
    Vec3 front{0.0f, 0.0f, 1.0f};
    Vec3 top{0.0f, 1.0f, 0.0f};
    float distanceFactor = 1.0f;
    float rolloffFactor = 1.0f;
};

struct Source3DParams {
    bool enabled = false;
    bool headRelative = false;
    Vec3 position{0.0f, 0.0f, 0.0f};
    float minDistance = 1.0f;
    float maxDistance = 100.0f;
};

struct AudioDiagnostics {
    uint32_t sampleRate = 48000;
    uint32_t activeChannels = 0;
    uint32_t activeSources = 0;
    uint64_t totalPcmFrames = 0;
    uint32_t underrunCount = 0;
    uint32_t nanSanitizedCount = 0;
    float peakLevel = 0.0f;
    float rmsLevel = 0.0f;
    bool mixerRunning = false;
    bool oboeConnected = false;
    std::string backendState = "UNINITIALIZED";
    std::string lastError;
    std::array<uint32_t, static_cast<size_t>(AudioCategory::Count)> categoryCounts{};
};

// DirectSound8 / XAudio2 unified voice descriptor
struct Voice {
    uint32_t handle = 0;
    bool allocated = false;
    bool playing = false;
    bool looping = false;
    bool streaming = false;
    AudioCategory category = AudioCategory::UI;

    uint32_t srcSampleRate = 44100;
    uint16_t srcChannels = 1;
    uint16_t srcBitsPerSample = 16; // 8, 16, or 32 (float)

    // Interleaved PCM storage (either static buffer or ring/stream queue)
    std::vector<float> pcmSamples; // normalized stereo or mono float32
    double playCursorFrames = 0.0;

    // DirectSound8 compatible controls
    int32_t dsVolumeMb = 0;        // -10000 .. 0 millibels
    int32_t dsPanMb = 0;           // -10000 .. +10000
    float linearVolume = 1.0f;     // XAudio2 / category multiplier
    float frequencyRatio = 1.0f;
    Source3DParams spatial{};
};

class AudioMixer {
public:
    static constexpr uint32_t kMaxVoices = 256;
    static constexpr uint32_t kDefaultSampleRate = 48000;

    explicit AudioMixer(uint32_t outputSampleRate = kDefaultSampleRate);

    // Master & category volumes [0.0f .. 1.0f]
    void setMasterVolume(float vol);
    void setCategoryVolume(AudioCategory cat, float vol);
    float getCategoryVolume(AudioCategory cat) const;

    // DirectSound8 / DirectSoundBuffer8 compatible API
    uint32_t createBuffer(uint32_t sampleRate, uint16_t channels, uint16_t bitsPerSample,
                          AudioCategory category, bool is3D = false);
    uint32_t duplicateBuffer(uint32_t srcHandle);
    bool uploadPcm(uint32_t handle, const void* data, size_t byteLength, bool appendStream = false);
    bool play(uint32_t handle, bool loop);
    bool stop(uint32_t handle);
    bool release(uint32_t handle);
    bool setVolumeMillibels(uint32_t handle, int32_t millibels);
    bool setPanMillibels(uint32_t handle, int32_t panMb);
    bool setFrequency(uint32_t handle, uint32_t newSampleRate);
    uint32_t getStatus(uint32_t handle) const; // 0=stopped, 1=playing, 5=playing|looping
    uint32_t getCurrentPositionBytes(uint32_t handle) const;
    bool setCurrentPositionBytes(uint32_t handle, uint32_t bytePos);

    // DirectSound3D compatible API
    bool set3DPosition(uint32_t handle, float x, float y, float z);
    bool set3DDistances(uint32_t handle, float minDist, float maxDist);
    bool set3DMode(uint32_t handle, bool enabled, bool headRelative);
    void setListener3D(const Listener3D& listener);

    // XAudio2 compatible API
    uint32_t xa2CreateSourceVoice(uint32_t sampleRate, uint16_t channels, uint16_t bitsPerSample, AudioCategory category);
    bool xa2SubmitSourceBuffer(uint32_t handle, const void* data, size_t byteLength);
    bool xa2SetVolume(uint32_t handle, float gain);
    bool xa2SetFrequencyRatio(uint32_t handle, float ratio);

    // Real-time stereo float32 mixing callback (called by Oboe or unit tests)
    void mixFrames(float* outInterleavedStereo, uint32_t numFrames);

    // Backend status updates & diagnostics snapshot
    void setBackendStatus(bool running, bool oboeConnected, const std::string& state, const std::string& err = "");
    void recordUnderrun();
    AudioDiagnostics getDiagnostics() const;

    static float millibelsToGain(int32_t mb);

private:
    void computeStereoGains(const Voice& v, float& outL, float& outR) const;

    uint32_t mSampleRate;
    mutable std::mutex mMutex;
    std::array<Voice, kMaxVoices> mVoices{};
    uint32_t mNextHandle = 1;
    Listener3D mListener{};
    float mMasterVolume = 1.0f;
    std::array<float, static_cast<size_t>(AudioCategory::Count)> mCategoryVolumes{};

    // Telemetry
    uint64_t mTotalFrames = 0;
    uint32_t mUnderruns = 0;
    uint32_t mNanSanitized = 0;
    float mLastPeak = 0.0f;
    float mLastRms = 0.0f;
    bool mMixerRunning = false;
    bool mOboeConnected = false;
    std::string mBackendState = "STOPPED";
    std::string mLastError;
};

} // namespace fnv3::audio
