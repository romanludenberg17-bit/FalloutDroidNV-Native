#pragma once
#include <cstdint>
#include <string>
#include <unordered_map>
#include <vector>

namespace fnv3::fs {

struct BsaFileEntry {
    std::string fullPath; // normalized lowercase with '/'
    uint32_t offset = 0;
    uint32_t rawSize = 0;
    bool compressed = false;
};

class BsaArchive {
public:
    bool open(const std::string& filePath, std::string& outError);
    bool contains(const std::string& normalizedPath) const;
    bool extract(const std::string& normalizedPath, std::vector<uint8_t>& outData, std::string& outError) const;
    size_t fileCount() const { return mEntries.size(); }
    uint32_t version() const { return mVersion; }

    static std::string normalizePath(const std::string& p);

private:
    std::string mArchivePath;
    uint32_t mVersion = 0;
    uint32_t mArchiveFlags = 0;
    std::unordered_map<std::string, BsaFileEntry> mEntries;
};

struct GameDataReport {
    bool hasExecutable = false;
    bool hasFalloutNvEsm = false;
    bool hasSoundBsa = false;
    bool hasVoicesBsa = false;
    uint32_t bsaCount = 0;
    uint32_t dlcCount = 0;
    std::vector<std::string> foundDlcs;
    std::vector<std::string> missingRequired;
};

class GameFilesystem {
public:
    bool mountDataDir(const std::string& gameRootDir, GameDataReport& outReport);
    bool readVirtualFile(const std::string& gameRelPath, std::vector<uint8_t>& outData) const;
    size_t mountedBsaCount() const { return mArchives.size(); }

    static bool validateEsmHeader(const std::string& esmPath);

private:
    std::string mGameRoot;
    std::string mDataDir;
    std::vector<BsaArchive> mArchives;
};

} // namespace fnv3::fs
