#pragma once
#include <array>
#include <atomic>
#include <cstdint>
#include <cstring>
#include <memory>
#include <string>
#include <unordered_map>
#include <vector>

namespace fnv3::com {

using HRESULT = int32_t;
constexpr HRESULT S_OK_HR              = 0x00000000;
constexpr HRESULT E_NOTIMPL_HR         = static_cast<HRESULT>(0x80004001u);
constexpr HRESULT E_NOINTERFACE_HR     = static_cast<HRESULT>(0x80004002u);
constexpr HRESULT E_POINTER_HR         = static_cast<HRESULT>(0x80004003u);
constexpr HRESULT E_FAIL_HR            = static_cast<HRESULT>(0x80004005u);
constexpr HRESULT E_INVALIDARG_HR      = static_cast<HRESULT>(0x80070057u);
constexpr HRESULT CLASS_E_NO_CLASS_HR  = static_cast<HRESULT>(0x80040111u);

struct Guid {
    uint32_t data1;
    uint16_t data2;
    uint16_t data3;
    std::array<uint8_t, 8> data4;

    bool operator==(const Guid& o) const {
        return data1 == o.data1 && data2 == o.data2 && data3 == o.data3 && data4 == o.data4;
    }
};

// Canonical Win32 / DirectX COM IIDs
constexpr Guid IID_IUnknown               = {0x00000000, 0x0000, 0x0000, {0xC0,0x00,0x00,0x00,0x00,0x00,0x00,0x46}};
constexpr Guid IID_IDirectInput8A         = {0xBF798030, 0x483A, 0x4DA2, {0xAA,0x99,0x5D,0x64,0xED,0x36,0x97,0x00}};
constexpr Guid IID_IDirectInputDevice8A   = {0x54D41080, 0xDC15, 0x4833, {0xA4,0x1B,0x74,0x8F,0x73,0xA3,0x81,0x79}};
constexpr Guid GUID_SysKeyboard           = {0x6F1D2B61, 0xD5A0, 0x11CF, {0xBF,0xC7,0x44,0x45,0x53,0x54,0x00,0x00}};
constexpr Guid GUID_SysMouse              = {0x6F1D2B60, 0xD5A0, 0x11CF, {0xBF,0xC7,0x44,0x45,0x53,0x54,0x00,0x00}};
constexpr Guid IID_IDirectSound8          = {0xC50A7E93, 0xF395, 0x4834, {0x9E,0xF6,0x7F,0xA9,0x9D,0xE5,0x09,0x66}};
constexpr Guid IID_IDirectSoundBuffer8    = {0x6825A449, 0x7524, 0x4D82, {0x92,0x0F,0x50,0xE3,0x6A,0xB3,0xAB,0x1E}};
constexpr Guid IID_IDirectSound3DBuffer8  = {0x279AFA86, 0x4981, 0x11CE, {0xA5,0x21,0x00,0x20,0xAF,0x0B,0xE5,0x60}};
constexpr Guid IID_IDirectSound3DListener8= {0x279AFA84, 0x4981, 0x11CE, {0xA5,0x21,0x00,0x20,0xAF,0x0B,0xE5,0x60}};
constexpr Guid IID_IDirectSoundNotify     = {0xB0210783, 0x89CD, 0x11D0, {0xAF,0x08,0x00,0xA0,0xC9,0x25,0xCD,0x16}};
constexpr Guid IID_IXAudio2               = {0x8BCF1F58, 0x9FE7, 0x4583, {0x8A,0xC6,0xE2,0xAD,0xC4,0x65,0xC8,0xBB}};

class ComObject {
public:
    virtual ~ComObject() = default;

    virtual HRESULT queryInterface(const Guid& riid, ComObject** outObj) {
        if (!outObj) return E_POINTER_HR;
        if (riid == IID_IUnknown) {
            addRef();
            *outObj = this;
            return S_OK_HR;
        }
        *outObj = nullptr;
        return E_NOINTERFACE_HR;
    }

    uint32_t addRef() { return ++mRefCount; }
    uint32_t release() {
        uint32_t r = --mRefCount;
        if (r == 0) delete this;
        return r;
    }
    uint32_t refCount() const { return mRefCount.load(); }

    uint32_t guestAddress = 0;
    uint32_t guestVtblAddress = 0;

protected:
    std::atomic<uint32_t> mRefCount{1};
};

class ComRegistry {
public:
    uint32_t registerObject(ComObject* obj, uint32_t vtblSlotCount);
    ComObject* lookup(uint32_t guestAddr) const;
    void unregisterObject(uint32_t guestAddr);
    size_t liveObjectCount() const { return mObjects.size(); }

    static constexpr uint32_t kComObjBase = 0x7E000000u;

private:
    uint32_t mNextAddr = kComObjBase;
    std::unordered_map<uint32_t, ComObject*> mObjects;
};

} // namespace fnv3::com
