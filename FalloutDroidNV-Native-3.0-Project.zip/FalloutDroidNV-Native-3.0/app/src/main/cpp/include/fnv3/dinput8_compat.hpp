#pragma once
#include "fnv3/com_runtime.hpp"
#include "fnv3/input_engine.hpp"
#include <cstdint>
#include <vector>

namespace fnv3::dinput {

enum class DeviceKind : uint8_t { Keyboard, Mouse, Gamepad };

struct DiMouseState2 {
    int32_t lX = 0;
    int32_t lY = 0;
    int32_t lZ = 0;
    uint8_t rgbButtons[8]{};
};

struct DiDeviceObjectData {
    uint32_t dwOfs = 0;
    uint32_t dwData = 0;
    uint32_t dwTimeStamp = 0;
    uint32_t dwSequence = 0;
    uint32_t uAppData = 0;
};

class DirectInputDevice8 : public com::ComObject {
public:
    DirectInputDevice8(input::InputEngine& engine, DeviceKind kind);

    com::HRESULT queryInterface(const com::Guid& riid, com::ComObject** outObj) override;
    com::HRESULT setDataFormat(uint32_t formatId);
    com::HRESULT setCooperativeLevel(uint32_t hwnd, uint32_t flags);
    com::HRESULT acquire();
    com::HRESULT unacquire();
    com::HRESULT getDeviceState(uint32_t cbData, void* lpvData);
    com::HRESULT getDeviceData(uint32_t cbObjectData, DiDeviceObjectData* rgdod, uint32_t* inOutCount);

    bool isAcquired() const { return mAcquired; }
    DeviceKind kind() const { return mKind; }

private:
    input::InputEngine& mInput;
    DeviceKind mKind;
    bool mAcquired = false;
    uint32_t mCoopFlags = 0;
    uint32_t mSeqCounter = 1;
};

class DirectInput8 : public com::ComObject {
public:
    explicit DirectInput8(input::InputEngine& engine, com::ComRegistry& comReg);

    com::HRESULT queryInterface(const com::Guid& riid, com::ComObject** outObj) override;
    com::HRESULT createDevice(const com::Guid& rguid, DirectInputDevice8** outDev);

private:
    input::InputEngine& mInput;
    com::ComRegistry& mComReg;
};

} // namespace fnv3::dinput
