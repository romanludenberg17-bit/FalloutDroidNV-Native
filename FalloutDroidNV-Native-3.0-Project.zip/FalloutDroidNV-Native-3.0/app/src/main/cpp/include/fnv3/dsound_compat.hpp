#pragma once
#include "fnv3/audio_mixer.hpp"
#include "fnv3/com_runtime.hpp"
#include <cstdint>
#include <functional>
#include <vector>

namespace fnv3::dsound {

struct DsNotifyPosition {
    uint32_t offsetBytes = 0; // 0xFFFFFFFF = DSBPN_OFFSETSTOP
    uint32_t eventHandle = 0;
};

using SignalEventFn = std::function<void(uint32_t eventHandle)>;

class DirectSoundBuffer8 : public com::ComObject {
public:
    DirectSoundBuffer8(audio::AudioMixer& mixer, uint32_t voiceHandle, uint32_t bufferBytes,
                       uint32_t sampleRate, uint16_t channels, uint16_t bitsPerSample, bool is3D,
                       SignalEventFn signalEvent);

    com::HRESULT queryInterface(const com::Guid& riid, com::ComObject** outObj) override;

    // IDirectSoundBuffer8
    com::HRESULT lock(uint32_t offset, uint32_t bytes, uint8_t** outPtr1, uint32_t* outLen1,
                      uint8_t** outPtr2, uint32_t* outLen2);
    com::HRESULT unlock(const void* ptr1, uint32_t len1, const void* ptr2, uint32_t len2);
    com::HRESULT play(uint32_t flags);
    com::HRESULT stop();
    com::HRESULT setVolume(int32_t millibels);
    com::HRESULT setPan(int32_t panMb);
    com::HRESULT setFrequency(uint32_t hz);
    com::HRESULT getCurrentPosition(uint32_t* playCursor, uint32_t* writeCursor) const;
    com::HRESULT setCurrentPosition(uint32_t bytePos);
    com::HRESULT getStatus(uint32_t* outStatus) const;

    // IDirectSound3DBuffer8
    com::HRESULT set3DPosition(float x, float y, float z);
    com::HRESULT set3DMinDistance(float minDist);
    com::HRESULT set3DMaxDistance(float maxDist);
    com::HRESULT set3DMode(uint32_t mode); // 0=NORMAL, 1=HEADRELATIVE, 2=DISABLE

    // IDirectSound3DListener8
    com::HRESULT setListenerPosition(float x, float y, float z);
    com::HRESULT setListenerOrientation(float fx, float fy, float fz, float tx, float ty, float tz);

    // IDirectSoundNotify
    com::HRESULT setNotificationPositions(const std::vector<DsNotifyPosition>& positions);
    void pollNotifications();

    uint32_t voiceHandle() const { return mVoiceHandle; }
    uint32_t bufferBytes() const { return static_cast<uint32_t>(mStagingBuffer.size()); }

private:
    audio::AudioMixer& mMixer;
    uint32_t mVoiceHandle = 0;
    uint32_t mSampleRate = 44100;
    uint16_t mChannels = 1;
    uint16_t mBitsPerSample = 16;
    bool mIs3D = false;
    float mMinDist = 1.0f;
    float mMaxDist = 100.0f;
    audio::Listener3D mListener{};
    std::vector<uint8_t> mStagingBuffer;
    std::vector<DsNotifyPosition> mNotifies;
    std::vector<bool> mNotifyFired;
    SignalEventFn mSignalEvent;
};

class DirectSound8 : public com::ComObject {
public:
    DirectSound8(audio::AudioMixer& mixer, com::ComRegistry& comReg, SignalEventFn signalEvent);

    com::HRESULT queryInterface(const com::Guid& riid, com::ComObject** outObj) override;
    com::HRESULT createSoundBuffer(uint32_t bufferBytes, uint32_t sampleRate, uint16_t channels,
                                   uint16_t bitsPerSample, audio::AudioCategory cat, bool is3D,
                                   DirectSoundBuffer8** outBuf);
    com::HRESULT duplicateSoundBuffer(DirectSoundBuffer8* src, DirectSoundBuffer8** outBuf);
    com::HRESULT setCooperativeLevel(uint32_t hwnd, uint32_t level);

private:
    audio::AudioMixer& mMixer;
    com::ComRegistry& mComReg;
    SignalEventFn mSignalEvent;
};

class XAudio2SourceVoice : public com::ComObject {
public:
    XAudio2SourceVoice(audio::AudioMixer& mixer, uint32_t voiceHandle);
    com::HRESULT submitSourceBuffer(const void* pcmData, size_t byteLength);
    com::HRESULT start();
    com::HRESULT stop();
    com::HRESULT setVolume(float gain);
    com::HRESULT setFrequencyRatio(float ratio);
    uint32_t voiceHandle() const { return mVoiceHandle; }
private:
    audio::AudioMixer& mMixer;
    uint32_t mVoiceHandle = 0;
};

class XAudio2Engine : public com::ComObject {
public:
    XAudio2Engine(audio::AudioMixer& mixer, com::ComRegistry& comReg);
    com::HRESULT queryInterface(const com::Guid& riid, com::ComObject** outObj) override;
    com::HRESULT createSourceVoice(uint32_t sampleRate, uint16_t channels, uint16_t bitsPerSample,
                                   audio::AudioCategory cat, XAudio2SourceVoice** outVoice);
private:
    audio::AudioMixer& mMixer;
    com::ComRegistry& mComReg;
};

} // namespace fnv3::dsound
