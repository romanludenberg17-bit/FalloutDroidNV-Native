#pragma once
#include "fnv3/audio_mixer.hpp"
#include "fnv3/bsa_reader.hpp"
#include "fnv3/input_engine.hpp"
#include "fnv3/oboe_backend.hpp"
#include "fnv3/pe_loader.hpp"
#include "fnv3/unicorn_cpu.hpp"
#include "fnv3/vulkan_renderer.hpp"
#include "fnv3/win32_compat.hpp"
#include <memory>
#include <string>

namespace fnv3 {

class NativeEngineCore {
public:
    NativeEngineCore();
    ~NativeEngineCore();

    bool initializeAudio();
    bool mountGameDirectory(const std::string& gameRoot, fs::GameDataReport& outReport);
    bool prepareCpuAndLoadExe(const std::string& exePath, std::string& outError);
    void runAudioSelfTestTone(audio::AudioCategory category, float freqHz, uint32_t durationMs);

    audio::AudioMixer& mixer() { return mMixer; }
    input::InputEngine& input() { return mInput; }
    fs::GameFilesystem& filesystem() { return mFs; }
    gfx::VulkanRenderer& renderer() { return mRenderer; }
    cpu::UnicornCpuBackend& cpu() { return mCpu; }

private:
    audio::AudioMixer mMixer;
    audio::OboeAudioBackend mOboe;
    input::InputEngine mInput;
    fs::GameFilesystem mFs;
    win32::Win32CompatLayer mWin32;
    cpu::UnicornCpuBackend mCpu;
    gfx::VulkanRenderer mRenderer;
};

} // namespace fnv3
