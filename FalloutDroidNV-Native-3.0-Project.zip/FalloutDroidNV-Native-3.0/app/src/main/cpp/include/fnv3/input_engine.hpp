#pragma once
#include <array>
#include <cstdint>
#include <deque>
#include <mutex>

namespace fnv3::input {

// Standard Win32 Virtual-Key codes used by Fallout: New Vegas PC
namespace VK {
constexpr uint16_t LBUTTON = 0x01;
constexpr uint16_t RBUTTON = 0x02;
constexpr uint16_t MBUTTON = 0x04;
constexpr uint16_t TAB     = 0x09;
constexpr uint16_t RETURN  = 0x0D;
constexpr uint16_t SHIFT   = 0x10;
constexpr uint16_t CONTROL = 0x11;
constexpr uint16_t ESCAPE  = 0x1B;
constexpr uint16_t SPACE   = 0x20;
constexpr uint16_t KEY_1   = 0x31;
constexpr uint16_t KEY_9   = 0x39;
constexpr uint16_t KEY_A   = 0x41;
constexpr uint16_t KEY_D   = 0x44;
constexpr uint16_t KEY_E   = 0x45;
constexpr uint16_t KEY_F   = 0x46;
constexpr uint16_t KEY_Q   = 0x51;
constexpr uint16_t KEY_R   = 0x52;
constexpr uint16_t KEY_S   = 0x53;
constexpr uint16_t KEY_T   = 0x54;
constexpr uint16_t KEY_V   = 0x56;
constexpr uint16_t KEY_W   = 0x57;
constexpr uint16_t F5      = 0x74;
constexpr uint16_t F9      = 0x78;
} // namespace VK

enum class InputMode : uint8_t {
    Gameplay = 0, // Relative mouse camera, cursor captured
    Menu     = 1  // Absolute cursor in Pip-Boy / Pause / Dialogue, camera frozen
};

enum class EventType : uint8_t {
    KeyDown,
    KeyUp,
    MouseMoveRel,
    MouseMoveAbs,
    MouseButtonDown,
    MouseButtonUp,
    MouseWheel
};

struct InputEvent {
    EventType type = EventType::KeyDown;
    uint16_t vkCode = 0;
    uint8_t dikCode = 0;
    float dx = 0.0f;
    float dy = 0.0f;
    float absX = 0.0f;
    float absY = 0.0f;
    int32_t wheelDelta = 0;
};

struct MouseState {
    float relAccumX = 0.0f;
    float relAccumY = 0.0f;
    float cursorX = 0.5f; // normalized [0..1]
    float cursorY = 0.5f;
    int32_t wheelAccum = 0;
    uint8_t buttonsMask = 0; // bit0=LMB, bit1=RMB, bit2=MMB
};

class InputEngine {
public:
    InputEngine();

    // Mode switch (Gameplay <-> Menu)
    void setMode(InputMode mode);
    InputMode getMode() const;

    // Sensitivity & axis inversion
    void setMouseConfig(float sensitivity, bool invertX, bool invertY);

    // Virtual PC keyboard (ref-counted per VK to guarantee ZERO stuck keys with multitouch!)
    void setKeyState(uint16_t vkCode, bool pressed);
    bool isKeyDown(uint16_t vkCode) const;

    // Left analog stick -> WASD with configurable dead zone
    void setWasdStick(float normX, float normY, float deadZone = 0.18f);

    // Right virtual touchpad -> relative mouse (Gameplay) or cursor (Menu)
    void onTouchpadDelta(float rawDx, float rawDy);
    void onCursorAbsolute(float normX, float normY);
    void setMouseButton(uint8_t buttonIndex, bool pressed); // 0=LMB, 1=RMB, 2=MMB
    void onMouseWheel(int32_t delta);

    // Emergency release all (called on focus loss / mode switch / pause)
    void releaseAllKeys();

    // DirectInput8 / Win32 consumption
    std::array<uint8_t, 256> snapshotDirectInputKeys() const;
    MouseState consumeMouseState();
    bool popEvent(InputEvent& outEvent);

    static uint8_t vkToDik(uint16_t vkCode);

private:
    void pushEventLocked(const InputEvent& ev);
    void setStickKeyLocked(uint16_t vkCode, bool wantDown, bool& prevFlag);

    mutable std::mutex mMutex;
    InputMode mMode = InputMode::Gameplay;
    float mSensitivity = 1.0f;
    bool mInvertX = false;
    bool mInvertY = false;

    std::array<uint8_t, 256> mKeyRefCount{};
    bool mStickW = false, mStickA = false, mStickS = false, mStickD = false;

    MouseState mMouse{};
    std::deque<InputEvent> mQueue;
};

} // namespace fnv3::input
