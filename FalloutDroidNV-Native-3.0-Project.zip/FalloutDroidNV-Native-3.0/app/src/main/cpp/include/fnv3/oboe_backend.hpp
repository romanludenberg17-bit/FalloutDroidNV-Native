#pragma once
#include "fnv3/audio_mixer.hpp"
#include <memory>
#include <string>

#if defined(__ANDROID__) && !defined(FNV_HOST_TEST)
#include <oboe/Oboe.h>
#endif

namespace fnv3::audio {

class OboeAudioBackend
#if defined(__ANDROID__) && !defined(FNV_HOST_TEST)
    : public oboe::AudioStreamDataCallback,
      public oboe::AudioStreamErrorCallback
#endif
{
public:
    explicit OboeAudioBackend(AudioMixer& mixer);
    ~OboeAudioBackend();

    bool start();
    void stop();
    bool isRunning() const { return mRunning; }
    uint32_t actualSampleRate() const { return mActualSampleRate; }

#if defined(__ANDROID__) && !defined(FNV_HOST_TEST)
    oboe::DataCallbackResult onAudioReady(oboe::AudioStream* audioStream,
                                          void* audioData,
                                          int32_t numFrames) override;
    void onErrorAfterClose(oboe::AudioStream* audioStream, oboe::Result error) override;
#endif

private:
    AudioMixer& mMixer;
    bool mRunning = false;
    uint32_t mActualSampleRate = 48000;
#if defined(__ANDROID__) && !defined(FNV_HOST_TEST)
    std::shared_ptr<oboe::AudioStream> mStream;
#endif
};

} // namespace fnv3::audio
