#pragma once
#include <cstdint>
#include <string>
#include <vector>

namespace fnv3::core {

struct PeSection {
    std::string name;
    uint32_t virtualAddress = 0;
    uint32_t virtualSize = 0;
    uint32_t rawOffset = 0;
    uint32_t rawSize = 0;
    uint32_t characteristics = 0;
};

struct PeImport {
    std::string dllName;
    std::string funcName;
    bool byOrdinal = false;
    uint16_t ordinal = 0;
    uint32_t iatRva = 0;
};

struct PeExport {
    std::string name;
    uint16_t ordinal = 0;
    uint32_t rva = 0;
    bool isForwarded = false;
    std::string forwardTarget; // e.g. "NTDLL.RtlAllocateHeap"
};

struct PeRelocation {
    uint32_t rva = 0;
    uint8_t type = 0; // 0=ABSOLUTE, 3=HIGHLOW (32-bit)
};

struct PeImage {
    uint32_t imageBase = 0;
    uint32_t entryPointRva = 0;
    uint32_t sizeOfImage = 0;
    uint32_t sizeOfHeaders = 0;
    std::vector<PeSection> sections;
    std::vector<PeImport> imports;
    std::vector<PeExport> exports;
    std::vector<PeRelocation> relocations;
    std::vector<std::string> dependencies;
    std::vector<uint8_t> rawBytes;
};

struct ImportValidationReport {
    size_t totalImports = 0;
    size_t resolvedImports = 0;
    std::vector<std::string> missingImports;
};

class PeLoader {
public:
    static bool parseFile(const std::string& path, PeImage& outImage, std::string& outError);
    static bool parseBuffer(const std::vector<uint8_t>& data, PeImage& outImage, std::string& outError);
    static uint32_t rvaToFileOffset(const PeImage& img, uint32_t rva);
    static bool applyRelocations(const PeImage& img, uint32_t loadedBase, std::vector<uint8_t>& mappedImage);
    static const PeExport* findExportByName(const PeImage& img, const std::string& name);
    static const PeExport* findExportByOrdinal(const PeImage& img, uint16_t ordinal);
};

} // namespace fnv3::core
