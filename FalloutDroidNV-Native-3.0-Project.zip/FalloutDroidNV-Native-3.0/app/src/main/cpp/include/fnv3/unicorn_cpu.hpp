#pragma once
#include "fnv3/pe_loader.hpp"
#include "fnv3/win32_compat.hpp"
#include <cstdint>
#include <string>

#if !defined(FNV_HOST_TEST)
#include <unicorn/unicorn.h>
#endif

namespace fnv3::cpu {

class UnicornCpuBackend {
public:
    explicit UnicornCpuBackend(win32::Win32CompatLayer& win32);
    ~UnicornCpuBackend();

    bool initialize(std::string& outError);
    bool loadPeImage(const core::PeImage& image, std::string& outError);
    bool stepInstructions(uint64_t maxInstructions, std::string& outError);
    void shutdown();

    bool isInitialized() const { return mInitialized; }
    uint32_t currentEip() const { return mEip; }

private:
    win32::Win32CompatLayer& mWin32;
    bool mInitialized = false;
    uint32_t mEip = 0;
#if !defined(FNV_HOST_TEST)
    uc_engine* mUc = nullptr;
    uc_hook mStubHook = 0;
    static void onStubCode(uc_engine* uc, uint64_t address, uint32_t size, void* userData);
#endif
};

} // namespace fnv3::cpu
