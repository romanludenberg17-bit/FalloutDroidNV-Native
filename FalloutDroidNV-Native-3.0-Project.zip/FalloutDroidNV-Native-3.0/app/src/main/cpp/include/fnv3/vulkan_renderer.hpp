#pragma once
#include <cstdint>
#include <string>

#if defined(__ANDROID__) && !defined(FNV_HOST_TEST)
#include <android/native_window.h>
#define VK_USE_PLATFORM_ANDROID_KHR
#include <vulkan/vulkan.h>
#endif

namespace fnv3::gfx {

struct RendererStatus {
    bool initialized = false;
    bool surfaceAttached = false;
    uint32_t width = 0;
    uint32_t height = 0;
    std::string gpuName = "UNINITIALIZED";
    std::string lastError;
};

class VulkanRenderer {
public:
    VulkanRenderer() = default;
    ~VulkanRenderer();

    bool initialize(std::string& outError);
#if defined(__ANDROID__) && !defined(FNV_HOST_TEST)
    bool attachSurface(ANativeWindow* window, std::string& outError);
#endif
    void detachSurface();
    void renderFrame();
    void shutdown();

    RendererStatus status() const { return mStatus; }

private:
    RendererStatus mStatus{};
#if defined(__ANDROID__) && !defined(FNV_HOST_TEST)
    VkInstance mInstance = VK_NULL_HANDLE;
    VkPhysicalDevice mPhysicalDevice = VK_NULL_HANDLE;
    VkDevice mDevice = VK_NULL_HANDLE;
    VkQueue mGraphicsQueue = VK_NULL_HANDLE;
    uint32_t mGraphicsQueueFamily = 0;
    VkSurfaceKHR mSurface = VK_NULL_HANDLE;
#endif
};

} // namespace fnv3::gfx
