#pragma once
#include "fnv3/audio_mixer.hpp"
#include "fnv3/bsa_reader.hpp"
#include "fnv3/com_runtime.hpp"
#include "fnv3/dinput8_compat.hpp"
#include "fnv3/dsound_compat.hpp"
#include "fnv3/input_engine.hpp"
#include "fnv3/pe_loader.hpp"
#include <array>
#include <atomic>
#include <condition_variable>
#include <cstdint>
#include <functional>
#include <memory>
#include <mutex>
#include <string>
#include <unordered_map>
#include <vector>

namespace fnv3::win32 {

struct CpuRegs {
    uint32_t eax = 0, ebx = 0, ecx = 0, edx = 0;
    uint32_t esi = 0, edi = 0, ebp = 0, esp = 0, eip = 0;
};

using MemReadFn  = std::function<bool(uint32_t addr, void* dst, size_t len)>;
using MemWriteFn = std::function<bool(uint32_t addr, const void* src, size_t len)>;

struct ApiStubEntry {
    uint32_t stubAddr = 0;
    std::string dll;
    std::string name;
    bool implemented = false;
};

struct Win32Event {
    std::mutex mtx;
    std::condition_variable cv;
    bool manualReset = false;
    bool signaled = false;
};

struct Win32Mutex {
    std::mutex mtx;
    uint32_t ownerThreadId = 0;
    uint32_t lockCount = 0;
};

struct Win32FileHandle {
    std::vector<uint8_t> data;
    size_t cursor = 0;
    bool writable = false;
    std::string path;
};

struct HeapBlock {
    uint32_t addr = 0;
    uint32_t size = 0;
    bool free = false;
};

class Win32CompatLayer {
public:
    Win32CompatLayer(audio::AudioMixer& mixer, input::InputEngine& input, fs::GameFilesystem& fs);

    // PEB/TEB addresses in guest x86 32-bit address space
    static constexpr uint32_t kPebAddr   = 0x7FFDE000u;
    static constexpr uint32_t kTebAddr   = 0x7FFDF000u;
    static constexpr uint32_t kStubBase  = 0x7F000000u;
    static constexpr uint32_t kStubStride = 16u;

    // Import resolution & strict validation (NO fake success for missing APIs!)
    bool isApiImplemented(const std::string& dll, const std::string& funcName) const;
    uint32_t registerImportStub(const std::string& dll, const std::string& funcName);
    core::ImportValidationReport validateImports(const core::PeImage& image) const;

    // x86 stdcall dispatch from Unicorn UC_HOOK_CODE
    bool dispatchStub(uint32_t stubAddr, CpuRegs& regs, const MemReadFn& readMem, const MemWriteFn& writeMem);

    // Direct C++ helpers (also callable by host unit tests & internal subsystems)
    uint32_t tlsAlloc();
    bool tlsFree(uint32_t index);
    bool tlsSetValue(uint32_t threadId, uint32_t index, uint32_t value);
    uint32_t tlsGetValue(uint32_t threadId, uint32_t index) const;

    uint32_t createEvent(bool manualReset, bool initialState);
    bool setEvent(uint32_t handle);
    bool resetEvent(uint32_t handle);
    uint32_t waitForSingleObject(uint32_t handle, uint32_t timeoutMs);

    uint32_t createMutex(bool initialOwner, uint32_t threadId);
    bool releaseMutex(uint32_t handle, uint32_t threadId);

    void enterCriticalSection(uint32_t csAddr);
    void leaveCriticalSection(uint32_t csAddr);

    uint32_t heapAlloc(uint32_t size);
    bool heapFree(uint32_t addr);

    bool regCreateOrOpenKey(const std::string& fullPath, uint32_t& outHandle);
    bool regSetString(uint32_t hKey, const std::string& name, const std::string& value);
    bool regQueryString(uint32_t hKey, const std::string& name, std::string& outValue) const;
    bool regCloseKey(uint32_t hKey);

    void setEnvVar(const std::string& key, const std::string& val);
    bool getEnvVar(const std::string& key, std::string& outVal) const;

    // COM factories
    dinput::DirectInput8* createDirectInput8();
    dsound::DirectSound8* createDirectSound8();
    dsound::XAudio2Engine* createXAudio2();
    com::ComRegistry& comRegistry() { return mComReg; }

    size_t stubCount() const { return mStubs.size(); }
    const std::vector<std::string>& unimplementedLog() const { return mMissingRuntimeCalls; }
    std::vector<std::string> listImplementedApis() const;
    std::string buildApiReport() const;

private:
    static std::string toLower(const std::string& s);

    audio::AudioMixer& mMixer;
    input::InputEngine& mInput;
    fs::GameFilesystem& mFs;
    com::ComRegistry mComReg;

    mutable std::mutex mStateMtx;
    uint32_t mNextStub = kStubBase;
    uint32_t mNextHandle = 0x100u;
    uint32_t mNextHeapPtr = 0x20000000u;
    uint32_t mLastError = 0;
    uint32_t mUnhandledExceptionFilter = 0;
    bool mComInitialized = false;
    bool mWsaInitialized = false;

    std::unordered_map<uint32_t, ApiStubEntry> mStubs;
    std::unordered_map<std::string, uint32_t> mLoadedModules;
    std::vector<std::string> mMissingRuntimeCalls;

    // TLS: 64 slots
    std::array<bool, 64> mTlsAllocated{};
    std::unordered_map<uint32_t, std::array<uint32_t, 64>> mThreadTls;

    // Sync handles
    std::unordered_map<uint32_t, std::shared_ptr<Win32Event>> mEvents;
    std::unordered_map<uint32_t, std::shared_ptr<Win32Mutex>> mMutexes;
    std::unordered_map<uint32_t, std::shared_ptr<std::recursive_mutex>> mCritSecs;

    // Heap & VirtualAlloc blocks
    std::vector<HeapBlock> mHeapBlocks;

    // File handles
    std::unordered_map<uint32_t, Win32FileHandle> mFiles;

    // Registry (in-memory HKLM/HKCU tree)
    std::unordered_map<uint32_t, std::string> mOpenRegKeys;
    std::unordered_map<std::string, std::unordered_map<std::string, std::string>> mRegStore;

    // Environment variables
    std::unordered_map<std::string, std::string> mEnvVars;
};

} // namespace fnv3::win32
