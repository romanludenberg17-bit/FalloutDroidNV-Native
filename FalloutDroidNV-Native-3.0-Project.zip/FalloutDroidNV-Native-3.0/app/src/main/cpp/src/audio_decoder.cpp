#include "fnv3/audio_decoder.hpp"
#include <algorithm>
#include <cstring>

namespace fnv3::audio {

namespace {
uint16_t rd16(const std::vector<uint8_t>& d, size_t o) {
    uint16_t v = 0; std::memcpy(&v, d.data() + o, 2); return v;
}
uint32_t rd32(const std::vector<uint8_t>& d, size_t o) {
    uint32_t v = 0; std::memcpy(&v, d.data() + o, 4); return v;
}
} // namespace

AudioFormatKind AudioDecoder::detectFormat(const std::vector<uint8_t>& data) {
    if (data.size() < 12) return AudioFormatKind::Unknown;
    if (std::memcmp(data.data(), "RIFF", 4) == 0) {
        if (std::memcmp(data.data() + 8, "WAVE", 4) == 0) return AudioFormatKind::WavPcm;
        if (std::memcmp(data.data() + 8, "XWMA", 4) == 0) return AudioFormatKind::Xwma;
    }
    if (std::memcmp(data.data(), "OggS", 4) == 0) return AudioFormatKind::OggVorbis;
    if (std::memcmp(data.data(), "ID3", 3) == 0) return AudioFormatKind::Mp3;
    if (data[0] == 0xFF && (data[1] & 0xE0) == 0xE0) return AudioFormatKind::Mp3;
    return AudioFormatKind::Unknown;
}

bool AudioDecoder::decodeWavPcm(const std::vector<uint8_t>& data, DecodedAudio& out, std::string& outError) {
    if (detectFormat(data) != AudioFormatKind::WavPcm) {
        outError = "Not a RIFF/WAVE file";
        return false;
    }
    out = DecodedAudio{};
    out.format = AudioFormatKind::WavPcm;

    size_t pos = 12;
    bool gotFmt = false, gotData = false;
    while (pos + 8 <= data.size()) {
        uint32_t chunkSize = rd32(data, pos + 4);
        size_t payload = pos + 8;
        if (payload + chunkSize > data.size()) chunkSize = static_cast<uint32_t>(data.size() - payload);

        if (std::memcmp(data.data() + pos, "fmt ", 4) == 0 && chunkSize >= 16) {
            uint16_t audioFmt = rd16(data, payload + 0);
            if (audioFmt != 1 && audioFmt != 3) { // 1=PCM, 3=IEEE Float
                outError = "Unsupported WAV audioFormat tag: " + std::to_string(audioFmt);
                return false;
            }
            out.channels      = rd16(data, payload + 2);
            out.sampleRate    = rd32(data, payload + 4);
            out.bitsPerSample = rd16(data, payload + 14);
            gotFmt = true;
        } else if (std::memcmp(data.data() + pos, "data", 4) == 0) {
            out.pcmBytes.assign(data.begin() + static_cast<ptrdiff_t>(payload),
                                data.begin() + static_cast<ptrdiff_t>(payload + chunkSize));
            gotData = true;
        }
        pos = payload + chunkSize + (chunkSize & 1u);
    }
    if (!gotFmt || !gotData) {
        outError = "Missing fmt or data chunk in WAV";
        return false;
    }
    return true;
}

bool AudioDecoder::probeCompressedHeader(const std::vector<uint8_t>& data, DecodedAudio& outMeta, std::string& outError) {
    auto kind = detectFormat(data);
    outMeta = DecodedAudio{};
    outMeta.format = kind;

    if (kind == AudioFormatKind::OggVorbis) {
        // Locate "\x01vorbis" identification header (channels @ +11, sampleRate @ +12)
        for (size_t i = 0; i + 16 < std::min<size_t>(data.size(), 128); ++i) {
            if (data[i] == 0x01 && std::memcmp(data.data() + i + 1, "vorbis", 6) == 0) {
                outMeta.channels = data[i + 11];
                outMeta.sampleRate = rd32(data, i + 12);
                outMeta.bitsPerSample = 16;
                return true;
            }
        }
        outError = "OggS container without Vorbis identification header";
        return false;
    }

    if (kind == AudioFormatKind::Xwma) {
        size_t pos = 12;
        while (pos + 8 <= data.size()) {
            uint32_t csz = rd32(data, pos + 4);
            if (std::memcmp(data.data() + pos, "fmt ", 4) == 0 && pos + 8 + 16 <= data.size()) {
                outMeta.channels = rd16(data, pos + 8 + 2);
                outMeta.sampleRate = rd32(data, pos + 8 + 4);
                outMeta.bitsPerSample = 16;
                return true;
            }
            pos += 8 + csz + (csz & 1u);
        }
        outError = "XWMA missing fmt chunk";
        return false;
    }

    if (kind == AudioFormatKind::Mp3) {
        size_t off = 0;
        if (data.size() >= 10 && std::memcmp(data.data(), "ID3", 3) == 0) {
            uint32_t tagSz = ((data[6] & 0x7Fu) << 21) | ((data[7] & 0x7Fu) << 14) |
                             ((data[8] & 0x7Fu) << 7) | (data[9] & 0x7Fu);
            off = 10 + tagSz;
        }
        static const uint32_t kSrMpeg1[4] = {44100, 48000, 32000, 44100};
        for (size_t i = off; i + 4 <= std::min<size_t>(data.size(), off + 4096); ++i) {
            if (data[i] == 0xFF && (data[i + 1] & 0xE0) == 0xE0) {
                uint8_t srIdx = (data[i + 2] >> 2) & 0x03;
                uint8_t chMode = (data[i + 3] >> 6) & 0x03;
                outMeta.sampleRate = kSrMpeg1[srIdx];
                outMeta.channels = (chMode == 3) ? 1 : 2;
                outMeta.bitsPerSample = 16;
                return true;
            }
        }
        outError = "MP3 MPEG frame sync not found";
        return false;
    }

    outError = "Unknown audio container format";
    return false;
}

bool AudioDecoder::decodeToPcm(const std::vector<uint8_t>& data, DecodedAudio& out, std::string& outError) {
    auto kind = detectFormat(data);
    if (kind == AudioFormatKind::WavPcm) {
        return decodeWavPcm(data, out, outError);
    }
    // On Android runtime, MP3 / OGG Vorbis decode via AMediaExtractor + AMediaCodec (libmediandk.so).
    // On host builds without libmediandk, probe header accurately and report codec requirement honestly.
    if (!probeCompressedHeader(data, out, outError)) return false;
    outError = "Compressed format probed (" + std::to_string(out.sampleRate) + " Hz, " +
               std::to_string(out.channels) + " ch); full PCM decode requires Android libmediandk/FFmpeg";
    return false;
}

AudioStreamPlayer::AudioStreamPlayer(AudioMixer& mixer) : mMixer(mixer) {}

uint32_t AudioStreamPlayer::openStream(const DecodedAudio& audio, AudioCategory category, bool loop) {
    uint32_t h = mMixer.createBuffer(audio.sampleRate, audio.channels, audio.bitsPerSample, category, false);
    if (h == 0) return 0;
    mStreams.push_back(StreamState{h, audio.pcmBytes, 0, loop});
    feedNextChunk(h, 16384);
    mMixer.play(h, false);
    return h;
}

bool AudioStreamPlayer::feedNextChunk(uint32_t handle, size_t maxBytes) {
    for (auto& st : mStreams) {
        if (st.voiceHandle != handle) continue;
        if (st.sourcePcm.empty()) return false;
        if (st.cursorBytes >= st.sourcePcm.size()) {
            if (!st.loop) return false;
            st.cursorBytes = 0;
        }
        size_t avail = std::min(maxBytes, st.sourcePcm.size() - st.cursorBytes);
        bool ok = mMixer.uploadPcm(handle, st.sourcePcm.data() + st.cursorBytes, avail, true);
        if (ok) st.cursorBytes += avail;
        return ok;
    }
    return false;
}

bool AudioStreamPlayer::isFinished(uint32_t handle) const {
    for (const auto& st : mStreams) {
        if (st.voiceHandle == handle) {
            return !st.loop && st.cursorBytes >= st.sourcePcm.size() && mMixer.getStatus(handle) == 0;
        }
    }
    return true;
}

} // namespace fnv3::audio
