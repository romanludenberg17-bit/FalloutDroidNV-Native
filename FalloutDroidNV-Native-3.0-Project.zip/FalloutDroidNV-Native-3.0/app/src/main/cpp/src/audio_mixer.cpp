#include "fnv3/audio_mixer.hpp"
#include <algorithm>
#include <cmath>
#include <cstring>

namespace fnv3::audio {

namespace {
inline float clampf(float v, float lo, float hi) {
    return std::max(lo, std::min(hi, v));
}
inline Vec3 sub3(const Vec3& a, const Vec3& b) {
    return {a.x - b.x, a.y - b.y, a.z - b.z};
}
inline float dot3(const Vec3& a, const Vec3& b) {
    return a.x * b.x + a.y * b.y + a.z * b.z;
}
inline Vec3 cross3(const Vec3& a, const Vec3& b) {
    return {
        a.y * b.z - a.z * b.y,
        a.z * b.x - a.x * b.z,
        a.x * b.y - a.y * b.x
    };
}
inline Vec3 norm3(const Vec3& v) {
    float lenSq = dot3(v, v);
    if (lenSq <= 1e-12f) return {0.0f, 0.0f, 0.0f};
    float inv = 1.0f / std::sqrt(lenSq);
    return {v.x * inv, v.y * inv, v.z * inv};
}
} // namespace

AudioMixer::AudioMixer(uint32_t outputSampleRate)
    : mSampleRate(outputSampleRate ? outputSampleRate : kDefaultSampleRate) {
    mCategoryVolumes.fill(1.0f);
    mCategoryVolumes[static_cast<size_t>(AudioCategory::Music)] = 0.70f;
    mCategoryVolumes[static_cast<size_t>(AudioCategory::Radio)] = 0.85f;
}

float AudioMixer::millibelsToGain(int32_t mb) {
    if (mb <= -10000) return 0.0f;
    if (mb >= 0) return 1.0f;
    return std::pow(10.0f, static_cast<float>(mb) / 2000.0f);
}

void AudioMixer::setMasterVolume(float vol) {
    std::lock_guard<std::mutex> lock(mMutex);
    mMasterVolume = clampf(vol, 0.0f, 1.0f);
}

void AudioMixer::setCategoryVolume(AudioCategory cat, float vol) {
    std::lock_guard<std::mutex> lock(mMutex);
    size_t idx = static_cast<size_t>(cat);
    if (idx < mCategoryVolumes.size()) {
        mCategoryVolumes[idx] = clampf(vol, 0.0f, 1.0f);
    }
}

float AudioMixer::getCategoryVolume(AudioCategory cat) const {
    std::lock_guard<std::mutex> lock(mMutex);
    size_t idx = static_cast<size_t>(cat);
    return idx < mCategoryVolumes.size() ? mCategoryVolumes[idx] : 1.0f;
}

uint32_t AudioMixer::createBuffer(uint32_t sampleRate, uint16_t channels, uint16_t bitsPerSample,
                                  AudioCategory category, bool is3D) {
    std::lock_guard<std::mutex> lock(mMutex);
    for (auto& v : mVoices) {
        if (!v.allocated) {
            v = Voice{};
            v.allocated = true;
            v.handle = mNextHandle++;
            v.srcSampleRate = sampleRate ? sampleRate : 44100;
            v.srcChannels = (channels == 2) ? 2 : 1;
            v.srcBitsPerSample = (bitsPerSample == 8 || bitsPerSample == 32) ? bitsPerSample : 16;
            v.category = category;
            v.spatial.enabled = is3D;
            return v.handle;
        }
    }
    return 0;
}

uint32_t AudioMixer::duplicateBuffer(uint32_t srcHandle) {
    std::lock_guard<std::mutex> lock(mMutex);
    const Voice* src = nullptr;
    for (const auto& v : mVoices) {
        if (v.allocated && v.handle == srcHandle) { src = &v; break; }
    }
    if (!src) return 0;
    for (auto& dst : mVoices) {
        if (!dst.allocated) {
            dst = *src;
            dst.handle = mNextHandle++;
            dst.playing = false;
            dst.playCursorFrames = 0.0;
            return dst.handle;
        }
    }
    return 0;
}

bool AudioMixer::uploadPcm(uint32_t handle, const void* data, size_t byteLength, bool appendStream) {
    if (!data || byteLength == 0) return false;
    std::lock_guard<std::mutex> lock(mMutex);
    for (auto& v : mVoices) {
        if (!v.allocated || v.handle != handle) continue;

        std::vector<float> converted;
        if (v.srcBitsPerSample == 16) {
            size_t count = byteLength / 2;
            converted.resize(count);
            const auto* s16 = static_cast<const int16_t*>(data);
            for (size_t i = 0; i < count; ++i) {
                converted[i] = static_cast<float>(s16[i]) / 32768.0f;
            }
        } else if (v.srcBitsPerSample == 8) {
            converted.resize(byteLength);
            const auto* u8 = static_cast<const uint8_t*>(data);
            for (size_t i = 0; i < byteLength; ++i) {
                converted[i] = (static_cast<float>(u8[i]) - 128.0f) / 128.0f;
            }
        } else if (v.srcBitsPerSample == 32) {
            size_t count = byteLength / 4;
            converted.resize(count);
            std::memcpy(converted.data(), data, count * sizeof(float));
        } else {
            return false;
        }

        if (appendStream) {
            v.streaming = true;
            // Compact already-played prefix if large
            size_t consumedSamples = static_cast<size_t>(v.playCursorFrames) * v.srcChannels;
            if (consumedSamples > 48000 && consumedSamples <= v.pcmSamples.size()) {
                v.pcmSamples.erase(v.pcmSamples.begin(), v.pcmSamples.begin() + static_cast<ptrdiff_t>(consumedSamples));
                v.playCursorFrames -= static_cast<double>(consumedSamples / v.srcChannels);
            }
            v.pcmSamples.insert(v.pcmSamples.end(), converted.begin(), converted.end());
        } else {
            v.pcmSamples = std::move(converted);
            v.playCursorFrames = 0.0;
        }
        return true;
    }
    return false;
}

bool AudioMixer::play(uint32_t handle, bool loop) {
    std::lock_guard<std::mutex> lock(mMutex);
    for (auto& v : mVoices) {
        if (!v.allocated || v.handle != handle) continue;
        // One-shot replay sync: if cursor reached end, rewind to 0 cleanly!
        size_t totalFrames = v.pcmSamples.size() / v.srcChannels;
        if (!v.playing || v.playCursorFrames >= static_cast<double>(totalFrames)) {
            if (!v.streaming) v.playCursorFrames = 0.0;
        }
        v.looping = loop;
        v.playing = true;
        return true;
    }
    return false;
}

bool AudioMixer::stop(uint32_t handle) {
    std::lock_guard<std::mutex> lock(mMutex);
    for (auto& v : mVoices) {
        if (!v.allocated || v.handle != handle) continue;
        v.playing = false;
        return true;
    }
    return false;
}

bool AudioMixer::release(uint32_t handle) {
    std::lock_guard<std::mutex> lock(mMutex);
    for (auto& v : mVoices) {
        if (!v.allocated || v.handle != handle) continue;
        v = Voice{};
        return true;
    }
    return false;
}

bool AudioMixer::setVolumeMillibels(uint32_t handle, int32_t millibels) {
    std::lock_guard<std::mutex> lock(mMutex);
    for (auto& v : mVoices) {
        if (!v.allocated || v.handle != handle) continue;
        v.dsVolumeMb = std::max(-10000, std::min(0, millibels));
        return true;
    }
    return false;
}

bool AudioMixer::setPanMillibels(uint32_t handle, int32_t panMb) {
    std::lock_guard<std::mutex> lock(mMutex);
    for (auto& v : mVoices) {
        if (!v.allocated || v.handle != handle) continue;
        v.dsPanMb = std::max(-10000, std::min(10000, panMb));
        return true;
    }
    return false;
}

bool AudioMixer::setFrequency(uint32_t handle, uint32_t newSampleRate) {
    if (newSampleRate < 100 || newSampleRate > 200000) return false;
    std::lock_guard<std::mutex> lock(mMutex);
    for (auto& v : mVoices) {
        if (!v.allocated || v.handle != handle) continue;
        v.srcSampleRate = newSampleRate;
        return true;
    }
    return false;
}

uint32_t AudioMixer::getStatus(uint32_t handle) const {
    std::lock_guard<std::mutex> lock(mMutex);
    for (const auto& v : mVoices) {
        if (!v.allocated || v.handle != handle) continue;
        if (!v.playing) return 0u;
        return v.looping ? 5u : 1u; // DSBSTATUS_PLAYING | DSBSTATUS_LOOPING
    }
    return 0u;
}

uint32_t AudioMixer::getCurrentPositionBytes(uint32_t handle) const {
    std::lock_guard<std::mutex> lock(mMutex);
    for (const auto& v : mVoices) {
        if (!v.allocated || v.handle != handle) continue;
        uint32_t frameBytes = v.srcChannels * (v.srcBitsPerSample / 8);
        return static_cast<uint32_t>(v.playCursorFrames) * frameBytes;
    }
    return 0u;
}

bool AudioMixer::setCurrentPositionBytes(uint32_t handle, uint32_t bytePos) {
    std::lock_guard<std::mutex> lock(mMutex);
    for (auto& v : mVoices) {
        if (!v.allocated || v.handle != handle) continue;
        uint32_t frameBytes = std::max<uint32_t>(1u, v.srcChannels * (v.srcBitsPerSample / 8));
        size_t maxFrames = v.pcmSamples.size() / v.srcChannels;
        double targetFrame = static_cast<double>(bytePos / frameBytes);
        v.playCursorFrames = std::min(targetFrame, static_cast<double>(maxFrames));
        return true;
    }
    return false;
}

bool AudioMixer::set3DPosition(uint32_t handle, float x, float y, float z) {
    std::lock_guard<std::mutex> lock(mMutex);
    for (auto& v : mVoices) {
        if (!v.allocated || v.handle != handle) continue;
        v.spatial.position = {x, y, z};
        return true;
    }
    return false;
}

bool AudioMixer::set3DDistances(uint32_t handle, float minDist, float maxDist) {
    std::lock_guard<std::mutex> lock(mMutex);
    for (auto& v : mVoices) {
        if (!v.allocated || v.handle != handle) continue;
        v.spatial.minDistance = std::max(0.01f, minDist);
        v.spatial.maxDistance = std::max(v.spatial.minDistance + 0.01f, maxDist);
        return true;
    }
    return false;
}

bool AudioMixer::set3DMode(uint32_t handle, bool enabled, bool headRelative) {
    std::lock_guard<std::mutex> lock(mMutex);
    for (auto& v : mVoices) {
        if (!v.allocated || v.handle != handle) continue;
        v.spatial.enabled = enabled;
        v.spatial.headRelative = headRelative;
        return true;
    }
    return false;
}

void AudioMixer::setListener3D(const Listener3D& listener) {
    std::lock_guard<std::mutex> lock(mMutex);
    mListener = listener;
}

uint32_t AudioMixer::xa2CreateSourceVoice(uint32_t sampleRate, uint16_t channels, uint16_t bitsPerSample, AudioCategory category) {
    return createBuffer(sampleRate, channels, bitsPerSample, category, false);
}

bool AudioMixer::xa2SubmitSourceBuffer(uint32_t handle, const void* data, size_t byteLength) {
    return uploadPcm(handle, data, byteLength, true);
}

bool AudioMixer::xa2SetVolume(uint32_t handle, float gain) {
    std::lock_guard<std::mutex> lock(mMutex);
    for (auto& v : mVoices) {
        if (!v.allocated || v.handle != handle) continue;
        v.linearVolume = clampf(gain, 0.0f, 4.0f);
        return true;
    }
    return false;
}

bool AudioMixer::xa2SetFrequencyRatio(uint32_t handle, float ratio) {
    std::lock_guard<std::mutex> lock(mMutex);
    for (auto& v : mVoices) {
        if (!v.allocated || v.handle != handle) continue;
        v.frequencyRatio = clampf(ratio, 0.05f, 4.0f);
        return true;
    }
    return false;
}

void AudioMixer::computeStereoGains(const Voice& v, float& outL, float& outR) const {
    float baseGain = mMasterVolume
                   * mCategoryVolumes[static_cast<size_t>(v.category)]
                   * millibelsToGain(v.dsVolumeMb)
                   * v.linearVolume;

    float pan = 0.0f; // -1.0 left .. +1.0 right
    float atten = 1.0f;

    if (v.spatial.enabled) {
        Vec3 rel = v.spatial.headRelative ? v.spatial.position : sub3(v.spatial.position, mListener.position);
        float dist = std::sqrt(dot3(rel, rel)) * mListener.distanceFactor;
        if (dist > v.spatial.minDistance) {
            float clamped = std::min(dist, v.spatial.maxDistance);
            float denom = v.spatial.minDistance + mListener.rolloffFactor * (clamped - v.spatial.minDistance);
            atten = (denom > 1e-4f) ? (v.spatial.minDistance / denom) : 1.0f;
            if (dist >= v.spatial.maxDistance) atten *= 0.05f;
        }
        Vec3 dir = norm3(rel);
        // Right vector in left-handed DirectSound coordinates: right = top x front
        Vec3 right = norm3(cross3(mListener.top, mListener.front));
        pan = clampf(dot3(dir, right), -1.0f, 1.0f);
    } else if (v.dsPanMb != 0) {
        pan = clampf(static_cast<float>(v.dsPanMb) / 10000.0f, -1.0f, 1.0f);
    }

    // Constant-power stereo pan law (strictly clamped so sqrt never sees negative -> ZERO NaN!)
    float panL = std::sqrt(clampf(0.5f * (1.0f - pan), 0.0f, 1.0f));
    float panR = std::sqrt(clampf(0.5f * (1.0f + pan), 0.0f, 1.0f));
    outL = baseGain * atten * panL;
    outR = baseGain * atten * panR;
}

void AudioMixer::mixFrames(float* outInterleavedStereo, uint32_t numFrames) {
    if (!outInterleavedStereo || numFrames == 0) return;
    std::memset(outInterleavedStereo, 0, sizeof(float) * numFrames * 2);

    std::lock_guard<std::mutex> lock(mMutex);

    for (auto& v : mVoices) {
        if (!v.allocated || !v.playing || v.pcmSamples.empty()) continue;

        const size_t totalFrames = v.pcmSamples.size() / v.srcChannels;
        if (totalFrames == 0) continue;

        float gainL = 0.0f, gainR = 0.0f;
        computeStereoGains(v, gainL, gainR);
        const double step = (static_cast<double>(v.srcSampleRate) * static_cast<double>(v.frequencyRatio))
                          / static_cast<double>(mSampleRate);

        for (uint32_t i = 0; i < numFrames; ++i) {
            if (v.playCursorFrames >= static_cast<double>(totalFrames)) {
                if (v.looping) {
                    v.playCursorFrames = std::fmod(v.playCursorFrames, static_cast<double>(totalFrames));
                } else {
                    v.playing = false;
                    break;
                }
            }

            size_t idx0 = static_cast<size_t>(v.playCursorFrames);
            size_t idx1 = (idx0 + 1 < totalFrames) ? (idx0 + 1) : (v.looping ? 0 : idx0);
            float frac = static_cast<float>(v.playCursorFrames - static_cast<double>(idx0));

            float sL = 0.0f, sR = 0.0f;
            if (v.srcChannels == 1) {
                float s = v.pcmSamples[idx0] * (1.0f - frac) + v.pcmSamples[idx1] * frac;
                sL = s;
                sR = s;
            } else {
                sL = v.pcmSamples[idx0 * 2] * (1.0f - frac) + v.pcmSamples[idx1 * 2] * frac;
                sR = v.pcmSamples[idx0 * 2 + 1] * (1.0f - frac) + v.pcmSamples[idx1 * 2 + 1] * frac;
            }

            outInterleavedStereo[i * 2]     += sL * gainL;
            outInterleavedStereo[i * 2 + 1] += sR * gainR;
            v.playCursorFrames += step;
        }
    }

    // Final stage: NaN/Inf sanitization + gentle soft limiter (preserves loudness, zero hard clipping)
    float peak = 0.0f;
    double sumSq = 0.0;
    for (uint32_t i = 0; i < numFrames * 2; ++i) {
        float x = outInterleavedStereo[i];
        if (!std::isfinite(x)) {
            x = 0.0f;
            ++mNanSanitized;
        }
        // Soft limiter: y = x / (1 + 0.15 * |x|)
        float y = x / (1.0f + 0.15f * std::fabs(x));
        y = clampf(y, -0.98f, 0.98f);
        outInterleavedStereo[i] = y;
        float ay = std::fabs(y);
        if (ay > peak) peak = ay;
        sumSq += static_cast<double>(y) * static_cast<double>(y);
    }

    mTotalFrames += numFrames;
    mLastPeak = peak;
    mLastRms = static_cast<float>(std::sqrt(sumSq / static_cast<double>(numFrames * 2)));
}

void AudioMixer::setBackendStatus(bool running, bool oboeConnected, const std::string& state, const std::string& err) {
    std::lock_guard<std::mutex> lock(mMutex);
    mMixerRunning = running;
    mOboeConnected = oboeConnected;
    mBackendState = state;
    if (!err.empty()) mLastError = err;
}

void AudioMixer::recordUnderrun() {
    std::lock_guard<std::mutex> lock(mMutex);
    ++mUnderruns;
}

AudioDiagnostics AudioMixer::getDiagnostics() const {
    std::lock_guard<std::mutex> lock(mMutex);
    AudioDiagnostics d{};
    d.sampleRate = mSampleRate;
    d.totalPcmFrames = mTotalFrames;
    d.underrunCount = mUnderruns;
    d.nanSanitizedCount = mNanSanitized;
    d.peakLevel = mLastPeak;
    d.rmsLevel = mLastRms;
    d.mixerRunning = mMixerRunning;
    d.oboeConnected = mOboeConnected;
    d.backendState = mBackendState;
    d.lastError = mLastError;

    for (const auto& v : mVoices) {
        if (v.allocated) {
            ++d.activeSources;
            if (v.playing) {
                ++d.activeChannels;
                d.categoryCounts[static_cast<size_t>(v.category)]++;
            }
        }
    }
    return d;
}

} // namespace fnv3::audio
