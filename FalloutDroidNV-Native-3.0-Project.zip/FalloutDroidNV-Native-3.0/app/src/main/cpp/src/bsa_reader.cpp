#include "fnv3/bsa_reader.hpp"
#include <algorithm>
#include <cctype>
#include <cstring>
#include <filesystem>
#include <fstream>
#include <zlib.h>

namespace fnv3::fs {

namespace {
template <typename T>
bool readPod(std::ifstream& f, T& out) {
    return static_cast<bool>(f.read(reinterpret_cast<char*>(&out), sizeof(T)));
}
} // namespace

std::string BsaArchive::normalizePath(const std::string& p) {
    std::string out;
    out.reserve(p.size());
    for (char c : p) {
        if (c == '\\') out.push_back('/');
        else out.push_back(static_cast<char>(std::tolower(static_cast<unsigned char>(c))));
    }
    while (!out.empty() && out.front() == '/') out.erase(out.begin());
    return out;
}

bool BsaArchive::open(const std::string& filePath, std::string& outError) {
    std::ifstream f(filePath, std::ios::binary);
    if (!f) {
        outError = "Cannot open BSA: " + filePath;
        return false;
    }

    char magic[4]{};
    if (!f.read(magic, 4) || std::memcmp(magic, "BSA\0", 4) != 0) {
        outError = "Invalid BSA magic";
        return false;
    }

    uint32_t version = 0, offset = 0, archiveFlags = 0, folderCount = 0, fileCount = 0;
    uint32_t totalFolderNameLen = 0, totalFileNameLen = 0, fileFlags = 0;
    if (!readPod(f, version) || !readPod(f, offset) || !readPod(f, archiveFlags) ||
        !readPod(f, folderCount) || !readPod(f, fileCount) ||
        !readPod(f, totalFolderNameLen) || !readPod(f, totalFileNameLen) || !readPod(f, fileFlags)) {
        outError = "Truncated BSA header";
        return false;
    }
    if (version != 104 && version != 103) {
        outError = "Unsupported BSA version: " + std::to_string(version);
        return false;
    }

    mArchivePath = filePath;
    mVersion = version;
    mArchiveFlags = archiveFlags;
    mEntries.clear();

    struct FolderRec { uint64_t hash; uint32_t count; uint32_t offset; };
    std::vector<FolderRec> folders(folderCount);
    f.seekg(offset, std::ios::beg);
    for (uint32_t i = 0; i < folderCount; ++i) {
        if (!readPod(f, folders[i].hash) || !readPod(f, folders[i].count) || !readPod(f, folders[i].offset)) {
            outError = "Truncated BSA folder record";
            return false;
        }
    }

    struct RawFileRec { std::string folder; uint32_t sizeField; uint32_t dataOffset; };
    std::vector<RawFileRec> rawFiles;
    rawFiles.reserve(fileCount);

    const bool hasDirNames = (archiveFlags & 0x0001u) != 0;
    const bool defaultCompressed = (archiveFlags & 0x0004u) != 0;

    for (uint32_t i = 0; i < folderCount; ++i) {
        std::string folderName;
        if (hasDirNames) {
            uint8_t nlen = 0;
            if (!readPod(f, nlen) || nlen == 0) { outError = "Invalid BSA folder name length"; return false; }
            folderName.resize(nlen);
            if (!f.read(folderName.data(), nlen)) { outError = "Truncated BSA folder name"; return false; }
            if (!folderName.empty() && folderName.back() == '\0') folderName.pop_back();
        }
        for (uint32_t j = 0; j < folders[i].count; ++j) {
            uint64_t fhash = 0;
            uint32_t fsize = 0, foff = 0;
            if (!readPod(f, fhash) || !readPod(f, fsize) || !readPod(f, foff)) {
                outError = "Truncated BSA file record";
                return false;
            }
            rawFiles.push_back({folderName, fsize, foff});
        }
    }

    // Read NUL-terminated filenames block
    std::vector<char> nameBlock(totalFileNameLen);
    if (totalFileNameLen > 0 && !f.read(nameBlock.data(), static_cast<std::streamsize>(totalFileNameLen))) {
        outError = "Truncated BSA file names block";
        return false;
    }

    size_t pos = 0;
    for (size_t i = 0; i < rawFiles.size(); ++i) {
        std::string fname;
        while (pos < nameBlock.size() && nameBlock[pos] != '\0') {
            fname.push_back(nameBlock[pos++]);
        }
        if (pos < nameBlock.size()) ++pos;

        std::string full = rawFiles[i].folder.empty() ? fname : (rawFiles[i].folder + "/" + fname);
        std::string norm = normalizePath(full);

        bool toggleComp = (rawFiles[i].sizeField & (1u << 30)) != 0;
        uint32_t cleanSize = rawFiles[i].sizeField & 0x3FFFFFFFu;
        bool isComp = toggleComp ? !defaultCompressed : defaultCompressed;

        mEntries[norm] = BsaFileEntry{norm, rawFiles[i].dataOffset, cleanSize, isComp};
    }
    return true;
}

bool BsaArchive::contains(const std::string& normalizedPath) const {
    return mEntries.find(normalizePath(normalizedPath)) != mEntries.end();
}

bool BsaArchive::extract(const std::string& normalizedPath, std::vector<uint8_t>& outData, std::string& outError) const {
    auto it = mEntries.find(normalizePath(normalizedPath));
    if (it == mEntries.end()) {
        outError = "File not in BSA: " + normalizedPath;
        return false;
    }
    const auto& entry = it->second;
    std::ifstream f(mArchivePath, std::ios::binary);
    if (!f) { outError = "Cannot reopen BSA"; return false; }
    f.seekg(entry.offset, std::ios::beg);

    uint32_t remaining = entry.rawSize;
    // Flag 0x100: embedded filename prefix before data in v104
    if ((mArchiveFlags & 0x0100u) != 0 && remaining > 0) {
        uint8_t prefixLen = 0;
        if (!readPod(f, prefixLen) || prefixLen + 1u > remaining) {
            outError = "Invalid BSA embedded filename prefix";
            return false;
        }
        f.seekg(prefixLen, std::ios::cur);
        remaining -= (prefixLen + 1u);
    }

    if (!entry.compressed) {
        outData.resize(remaining);
        if (remaining > 0 && !f.read(reinterpret_cast<char*>(outData.data()), remaining)) {
            outError = "Failed reading uncompressed BSA payload";
            return false;
        }
        return true;
    }

    if (remaining < 4) { outError = "Invalid compressed BSA block"; return false; }
    uint32_t origSize = 0;
    readPod(f, origSize);
    std::vector<uint8_t> comp(remaining - 4);
    if (!f.read(reinterpret_cast<char*>(comp.data()), static_cast<std::streamsize>(comp.size()))) {
        outError = "Failed reading compressed BSA payload";
        return false;
    }

    outData.resize(origSize);
    uLongf dstLen = origSize;
    int zres = ::uncompress(outData.data(), &dstLen, comp.data(), static_cast<uLong>(comp.size()));
    if (zres != Z_OK) {
        outError = "zlib uncompress failed with code " + std::to_string(zres);
        return false;
    }
    outData.resize(dstLen);
    return true;
}

bool GameFilesystem::validateEsmHeader(const std::string& esmPath) {
    std::ifstream f(esmPath, std::ios::binary);
    char hdr[4]{};
    return f && f.read(hdr, 4) && std::memcmp(hdr, "TES4", 4) == 0;
}

bool GameFilesystem::mountDataDir(const std::string& gameRootDir, GameDataReport& outReport) {
    namespace fs = std::filesystem;
    outReport = GameDataReport{};
    mGameRoot = gameRootDir;
    mArchives.clear();

    if (!fs::exists(gameRootDir) || !fs::is_directory(gameRootDir)) {
        outReport.missingRequired.push_back("Game root directory does not exist");
        return false;
    }

    for (const auto& entry : fs::directory_iterator(gameRootDir)) {
        std::string nameLower = BsaArchive::normalizePath(entry.path().filename().string());
        if (nameLower == "falloutnv.exe") outReport.hasExecutable = true;
        if (nameLower == "data" && entry.is_directory()) mDataDir = entry.path().string();
    }
    if (!outReport.hasExecutable) outReport.missingRequired.push_back("FalloutNV.exe");
    if (mDataDir.empty()) {
        outReport.missingRequired.push_back("Data/");
        return false;
    }

    static const std::vector<std::string> kKnownDlcs = {
        "deadmoney.esm", "honesthearts.esm", "oldworldblues.esm",
        "lonesomeroad.esm", "gunrunnersarsenal.esm"
    };

    for (const auto& entry : fs::directory_iterator(mDataDir)) {
        if (!entry.is_regular_file()) continue;
        std::string fn = BsaArchive::normalizePath(entry.path().filename().string());
        if (fn == "falloutnv.esm" && validateEsmHeader(entry.path().string())) {
            outReport.hasFalloutNvEsm = true;
        }
        if (std::find(kKnownDlcs.begin(), kKnownDlcs.end(), fn) != kKnownDlcs.end() &&
            validateEsmHeader(entry.path().string())) {
            outReport.foundDlcs.push_back(entry.path().filename().string());
            ++outReport.dlcCount;
        }
        if (fn.size() > 4 && fn.substr(fn.size() - 4) == ".bsa") {
            BsaArchive arch;
            std::string err;
            if (arch.open(entry.path().string(), err)) {
                if (fn == "fallout - sound.bsa") outReport.hasSoundBsa = true;
                if (fn == "fallout - voices1.bsa") outReport.hasVoicesBsa = true;
                mArchives.push_back(std::move(arch));
                ++outReport.bsaCount;
            }
        }
    }

    if (!outReport.hasFalloutNvEsm) outReport.missingRequired.push_back("Data/FalloutNV.esm");
    return outReport.hasExecutable && outReport.hasFalloutNvEsm;
}

bool GameFilesystem::readVirtualFile(const std::string& gameRelPath, std::vector<uint8_t>& outData) const {
    namespace fs = std::filesystem;
    std::string norm = BsaArchive::normalizePath(gameRelPath);
    if (!mDataDir.empty()) {
        fs::path loose = fs::path(mDataDir) / norm;
        if (fs::exists(loose) && fs::is_regular_file(loose)) {
            std::ifstream f(loose, std::ios::binary | std::ios::ate);
            if (f) {
                auto sz = f.tellg();
                f.seekg(0, std::ios::beg);
                outData.resize(static_cast<size_t>(sz));
                return static_cast<bool>(f.read(reinterpret_cast<char*>(outData.data()), sz));
            }
        }
    }
    std::string err;
    for (const auto& arch : mArchives) {
        if (arch.contains(norm) && arch.extract(norm, outData, err)) {
            return true;
        }
    }
    return false;
}

} // namespace fnv3::fs
