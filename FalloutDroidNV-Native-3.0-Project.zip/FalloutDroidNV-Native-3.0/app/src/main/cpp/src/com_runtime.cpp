#include "fnv3/com_runtime.hpp"

namespace fnv3::com {

uint32_t ComRegistry::registerObject(ComObject* obj, uint32_t vtblSlotCount) {
    if (!obj) return 0;
    uint32_t addr = mNextAddr;
    // Reserve object header (16 B) + vtable pointer table (4 B * slots) aligned to 64 B
    uint32_t vtblAddr = addr + 16u;
    uint32_t span = ((16u + vtblSlotCount * 4u) + 63u) & ~63u;
    mNextAddr += span;
    obj->guestAddress = addr;
    obj->guestVtblAddress = vtblAddr;
    mObjects[addr] = obj;
    return addr;
}

ComObject* ComRegistry::lookup(uint32_t guestAddr) const {
    auto it = mObjects.find(guestAddr);
    return (it != mObjects.end()) ? it->second : nullptr;
}

void ComRegistry::unregisterObject(uint32_t guestAddr) {
    mObjects.erase(guestAddr);
}

} // namespace fnv3::com
