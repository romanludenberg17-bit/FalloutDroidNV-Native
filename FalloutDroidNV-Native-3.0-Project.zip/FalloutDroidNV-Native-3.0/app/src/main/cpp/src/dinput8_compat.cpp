#include "fnv3/dinput8_compat.hpp"
#include <algorithm>
#include <cstring>

namespace fnv3::dinput {

DirectInputDevice8::DirectInputDevice8(input::InputEngine& engine, DeviceKind kind)
    : mInput(engine), mKind(kind) {}

com::HRESULT DirectInputDevice8::queryInterface(const com::Guid& riid, com::ComObject** outObj) {
    if (!outObj) return com::E_POINTER_HR;
    if (riid == com::IID_IUnknown || riid == com::IID_IDirectInputDevice8A) {
        addRef();
        *outObj = this;
        return com::S_OK_HR;
    }
    *outObj = nullptr;
    return com::E_NOINTERFACE_HR;
}

com::HRESULT DirectInputDevice8::setDataFormat(uint32_t) { return com::S_OK_HR; }

com::HRESULT DirectInputDevice8::setCooperativeLevel(uint32_t, uint32_t flags) {
    mCoopFlags = flags;
    return com::S_OK_HR;
}

com::HRESULT DirectInputDevice8::acquire() {
    mAcquired = true;
    return com::S_OK_HR;
}

com::HRESULT DirectInputDevice8::unacquire() {
    mAcquired = false;
    return com::S_OK_HR;
}

com::HRESULT DirectInputDevice8::getDeviceState(uint32_t cbData, void* lpvData) {
    if (!lpvData || cbData == 0) return com::E_INVALIDARG_HR;
    if (!mAcquired) mAcquired = true;

    if (mKind == DeviceKind::Keyboard) {
        if (cbData < 256) return com::E_INVALIDARG_HR;
        auto keys = mInput.snapshotDirectInputKeys();
        std::memcpy(lpvData, keys.data(), 256);
        return com::S_OK_HR;
    }
    if (mKind == DeviceKind::Mouse) {
        if (cbData < 16) return com::E_INVALIDARG_HR;
        auto ms = mInput.consumeMouseState();
        DiMouseState2 st{};
        st.lX = static_cast<int32_t>(ms.relAccumX);
        st.lY = static_cast<int32_t>(ms.relAccumY);
        st.lZ = ms.wheelAccum * 120;
        st.rgbButtons[0] = (ms.buttonsMask & 0x01) ? 0x80 : 0x00;
        st.rgbButtons[1] = (ms.buttonsMask & 0x02) ? 0x80 : 0x00;
        st.rgbButtons[2] = (ms.buttonsMask & 0x04) ? 0x80 : 0x00;
        std::memcpy(lpvData, &st, std::min<size_t>(cbData, sizeof(DiMouseState2)));
        return com::S_OK_HR;
    }
    std::memset(lpvData, 0, cbData);
    return com::S_OK_HR;
}

com::HRESULT DirectInputDevice8::getDeviceData(uint32_t cbObjectData, DiDeviceObjectData* rgdod, uint32_t* inOutCount) {
    if (!inOutCount || cbObjectData < sizeof(DiDeviceObjectData)) return com::E_INVALIDARG_HR;
    uint32_t cap = *inOutCount;
    uint32_t written = 0;
    input::InputEvent ev{};
    while (written < cap && mInput.popEvent(ev)) {
        DiDeviceObjectData item{};
        if (mKind == DeviceKind::Keyboard && (ev.type == input::EventType::KeyDown || ev.type == input::EventType::KeyUp)) {
            item.dwOfs = ev.dikCode;
            item.dwData = (ev.type == input::EventType::KeyDown) ? 0x80u : 0x00u;
        } else if (mKind == DeviceKind::Mouse) {
            if (ev.type == input::EventType::MouseButtonDown || ev.type == input::EventType::MouseButtonUp) {
                item.dwOfs = (ev.vkCode == input::VK::LBUTTON) ? 12u : 13u;
                item.dwData = (ev.type == input::EventType::MouseButtonDown) ? 0x80u : 0x00u;
            } else if (ev.type == input::EventType::MouseWheel) {
                item.dwOfs = 8u;
                item.dwData = static_cast<uint32_t>(ev.wheelDelta * 120);
            } else {
                continue;
            }
        } else {
            continue;
        }
        item.dwSequence = mSeqCounter++;
        if (rgdod) rgdod[written] = item;
        ++written;
    }
    *inOutCount = written;
    return com::S_OK_HR;
}

DirectInput8::DirectInput8(input::InputEngine& engine, com::ComRegistry& comReg)
    : mInput(engine), mComReg(comReg) {}

com::HRESULT DirectInput8::queryInterface(const com::Guid& riid, com::ComObject** outObj) {
    if (!outObj) return com::E_POINTER_HR;
    if (riid == com::IID_IUnknown || riid == com::IID_IDirectInput8A) {
        addRef();
        *outObj = this;
        return com::S_OK_HR;
    }
    *outObj = nullptr;
    return com::E_NOINTERFACE_HR;
}

com::HRESULT DirectInput8::createDevice(const com::Guid& rguid, DirectInputDevice8** outDev) {
    if (!outDev) return com::E_POINTER_HR;
    DeviceKind kind = DeviceKind::Gamepad;
    if (rguid == com::GUID_SysKeyboard) kind = DeviceKind::Keyboard;
    else if (rguid == com::GUID_SysMouse) kind = DeviceKind::Mouse;
    auto* dev = new DirectInputDevice8(mInput, kind);
    mComReg.registerObject(dev, 32);
    *outDev = dev;
    return com::S_OK_HR;
}

} // namespace fnv3::dinput
