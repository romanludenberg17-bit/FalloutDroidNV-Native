#include "fnv3/dsound_compat.hpp"
#include <algorithm>
#include <cstring>

namespace fnv3::dsound {

DirectSoundBuffer8::DirectSoundBuffer8(audio::AudioMixer& mixer, uint32_t voiceHandle, uint32_t bufferBytes,
                                       uint32_t sampleRate, uint16_t channels, uint16_t bitsPerSample, bool is3D,
                                       SignalEventFn signalEvent)
    : mMixer(mixer), mVoiceHandle(voiceHandle), mSampleRate(sampleRate), mChannels(channels),
      mBitsPerSample(bitsPerSample), mIs3D(is3D),
      mStagingBuffer(std::max<uint32_t>(4, bufferBytes), 0),
      mSignalEvent(std::move(signalEvent)) {}

com::HRESULT DirectSoundBuffer8::queryInterface(const com::Guid& riid, com::ComObject** outObj) {
    if (!outObj) return com::E_POINTER_HR;
    if (riid == com::IID_IUnknown || riid == com::IID_IDirectSoundBuffer8 ||
        riid == com::IID_IDirectSound3DBuffer8 || riid == com::IID_IDirectSound3DListener8 ||
        riid == com::IID_IDirectSoundNotify) {
        addRef();
        *outObj = this;
        return com::S_OK_HR;
    }
    *outObj = nullptr;
    return com::E_NOINTERFACE_HR;
}

com::HRESULT DirectSoundBuffer8::lock(uint32_t offset, uint32_t bytes, uint8_t** outPtr1, uint32_t* outLen1,
                                      uint8_t** outPtr2, uint32_t* outLen2) {
    if (!outPtr1 || !outLen1 || mStagingBuffer.empty()) return com::E_INVALIDARG_HR;
    uint32_t total = static_cast<uint32_t>(mStagingBuffer.size());
    offset %= total;
    if (bytes == 0 || bytes > total) bytes = total;

    uint32_t first = std::min(bytes, total - offset);
    *outPtr1 = mStagingBuffer.data() + offset;
    *outLen1 = first;
    if (outPtr2 && outLen2) {
        if (bytes > first) {
            *outPtr2 = mStagingBuffer.data();
            *outLen2 = bytes - first;
        } else {
            *outPtr2 = nullptr;
            *outLen2 = 0;
        }
    }
    return com::S_OK_HR;
}

com::HRESULT DirectSoundBuffer8::unlock(const void*, uint32_t, const void*, uint32_t) {
    // Push full staging PCM into unified Stage 1 AudioMixer
    if (!mStagingBuffer.empty()) {
        mMixer.uploadPcm(mVoiceHandle, mStagingBuffer.data(), mStagingBuffer.size(), false);
    }
    return com::S_OK_HR;
}

com::HRESULT DirectSoundBuffer8::play(uint32_t flags) {
    std::fill(mNotifyFired.begin(), mNotifyFired.end(), false);
    return mMixer.play(mVoiceHandle, (flags & 1u) != 0) ? com::S_OK_HR : com::E_FAIL_HR;
}

com::HRESULT DirectSoundBuffer8::stop() {
    bool ok = mMixer.stop(mVoiceHandle);
    pollNotifications();
    return ok ? com::S_OK_HR : com::E_FAIL_HR;
}

com::HRESULT DirectSoundBuffer8::setVolume(int32_t millibels) {
    return mMixer.setVolumeMillibels(mVoiceHandle, millibels) ? com::S_OK_HR : com::E_FAIL_HR;
}

com::HRESULT DirectSoundBuffer8::setPan(int32_t panMb) {
    return mMixer.setPanMillibels(mVoiceHandle, panMb) ? com::S_OK_HR : com::E_FAIL_HR;
}

com::HRESULT DirectSoundBuffer8::setFrequency(uint32_t hz) {
    return mMixer.setFrequency(mVoiceHandle, hz) ? com::S_OK_HR : com::E_INVALIDARG_HR;
}

com::HRESULT DirectSoundBuffer8::getCurrentPosition(uint32_t* playCursor, uint32_t* writeCursor) const {
    uint32_t pos = mMixer.getCurrentPositionBytes(mVoiceHandle);
    if (playCursor) *playCursor = pos;
    if (writeCursor) *writeCursor = pos;
    return com::S_OK_HR;
}

com::HRESULT DirectSoundBuffer8::setCurrentPosition(uint32_t bytePos) {
    return mMixer.setCurrentPositionBytes(mVoiceHandle, bytePos) ? com::S_OK_HR : com::E_FAIL_HR;
}

com::HRESULT DirectSoundBuffer8::getStatus(uint32_t* outStatus) const {
    if (!outStatus) return com::E_POINTER_HR;
    *outStatus = mMixer.getStatus(mVoiceHandle);
    return com::S_OK_HR;
}

com::HRESULT DirectSoundBuffer8::set3DPosition(float x, float y, float z) {
    return mMixer.set3DPosition(mVoiceHandle, x, y, z) ? com::S_OK_HR : com::E_FAIL_HR;
}

com::HRESULT DirectSoundBuffer8::set3DMinDistance(float minDist) {
    mMinDist = minDist;
    return mMixer.set3DDistances(mVoiceHandle, mMinDist, mMaxDist) ? com::S_OK_HR : com::E_FAIL_HR;
}

com::HRESULT DirectSoundBuffer8::set3DMaxDistance(float maxDist) {
    mMaxDist = maxDist;
    return mMixer.set3DDistances(mVoiceHandle, mMinDist, mMaxDist) ? com::S_OK_HR : com::E_FAIL_HR;
}

com::HRESULT DirectSoundBuffer8::set3DMode(uint32_t mode) {
    bool enabled = (mode != 2u);
    bool headRel = (mode == 1u);
    return mMixer.set3DMode(mVoiceHandle, enabled, headRel) ? com::S_OK_HR : com::E_FAIL_HR;
}

com::HRESULT DirectSoundBuffer8::setListenerPosition(float x, float y, float z) {
    mListener.position = {x, y, z};
    mMixer.setListener3D(mListener);
    return com::S_OK_HR;
}

com::HRESULT DirectSoundBuffer8::setListenerOrientation(float fx, float fy, float fz, float tx, float ty, float tz) {
    mListener.front = {fx, fy, fz};
    mListener.top = {tx, ty, tz};
    mMixer.setListener3D(mListener);
    return com::S_OK_HR;
}

com::HRESULT DirectSoundBuffer8::setNotificationPositions(const std::vector<DsNotifyPosition>& positions) {
    mNotifies = positions;
    mNotifyFired.assign(positions.size(), false);
    return com::S_OK_HR;
}

void DirectSoundBuffer8::pollNotifications() {
    if (mNotifies.empty() || !mSignalEvent) return;
    uint32_t pos = mMixer.getCurrentPositionBytes(mVoiceHandle);
    uint32_t st = mMixer.getStatus(mVoiceHandle);
    for (size_t i = 0; i < mNotifies.size(); ++i) {
        if (mNotifyFired[i]) continue;
        bool hit = (mNotifies[i].offsetBytes == 0xFFFFFFFFu && st == 0u) ||
                   (mNotifies[i].offsetBytes != 0xFFFFFFFFu && pos >= mNotifies[i].offsetBytes);
        if (hit) {
            mNotifyFired[i] = true;
            mSignalEvent(mNotifies[i].eventHandle);
        }
    }
}

DirectSound8::DirectSound8(audio::AudioMixer& mixer, com::ComRegistry& comReg, SignalEventFn signalEvent)
    : mMixer(mixer), mComReg(comReg), mSignalEvent(std::move(signalEvent)) {}

com::HRESULT DirectSound8::queryInterface(const com::Guid& riid, com::ComObject** outObj) {
    if (!outObj) return com::E_POINTER_HR;
    if (riid == com::IID_IUnknown || riid == com::IID_IDirectSound8) {
        addRef();
        *outObj = this;
        return com::S_OK_HR;
    }
    *outObj = nullptr;
    return com::E_NOINTERFACE_HR;
}

com::HRESULT DirectSound8::createSoundBuffer(uint32_t bufferBytes, uint32_t sampleRate, uint16_t channels,
                                             uint16_t bitsPerSample, audio::AudioCategory cat, bool is3D,
                                             DirectSoundBuffer8** outBuf) {
    if (!outBuf) return com::E_POINTER_HR;
    uint32_t vh = mMixer.createBuffer(sampleRate, channels, bitsPerSample, cat, is3D);
    if (vh == 0) return com::E_FAIL_HR;
    auto* buf = new DirectSoundBuffer8(mMixer, vh, bufferBytes, sampleRate, channels, bitsPerSample, is3D, mSignalEvent);
    mComReg.registerObject(buf, 24);
    *outBuf = buf;
    return com::S_OK_HR;
}

com::HRESULT DirectSound8::duplicateSoundBuffer(DirectSoundBuffer8* src, DirectSoundBuffer8** outBuf) {
    if (!src || !outBuf) return com::E_INVALIDARG_HR;
    uint32_t vh = mMixer.duplicateBuffer(src->voiceHandle());
    if (vh == 0) return com::E_FAIL_HR;
    auto* buf = new DirectSoundBuffer8(mMixer, vh, src->bufferBytes(), 44100, 1, 16, false, mSignalEvent);
    mComReg.registerObject(buf, 24);
    *outBuf = buf;
    return com::S_OK_HR;
}

com::HRESULT DirectSound8::setCooperativeLevel(uint32_t, uint32_t) { return com::S_OK_HR; }

XAudio2SourceVoice::XAudio2SourceVoice(audio::AudioMixer& mixer, uint32_t voiceHandle)
    : mMixer(mixer), mVoiceHandle(voiceHandle) {}

com::HRESULT XAudio2SourceVoice::submitSourceBuffer(const void* pcmData, size_t byteLength) {
    return mMixer.xa2SubmitSourceBuffer(mVoiceHandle, pcmData, byteLength) ? com::S_OK_HR : com::E_INVALIDARG_HR;
}
com::HRESULT XAudio2SourceVoice::start() { return mMixer.play(mVoiceHandle, false) ? com::S_OK_HR : com::E_FAIL_HR; }
com::HRESULT XAudio2SourceVoice::stop()  { return mMixer.stop(mVoiceHandle) ? com::S_OK_HR : com::E_FAIL_HR; }
com::HRESULT XAudio2SourceVoice::setVolume(float gain) { return mMixer.xa2SetVolume(mVoiceHandle, gain) ? com::S_OK_HR : com::E_FAIL_HR; }
com::HRESULT XAudio2SourceVoice::setFrequencyRatio(float ratio) { return mMixer.xa2SetFrequencyRatio(mVoiceHandle, ratio) ? com::S_OK_HR : com::E_FAIL_HR; }

XAudio2Engine::XAudio2Engine(audio::AudioMixer& mixer, com::ComRegistry& comReg)
    : mMixer(mixer), mComReg(comReg) {}

com::HRESULT XAudio2Engine::queryInterface(const com::Guid& riid, com::ComObject** outObj) {
    if (!outObj) return com::E_POINTER_HR;
    if (riid == com::IID_IUnknown || riid == com::IID_IXAudio2) {
        addRef();
        *outObj = this;
        return com::S_OK_HR;
    }
    *outObj = nullptr;
    return com::E_NOINTERFACE_HR;
}

com::HRESULT XAudio2Engine::createSourceVoice(uint32_t sampleRate, uint16_t channels, uint16_t bitsPerSample,
                                              audio::AudioCategory cat, XAudio2SourceVoice** outVoice) {
    if (!outVoice) return com::E_POINTER_HR;
    uint32_t vh = mMixer.xa2CreateSourceVoice(sampleRate, channels, bitsPerSample, cat);
    if (vh == 0) return com::E_FAIL_HR;
    auto* sv = new XAudio2SourceVoice(mMixer, vh);
    mComReg.registerObject(sv, 24);
    *outVoice = sv;
    return com::S_OK_HR;
}

} // namespace fnv3::dsound
