#include "fnv3/engine_core.hpp"
#include <cmath>
#include <vector>

namespace fnv3 {

NativeEngineCore::NativeEngineCore()
    : mMixer(audio::AudioMixer::kDefaultSampleRate),
      mOboe(mMixer),
      mWin32(mMixer, mInput, mFs),
      mCpu(mWin32) {}

NativeEngineCore::~NativeEngineCore() {
    mOboe.stop();
    mCpu.shutdown();
    mRenderer.shutdown();
}

bool NativeEngineCore::initializeAudio() {
    return mOboe.start();
}

bool NativeEngineCore::mountGameDirectory(const std::string& gameRoot, fs::GameDataReport& outReport) {
    return mFs.mountDataDir(gameRoot, outReport);
}

bool NativeEngineCore::prepareCpuAndLoadExe(const std::string& exePath, std::string& outError) {
    core::PeImage img;
    if (!core::PeLoader::parseFile(exePath, img, outError)) return false;
    if (!mCpu.initialize(outError)) return false;
    return mCpu.loadPeImage(img, outError);
}

void NativeEngineCore::runAudioSelfTestTone(audio::AudioCategory category, float freqHz, uint32_t durationMs) {
    const uint32_t sr = 48000;
    const uint32_t frames = (sr * durationMs) / 1000;
    std::vector<int16_t> pcm(frames);
    for (uint32_t i = 0; i < frames; ++i) {
        float env = 1.0f;
        if (i < 240) env = static_cast<float>(i) / 240.0f;
        else if (i + 240 > frames) env = static_cast<float>(frames - i) / 240.0f;
        float s = std::sin(2.0f * 3.14159265f * freqHz * static_cast<float>(i) / static_cast<float>(sr));
        pcm[i] = static_cast<int16_t>(s * env * 18000.0f);
    }
    uint32_t h = mMixer.createBuffer(sr, 1, 16, category, category == audio::AudioCategory::Spatial3D);
    if (h != 0) {
        if (category == audio::AudioCategory::Spatial3D) {
            mMixer.set3DPosition(h, 4.0f, 0.0f, 3.0f);
            mMixer.set3DDistances(h, 1.0f, 30.0f);
        }
        mMixer.uploadPcm(h, pcm.data(), pcm.size() * sizeof(int16_t), false);
        mMixer.play(h, false);
    }
}

} // namespace fnv3
