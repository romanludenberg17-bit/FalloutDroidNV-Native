#include "fnv3/input_engine.hpp"
#include <algorithm>
#include <cmath>

namespace fnv3::input {

InputEngine::InputEngine() = default;

void InputEngine::setMode(InputMode mode) {
    std::lock_guard<std::mutex> lock(mMutex);
    if (mMode != mode) {
        mMode = mode;
        // Freeze residual relative deltas on mode switch so camera never snaps when entering/leaving menu
        mMouse.relAccumX = 0.0f;
        mMouse.relAccumY = 0.0f;
    }
}

InputMode InputEngine::getMode() const {
    std::lock_guard<std::mutex> lock(mMutex);
    return mMode;
}

void InputEngine::setMouseConfig(float sensitivity, bool invertX, bool invertY) {
    std::lock_guard<std::mutex> lock(mMutex);
    mSensitivity = std::max(0.1f, std::min(10.0f, sensitivity));
    mInvertX = invertX;
    mInvertY = invertY;
}

void InputEngine::pushEventLocked(const InputEvent& ev) {
    if (mQueue.size() >= 512) {
        mQueue.pop_front();
    }
    mQueue.push_back(ev);
}

void InputEngine::setKeyState(uint16_t vkCode, bool pressed) {
    if (vkCode >= 256) return;
    std::lock_guard<std::mutex> lock(mMutex);
    uint8_t& rc = mKeyRefCount[vkCode];
    if (pressed) {
        if (rc == 0) {
            InputEvent ev{};
            ev.type = EventType::KeyDown;
            ev.vkCode = vkCode;
            ev.dikCode = vkToDik(vkCode);
            pushEventLocked(ev);
        }
        if (rc < 255) ++rc;
    } else {
        if (rc > 0) {
            --rc;
            if (rc == 0) {
                InputEvent ev{};
                ev.type = EventType::KeyUp;
                ev.vkCode = vkCode;
                ev.dikCode = vkToDik(vkCode);
                pushEventLocked(ev);
            }
        }
    }
}

bool InputEngine::isKeyDown(uint16_t vkCode) const {
    if (vkCode >= 256) return false;
    std::lock_guard<std::mutex> lock(mMutex);
    return mKeyRefCount[vkCode] > 0;
}

void InputEngine::setStickKeyLocked(uint16_t vkCode, bool wantDown, bool& prevFlag) {
    if (wantDown == prevFlag) return;
    prevFlag = wantDown;
    uint8_t& rc = mKeyRefCount[vkCode];
    if (wantDown) {
        if (rc == 0) {
            InputEvent ev{};
            ev.type = EventType::KeyDown;
            ev.vkCode = vkCode;
            ev.dikCode = vkToDik(vkCode);
            pushEventLocked(ev);
        }
        if (rc < 255) ++rc;
    } else if (rc > 0) {
        --rc;
        if (rc == 0) {
            InputEvent ev{};
            ev.type = EventType::KeyUp;
            ev.vkCode = vkCode;
            ev.dikCode = vkToDik(vkCode);
            pushEventLocked(ev);
        }
    }
}

void InputEngine::setWasdStick(float normX, float normY, float deadZone) {
    std::lock_guard<std::mutex> lock(mMutex);
    float dz = std::max(0.05f, std::min(0.6f, deadZone));
    float mag = std::sqrt(normX * normX + normY * normY);
    bool w = false, s = false, a = false, d = false;
    if (mag >= dz) {
        w = (normY < -dz);
        s = (normY >  dz);
        a = (normX < -dz);
        d = (normX >  dz);
    }
    setStickKeyLocked(VK::KEY_W, w, mStickW);
    setStickKeyLocked(VK::KEY_S, s, mStickS);
    setStickKeyLocked(VK::KEY_A, a, mStickA);
    setStickKeyLocked(VK::KEY_D, d, mStickD);
}

void InputEngine::onTouchpadDelta(float rawDx, float rawDy) {
    std::lock_guard<std::mutex> lock(mMutex);
    float dx = rawDx * mSensitivity * (mInvertX ? -1.0f : 1.0f);
    float dy = rawDy * mSensitivity * (mInvertY ? -1.0f : 1.0f);

    if (mMode == InputMode::Gameplay) {
        mMouse.relAccumX += dx;
        mMouse.relAccumY += dy;
        InputEvent ev{};
        ev.type = EventType::MouseMoveRel;
        ev.dx = dx;
        ev.dy = dy;
        pushEventLocked(ev);
    } else {
        // Menu mode: move cursor, NEVER rotate gameplay camera
        mMouse.cursorX = std::max(0.0f, std::min(1.0f, mMouse.cursorX + dx * 0.0012f));
        mMouse.cursorY = std::max(0.0f, std::min(1.0f, mMouse.cursorY + dy * 0.0018f));
        InputEvent ev{};
        ev.type = EventType::MouseMoveAbs;
        ev.absX = mMouse.cursorX;
        ev.absY = mMouse.cursorY;
        pushEventLocked(ev);
    }
}

void InputEngine::onCursorAbsolute(float normX, float normY) {
    std::lock_guard<std::mutex> lock(mMutex);
    mMouse.cursorX = std::max(0.0f, std::min(1.0f, normX));
    mMouse.cursorY = std::max(0.0f, std::min(1.0f, normY));
    InputEvent ev{};
    ev.type = EventType::MouseMoveAbs;
    ev.absX = mMouse.cursorX;
    ev.absY = mMouse.cursorY;
    pushEventLocked(ev);
}

void InputEngine::setMouseButton(uint8_t buttonIndex, bool pressed) {
    if (buttonIndex > 2) return;
    std::lock_guard<std::mutex> lock(mMutex);
    uint8_t bit = static_cast<uint8_t>(1u << buttonIndex);
    bool wasDown = (mMouse.buttonsMask & bit) != 0;
    if (pressed == wasDown) return;
    if (pressed) mMouse.buttonsMask |= bit;
    else mMouse.buttonsMask &= static_cast<uint8_t>(~bit);

    InputEvent ev{};
    ev.type = pressed ? EventType::MouseButtonDown : EventType::MouseButtonUp;
    ev.vkCode = (buttonIndex == 0) ? VK::LBUTTON : ((buttonIndex == 1) ? VK::RBUTTON : VK::MBUTTON);
    pushEventLocked(ev);
}

void InputEngine::onMouseWheel(int32_t delta) {
    if (delta == 0) return;
    std::lock_guard<std::mutex> lock(mMutex);
    mMouse.wheelAccum += delta;
    InputEvent ev{};
    ev.type = EventType::MouseWheel;
    ev.wheelDelta = delta;
    pushEventLocked(ev);
}

void InputEngine::releaseAllKeys() {
    std::lock_guard<std::mutex> lock(mMutex);
    for (uint16_t vk = 0; vk < 256; ++vk) {
        if (mKeyRefCount[vk] > 0) {
            mKeyRefCount[vk] = 0;
            InputEvent ev{};
            ev.type = EventType::KeyUp;
            ev.vkCode = vk;
            ev.dikCode = vkToDik(vk);
            pushEventLocked(ev);
        }
    }
    mStickW = mStickA = mStickS = mStickD = false;
    for (uint8_t b = 0; b < 3; ++b) {
        uint8_t bit = static_cast<uint8_t>(1u << b);
        if (mMouse.buttonsMask & bit) {
            mMouse.buttonsMask &= static_cast<uint8_t>(~bit);
            InputEvent ev{};
            ev.type = EventType::MouseButtonUp;
            ev.vkCode = (b == 0) ? VK::LBUTTON : ((b == 1) ? VK::RBUTTON : VK::MBUTTON);
            pushEventLocked(ev);
        }
    }
}

std::array<uint8_t, 256> InputEngine::snapshotDirectInputKeys() const {
    std::lock_guard<std::mutex> lock(mMutex);
    std::array<uint8_t, 256> dik{};
    for (uint16_t vk = 0; vk < 256; ++vk) {
        if (mKeyRefCount[vk] > 0) {
            uint8_t sc = vkToDik(vk);
            if (sc > 0) dik[sc] = 0x80;
        }
    }
    return dik;
}

MouseState InputEngine::consumeMouseState() {
    std::lock_guard<std::mutex> lock(mMutex);
    MouseState snap = mMouse;
    mMouse.relAccumX = 0.0f;
    mMouse.relAccumY = 0.0f;
    mMouse.wheelAccum = 0;
    return snap;
}

bool InputEngine::popEvent(InputEvent& outEvent) {
    std::lock_guard<std::mutex> lock(mMutex);
    if (mQueue.empty()) return false;
    outEvent = mQueue.front();
    mQueue.pop_front();
    return true;
}

uint8_t InputEngine::vkToDik(uint16_t vk) {
    switch (vk) {
        case VK::ESCAPE:  return 0x01;
        case VK::KEY_1:   return 0x02;
        case 0x32:        return 0x03;
        case 0x33:        return 0x04;
        case 0x34:        return 0x05;
        case 0x35:        return 0x06;
        case 0x36:        return 0x07;
        case 0x37:        return 0x08;
        case 0x38:        return 0x09;
        case VK::KEY_9:   return 0x0A;
        case VK::TAB:     return 0x0F;
        case VK::KEY_Q:   return 0x10;
        case VK::KEY_W:   return 0x11;
        case VK::KEY_E:   return 0x12;
        case VK::KEY_R:   return 0x13;
        case VK::KEY_T:   return 0x14;
        case VK::RETURN:  return 0x1C;
        case VK::CONTROL: return 0x1D;
        case VK::KEY_A:   return 0x1E;
        case VK::KEY_S:   return 0x1F;
        case VK::KEY_D:   return 0x20;
        case VK::KEY_F:   return 0x21;
        case VK::SHIFT:   return 0x2A;
        case VK::KEY_V:   return 0x2F;
        case VK::SPACE:   return 0x39;
        case VK::F5:      return 0x3F;
        case VK::F9:      return 0x43;
        default:          return 0x00;
    }
}

} // namespace fnv3::input
