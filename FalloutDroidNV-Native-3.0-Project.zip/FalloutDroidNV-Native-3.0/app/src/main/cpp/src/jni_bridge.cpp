#include "fnv3/engine_core.hpp"
#include <jni.h>
#include <android/native_window_jni.h>
#include <memory>
#include <sstream>

namespace {
std::unique_ptr<fnv3::NativeEngineCore> gEngine;

fnv3::NativeEngineCore& engine() {
    if (!gEngine) gEngine = std::make_unique<fnv3::NativeEngineCore>();
    return *gEngine;
}
} // namespace

extern "C" {

JNIEXPORT jboolean JNICALL
Java_com_rommy_falloutdroid_nv3_nativebridge_NativeEngine_nativeInitAudio(JNIEnv*, jobject) {
    return engine().initializeAudio() ? JNI_TRUE : JNI_FALSE;
}

JNIEXPORT void JNICALL
Java_com_rommy_falloutdroid_nv3_nativebridge_NativeEngine_nativeSetMasterVolume(JNIEnv*, jobject, jfloat vol) {
    engine().mixer().setMasterVolume(vol);
}

JNIEXPORT void JNICALL
Java_com_rommy_falloutdroid_nv3_nativebridge_NativeEngine_nativeSetCategoryVolume(JNIEnv*, jobject, jint cat, jfloat vol) {
    if (cat >= 0 && cat < static_cast<jint>(fnv3::audio::AudioCategory::Count)) {
        engine().mixer().setCategoryVolume(static_cast<fnv3::audio::AudioCategory>(cat), vol);
    }
}

JNIEXPORT void JNICALL
Java_com_rommy_falloutdroid_nv3_nativebridge_NativeEngine_nativeTriggerAudioTest(JNIEnv*, jobject, jint cat, jfloat freqHz, jint durationMs) {
    if (cat >= 0 && cat < static_cast<jint>(fnv3::audio::AudioCategory::Count)) {
        engine().runAudioSelfTestTone(static_cast<fnv3::audio::AudioCategory>(cat), freqHz, static_cast<uint32_t>(durationMs));
    }
}

JNIEXPORT jstring JNICALL
Java_com_rommy_falloutdroid_nv3_nativebridge_NativeEngine_nativeGetAudioDiagnosticsJson(JNIEnv* env, jobject) {
    auto d = engine().mixer().getDiagnostics();
    std::ostringstream os;
    os << "{"
       << "\"sampleRate\":" << d.sampleRate << ","
       << "\"activeChannels\":" << d.activeChannels << ","
       << "\"activeSources\":" << d.activeSources << ","
       << "\"totalPcmFrames\":" << d.totalPcmFrames << ","
       << "\"underrunCount\":" << d.underrunCount << ","
       << "\"nanSanitizedCount\":" << d.nanSanitizedCount << ","
       << "\"peakLevel\":" << d.peakLevel << ","
       << "\"rmsLevel\":" << d.rmsLevel << ","
       << "\"mixerRunning\":" << (d.mixerRunning ? "true" : "false") << ","
       << "\"oboeConnected\":" << (d.oboeConnected ? "true" : "false") << ","
       << "\"backendState\":\"" << d.backendState << "\","
       << "\"lastError\":\"" << d.lastError << "\""
       << "}";
    return env->NewStringUTF(os.str().c_str());
}

JNIEXPORT void JNICALL
Java_com_rommy_falloutdroid_nv3_nativebridge_NativeEngine_nativeSetInputMode(JNIEnv*, jobject, jint mode) {
    engine().input().setMode(mode == 1 ? fnv3::input::InputMode::Menu : fnv3::input::InputMode::Gameplay);
}

JNIEXPORT void JNICALL
Java_com_rommy_falloutdroid_nv3_nativebridge_NativeEngine_nativeSetMouseConfig(JNIEnv*, jobject, jfloat sens, jboolean invX, jboolean invY) {
    engine().input().setMouseConfig(sens, invX == JNI_TRUE, invY == JNI_TRUE);
}

JNIEXPORT void JNICALL
Java_com_rommy_falloutdroid_nv3_nativebridge_NativeEngine_nativeKeyEvent(JNIEnv*, jobject, jint vkCode, jboolean pressed) {
    engine().input().setKeyState(static_cast<uint16_t>(vkCode), pressed == JNI_TRUE);
}

JNIEXPORT void JNICALL
Java_com_rommy_falloutdroid_nv3_nativebridge_NativeEngine_nativeWasdStick(JNIEnv*, jobject, jfloat nx, jfloat ny, jfloat deadZone) {
    engine().input().setWasdStick(nx, ny, deadZone);
}

JNIEXPORT void JNICALL
Java_com_rommy_falloutdroid_nv3_nativebridge_NativeEngine_nativeTouchpadDelta(JNIEnv*, jobject, jfloat dx, jfloat dy) {
    engine().input().onTouchpadDelta(dx, dy);
}

JNIEXPORT void JNICALL
Java_com_rommy_falloutdroid_nv3_nativebridge_NativeEngine_nativeMouseButton(JNIEnv*, jobject, jint btn, jboolean pressed) {
    engine().input().setMouseButton(static_cast<uint8_t>(btn), pressed == JNI_TRUE);
}

JNIEXPORT void JNICALL
Java_com_rommy_falloutdroid_nv3_nativebridge_NativeEngine_nativeMouseWheel(JNIEnv*, jobject, jint delta) {
    engine().input().onMouseWheel(delta);
}

JNIEXPORT void JNICALL
Java_com_rommy_falloutdroid_nv3_nativebridge_NativeEngine_nativeReleaseAllInput(JNIEnv*, jobject) {
    engine().input().releaseAllKeys();
}

JNIEXPORT jstring JNICALL
Java_com_rommy_falloutdroid_nv3_nativebridge_NativeEngine_nativeMountGameDir(JNIEnv* env, jobject, jstring jPath) {
    const char* p = env->GetStringUTFChars(jPath, nullptr);
    fnv3::fs::GameDataReport rep{};
    bool ok = engine().mountGameDirectory(p ? p : "", rep);
    env->ReleaseStringUTFChars(jPath, p);
    std::ostringstream os;
    os << "{\"ok\":" << (ok ? "true" : "false")
       << ",\"hasExe\":" << (rep.hasExecutable ? "true" : "false")
       << ",\"hasEsm\":" << (rep.hasFalloutNvEsm ? "true" : "false")
       << ",\"hasSoundBsa\":" << (rep.hasSoundBsa ? "true" : "false")
       << ",\"hasVoicesBsa\":" << (rep.hasVoicesBsa ? "true" : "false")
       << ",\"bsaCount\":" << rep.bsaCount
       << ",\"dlcCount\":" << rep.dlcCount << "}";
    return env->NewStringUTF(os.str().c_str());
}

JNIEXPORT jboolean JNICALL
Java_com_rommy_falloutdroid_nv3_nativebridge_NativeEngine_nativeAttachSurface(JNIEnv* env, jobject, jobject surface) {
    std::string err;
    if (!engine().renderer().status().initialized) {
        if (!engine().renderer().initialize(err)) return JNI_FALSE;
    }
    ANativeWindow* win = ANativeWindow_fromSurface(env, surface);
    bool ok = engine().renderer().attachSurface(win, err);
    if (win) ANativeWindow_release(win);
    return ok ? JNI_TRUE : JNI_FALSE;
}

JNIEXPORT void JNICALL
Java_com_rommy_falloutdroid_nv3_nativebridge_NativeEngine_nativeDetachSurface(JNIEnv*, jobject) {
    engine().renderer().detachSurface();
}

} // extern "C"
