#include "fnv3/oboe_backend.hpp"

namespace fnv3::audio {

OboeAudioBackend::OboeAudioBackend(AudioMixer& mixer) : mMixer(mixer) {}

OboeAudioBackend::~OboeAudioBackend() {
    stop();
}

bool OboeAudioBackend::start() {
#if defined(__ANDROID__) && !defined(FNV_HOST_TEST)
    if (mRunning) return true;

    oboe::AudioStreamBuilder builder;
    builder.setDirection(oboe::Direction::Output)
           ->setSharingMode(oboe::SharingMode::Shared)
           ->setPerformanceMode(oboe::PerformanceMode::None) // Safe across speakers & Bluetooth without xrun dropouts
           ->setFormat(oboe::AudioFormat::Float)
           ->setChannelCount(oboe::ChannelCount::Stereo)
           ->setSampleRate(48000)
           ->setUsage(oboe::Usage::Media)
           ->setContentType(oboe::ContentType::Music)
           ->setDataCallback(this)
           ->setErrorCallback(this);

    oboe::Result res = builder.openStream(mStream);
    if (res != oboe::Result::OK || !mStream) {
        mMixer.setBackendStatus(false, false, "OPEN_FAILED", oboe::convertToText(res));
        return false;
    }

    mActualSampleRate = static_cast<uint32_t>(mStream->getSampleRate());
    // Set buffer size to 2x framesPerBurst to avoid underruns on Android 10-17
    int32_t burst = mStream->getFramesPerBurst();
    if (burst > 0) {
        mStream->setBufferSizeInFrames(burst * 2);
    }

    res = mStream->requestStart();
    if (res != oboe::Result::OK) {
        mMixer.setBackendStatus(false, false, "START_FAILED", oboe::convertToText(res));
        mStream->close();
        mStream.reset();
        return false;
    }

    mRunning = true;
    const char* apiName = (mStream->getAudioApi() == oboe::AudioApi::AAudio) ? "OBOE_AAUDIO_RUNNING" : "OBOE_OPENSLES_RUNNING";
    mMixer.setBackendStatus(true, true, apiName, "");
    return true;
#else
    mRunning = true;
    mMixer.setBackendStatus(true, false, "HOST_OFFLINE_MIXER", "");
    return true;
#endif
}

void OboeAudioBackend::stop() {
#if defined(__ANDROID__) && !defined(FNV_HOST_TEST)
    if (mStream) {
        mStream->requestStop();
        mStream->close();
        mStream.reset();
    }
#endif
    mRunning = false;
    mMixer.setBackendStatus(false, false, "STOPPED", "");
}

#if defined(__ANDROID__) && !defined(FNV_HOST_TEST)
oboe::DataCallbackResult OboeAudioBackend::onAudioReady(oboe::AudioStream* audioStream,
                                                        void* audioData,
                                                        int32_t numFrames) {
    if (audioStream) {
        auto xr = audioStream->getXRunCount();
        if (xr && xr.value() > 0) mMixer.recordUnderrun();
    }
    mMixer.mixFrames(static_cast<float*>(audioData), static_cast<uint32_t>(numFrames));
    return oboe::DataCallbackResult::Continue;
}

void OboeAudioBackend::onErrorAfterClose(oboe::AudioStream*, oboe::Result error) {
    mRunning = false;
    mMixer.setBackendStatus(false, false, "DISCONNECTED_RESTARTING", oboe::convertToText(error));
    if (error == oboe::Result::ErrorDisconnected) {
        // Automatically re-route when headphones / Bluetooth audio connect or disconnect
        start();
    }
}
#endif

} // namespace fnv3::audio
