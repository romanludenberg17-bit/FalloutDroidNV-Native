#include "fnv3/pe_loader.hpp"
#include <algorithm>
#include <cstring>
#include <fstream>

namespace fnv3::core {

namespace {
uint16_t u16(const std::vector<uint8_t>& d, size_t o) {
    uint16_t v = 0; std::memcpy(&v, d.data() + o, 2); return v;
}
uint32_t u32(const std::vector<uint8_t>& d, size_t o) {
    uint32_t v = 0; std::memcpy(&v, d.data() + o, 4); return v;
}
std::string readCstr(const std::vector<uint8_t>& d, size_t o) {
    std::string s;
    while (o < d.size() && d[o] != 0) s.push_back(static_cast<char>(d[o++]));
    return s;
}
} // namespace

uint32_t PeLoader::rvaToFileOffset(const PeImage& img, uint32_t rva) {
    if (rva < img.sizeOfHeaders) return rva;
    for (const auto& s : img.sections) {
        uint32_t span = std::max(s.virtualSize, s.rawSize);
        if (rva >= s.virtualAddress && rva < s.virtualAddress + span) {
            uint32_t off = s.rawOffset + (rva - s.virtualAddress);
            return (off < img.rawBytes.size()) ? off : 0xFFFFFFFFu;
        }
    }
    return 0xFFFFFFFFu;
}

bool PeLoader::parseFile(const std::string& path, PeImage& outImage, std::string& outError) {
    std::ifstream f(path, std::ios::binary | std::ios::ate);
    if (!f) { outError = "Cannot open PE file: " + path; return false; }
    auto sz = f.tellg();
    if (sz < 0x100) { outError = "PE file too small"; return false; }
    f.seekg(0, std::ios::beg);
    std::vector<uint8_t> data(static_cast<size_t>(sz));
    if (!f.read(reinterpret_cast<char*>(data.data()), sz)) {
        outError = "Failed reading PE file";
        return false;
    }
    return parseBuffer(data, outImage, outError);
}

bool PeLoader::parseBuffer(const std::vector<uint8_t>& data, PeImage& outImage, std::string& outError) {
    if (data.size() < 0x100 || data[0] != 'M' || data[1] != 'Z') {
        outError = "Invalid MZ DOS signature";
        return false;
    }
    uint32_t peOff = u32(data, 0x3C);
    if (peOff + 24 + 224 > data.size() || std::memcmp(data.data() + peOff, "PE\0\0", 4) != 0) {
        outError = "Invalid PE\\0\\0 signature";
        return false;
    }
    uint16_t machine = u16(data, peOff + 4);
    if (machine != 0x014C) {
        outError = "Expected x86 (i386) PE32 executable";
        return false;
    }
    uint16_t numSections = u16(data, peOff + 6);
    uint16_t optSize = u16(data, peOff + 20);
    size_t optOff = peOff + 24;
    if (u16(data, optOff) != 0x010B) {
        outError = "Expected PE32 optional header (0x10B)";
        return false;
    }

    outImage = PeImage{};
    outImage.entryPointRva = u32(data, optOff + 16);
    outImage.imageBase     = u32(data, optOff + 28);
    outImage.sizeOfImage   = u32(data, optOff + 56);
    outImage.sizeOfHeaders = u32(data, optOff + 60);
    outImage.rawBytes      = data;

    size_t secOff = optOff + optSize;
    for (uint16_t i = 0; i < numSections; ++i) {
        size_t o = secOff + i * 40;
        if (o + 40 > data.size()) break;
        PeSection s{};
        char nm[9]{};
        std::memcpy(nm, data.data() + o, 8);
        s.name = nm;
        s.virtualSize     = u32(data, o + 8);
        s.virtualAddress  = u32(data, o + 12);
        s.rawSize         = u32(data, o + 16);
        s.rawOffset       = u32(data, o + 20);
        s.characteristics = u32(data, o + 36);
        outImage.sections.push_back(std::move(s));
    }

    // DataDirectory[0]: Export Directory (@ optOff + 96)
    uint32_t expRva  = u32(data, optOff + 96);
    uint32_t expSize = u32(data, optOff + 100);
    if (expRva != 0 && expSize != 0) {
        uint32_t expOff = rvaToFileOffset(outImage, expRva);
        if (expOff != 0xFFFFFFFFu && expOff + 40 <= data.size()) {
            uint32_t ordBase   = u32(data, expOff + 16);
            uint32_t numFuncs  = u32(data, expOff + 20);
            uint32_t numNames  = u32(data, expOff + 24);
            uint32_t funcsRva  = u32(data, expOff + 28);
            uint32_t namesRva  = u32(data, expOff + 32);
            uint32_t ordsRva   = u32(data, expOff + 36);

            uint32_t funcsOff = rvaToFileOffset(outImage, funcsRva);
            uint32_t namesOff = rvaToFileOffset(outImage, namesRva);
            uint32_t ordsOff  = rvaToFileOffset(outImage, ordsRva);

            if (funcsOff != 0xFFFFFFFFu) {
                std::vector<std::string> idxToName(numFuncs);
                if (namesOff != 0xFFFFFFFFu && ordsOff != 0xFFFFFFFFu) {
                    for (uint32_t i = 0; i < numNames; ++i) {
                        if (namesOff + i * 4 + 4 > data.size() || ordsOff + i * 2 + 2 > data.size()) break;
                        uint32_t nRva = u32(data, namesOff + i * 4);
                        uint16_t ordIdx = u16(data, ordsOff + i * 2);
                        uint32_t nOff = rvaToFileOffset(outImage, nRva);
                        if (ordIdx < numFuncs && nOff != 0xFFFFFFFFu) {
                            idxToName[ordIdx] = readCstr(data, nOff);
                        }
                    }
                }
                for (uint32_t i = 0; i < numFuncs; ++i) {
                    if (funcsOff + i * 4 + 4 > data.size()) break;
                    uint32_t fnRva = u32(data, funcsOff + i * 4);
                    if (fnRva == 0) continue;
                    PeExport ex{};
                    ex.name = idxToName[i];
                    ex.ordinal = static_cast<uint16_t>(ordBase + i);
                    ex.rva = fnRva;
                    // Forwarded export: RVA falls inside [expRva, expRva + expSize)
                    if (fnRva >= expRva && fnRva < expRva + expSize) {
                        ex.isForwarded = true;
                        uint32_t fOff = rvaToFileOffset(outImage, fnRva);
                        if (fOff != 0xFFFFFFFFu) ex.forwardTarget = readCstr(data, fOff);
                    }
                    outImage.exports.push_back(std::move(ex));
                }
            }
        }
    }

    // DataDirectory[1]: Import Directory (@ optOff + 104)
    uint32_t importRva = u32(data, optOff + 104);
    if (importRva != 0) {
        uint32_t impOff = rvaToFileOffset(outImage, importRva);
        while (impOff != 0xFFFFFFFFu && impOff + 20 <= data.size()) {
            uint32_t origFirstThunk = u32(data, impOff + 0);
            uint32_t nameRva        = u32(data, impOff + 12);
            uint32_t firstThunk     = u32(data, impOff + 16);
            if (origFirstThunk == 0 && nameRva == 0 && firstThunk == 0) break;

            uint32_t dllOff = rvaToFileOffset(outImage, nameRva);
            std::string dllName = (dllOff < data.size()) ? readCstr(data, dllOff) : "";
            if (!dllName.empty() && std::find(outImage.dependencies.begin(), outImage.dependencies.end(), dllName) == outImage.dependencies.end()) {
                outImage.dependencies.push_back(dllName);
            }
            uint32_t thunkRva = origFirstThunk ? origFirstThunk : firstThunk;
            uint32_t thunkOff = rvaToFileOffset(outImage, thunkRva);
            uint32_t iatCur = firstThunk;

            while (thunkOff != 0xFFFFFFFFu && thunkOff + 4 <= data.size()) {
                uint32_t thunkVal = u32(data, thunkOff);
                if (thunkVal == 0) break;
                PeImport imp{};
                imp.dllName = dllName;
                imp.iatRva = iatCur;
                if (thunkVal & 0x80000000u) {
                    imp.byOrdinal = true;
                    imp.ordinal = static_cast<uint16_t>(thunkVal & 0xFFFFu);
                } else {
                    uint32_t hintOff = rvaToFileOffset(outImage, thunkVal);
                    if (hintOff != 0xFFFFFFFFu && hintOff + 2 < data.size()) {
                        imp.ordinal = u16(data, hintOff);
                        imp.funcName = readCstr(data, hintOff + 2);
                    }
                }
                outImage.imports.push_back(std::move(imp));
                thunkOff += 4;
                iatCur += 4;
            }
            impOff += 20;
        }
    }

    // DataDirectory[5]: Base Relocation Table (@ optOff + 136)
    uint32_t relocRva  = u32(data, optOff + 136);
    uint32_t relocSize = u32(data, optOff + 140);
    if (relocRva != 0 && relocSize >= 8) {
        uint32_t relOff = rvaToFileOffset(outImage, relocRva);
        uint32_t consumed = 0;
        while (relOff != 0xFFFFFFFFu && consumed + 8 <= relocSize && relOff + consumed + 8 <= data.size()) {
            uint32_t pageRva = u32(data, relOff + consumed);
            uint32_t blkSize = u32(data, relOff + consumed + 4);
            if (blkSize < 8) break;
            uint32_t count = (blkSize - 8) / 2;
            for (uint32_t i = 0; i < count; ++i) {
                size_t eo = relOff + consumed + 8 + i * 2;
                if (eo + 2 > data.size()) break;
                uint16_t entry = u16(data, eo);
                uint8_t rtype = static_cast<uint8_t>(entry >> 12);
                uint16_t roff = static_cast<uint16_t>(entry & 0x0FFFu);
                if (rtype != 0) {
                    outImage.relocations.push_back({pageRva + roff, rtype});
                }
            }
            consumed += blkSize;
        }
    }
    return true;
}

bool PeLoader::applyRelocations(const PeImage& img, uint32_t loadedBase, std::vector<uint8_t>& mappedImage) {
    int32_t delta = static_cast<int32_t>(loadedBase) - static_cast<int32_t>(img.imageBase);
    if (delta == 0) return true;
    for (const auto& r : img.relocations) {
        if (r.type == 3) { // IMAGE_REL_BASED_HIGHLOW
            if (r.rva + 4 > mappedImage.size()) return false;
            uint32_t val = 0;
            std::memcpy(&val, mappedImage.data() + r.rva, 4);
            val = static_cast<uint32_t>(static_cast<int32_t>(val) + delta);
            std::memcpy(mappedImage.data() + r.rva, &val, 4);
        }
    }
    return true;
}

const PeExport* PeLoader::findExportByName(const PeImage& img, const std::string& name) {
    for (const auto& e : img.exports) {
        if (!e.name.empty() && e.name == name) return &e;
    }
    return nullptr;
}

const PeExport* PeLoader::findExportByOrdinal(const PeImage& img, uint16_t ordinal) {
    for (const auto& e : img.exports) {
        if (e.ordinal == ordinal) return &e;
    }
    return nullptr;
}

} // namespace fnv3::core
