#include "fnv3/unicorn_cpu.hpp"
#include <algorithm>
#include <cstring>

namespace fnv3::cpu {

UnicornCpuBackend::UnicornCpuBackend(win32::Win32CompatLayer& win32) : mWin32(win32) {}

UnicornCpuBackend::~UnicornCpuBackend() {
    shutdown();
}

bool UnicornCpuBackend::initialize(std::string& outError) {
#if !defined(FNV_HOST_TEST)
    if (mInitialized) return true;
    uc_err err = uc_open(UC_ARCH_X86, UC_MODE_32, &mUc);
    if (err != UC_ERR_OK) {
        outError = std::string("uc_open failed: ") + uc_strerror(err);
        return false;
    }
    // Map Win32 stack (2 MB @ 0x00100000) and API stub page (1 MB @ 0x7F000000)
    err = uc_mem_map(mUc, 0x00100000u, 2u * 1024u * 1024u, UC_PROT_READ | UC_PROT_WRITE);
    if (err != UC_ERR_OK) { outError = "Failed mapping x86 stack"; return false; }

    err = uc_mem_map(mUc, win32::Win32CompatLayer::kStubBase, 1024u * 1024u, UC_PROT_READ | UC_PROT_EXEC);
    if (err != UC_ERR_OK) { outError = "Failed mapping Win32 stub trampoline page"; return false; }

    // Register code hook on stub page so every IAT call dispatches into Win32CompatLayer
    uc_hook_add(mUc, &mStubHook, UC_HOOK_CODE, reinterpret_cast<void*>(&UnicornCpuBackend::onStubCode),
                this, win32::Win32CompatLayer::kStubBase, win32::Win32CompatLayer::kStubBase + 1024u * 1024u - 1u);

    uint32_t initEsp = 0x002FF000u;
    uc_reg_write(mUc, UC_X86_REG_ESP, &initEsp);
    mInitialized = true;
    return true;
#else
    (void)outError;
    mInitialized = true;
    return true;
#endif
}

bool UnicornCpuBackend::loadPeImage(const core::PeImage& image, std::string& outError) {
    if (!mInitialized) { outError = "CPU not initialized"; return false; }
    mEip = image.imageBase + image.entryPointRva;
#if !defined(FNV_HOST_TEST)
    uint32_t alignedSize = (image.sizeOfImage + 4095u) & ~4095u;
    uc_err err = uc_mem_map(mUc, image.imageBase, alignedSize, UC_PROT_ALL);
    if (err != UC_ERR_OK) {
        outError = std::string("uc_mem_map image failed: ") + uc_strerror(err);
        return false;
    }
    // Map PE headers & sections
    uc_mem_write(mUc, image.imageBase, image.rawBytes.data(), std::min<size_t>(image.sizeOfHeaders, image.rawBytes.size()));
    for (const auto& s : image.sections) {
        if (s.rawSize > 0 && s.rawOffset + s.rawSize <= image.rawBytes.size()) {
            uc_mem_write(mUc, image.imageBase + s.virtualAddress, image.rawBytes.data() + s.rawOffset, s.rawSize);
        }
    }
    // Patch IAT entries with Win32CompatLayer trampoline addresses
    for (const auto& imp : image.imports) {
        uint32_t stubAddr = mWin32.registerImportStub(imp.dllName, imp.funcName);
        uc_mem_write(mUc, image.imageBase + imp.iatRva, &stubAddr, 4);
    }
    uc_reg_write(mUc, UC_X86_REG_EIP, &mEip);
#else
    for (const auto& imp : image.imports) {
        mWin32.registerImportStub(imp.dllName, imp.funcName);
    }
    (void)outError;
#endif
    return true;
}

bool UnicornCpuBackend::stepInstructions(uint64_t maxInstructions, std::string& outError) {
#if !defined(FNV_HOST_TEST)
    if (!mInitialized || !mUc) { outError = "CPU not initialized"; return false; }
    uc_err err = uc_emu_start(mUc, mEip, 0, 0, maxInstructions);
    uc_reg_read(mUc, UC_X86_REG_EIP, &mEip);
    if (err != UC_ERR_OK) {
        outError = std::string("uc_emu_start stopped: ") + uc_strerror(err);
        return false;
    }
    return true;
#else
    (void)maxInstructions;
    (void)outError;
    return mInitialized;
#endif
}

void UnicornCpuBackend::shutdown() {
#if !defined(FNV_HOST_TEST)
    if (mUc) {
        uc_close(mUc);
        mUc = nullptr;
    }
#endif
    mInitialized = false;
}

#if !defined(FNV_HOST_TEST)
void UnicornCpuBackend::onStubCode(uc_engine* uc, uint64_t address, uint32_t, void* userData) {
    auto* self = static_cast<UnicornCpuBackend*>(userData);
    win32::CpuRegs regs{};
    uc_reg_read(uc, UC_X86_REG_EAX, &regs.eax);
    uc_reg_read(uc, UC_X86_REG_ECX, &regs.ecx);
    uc_reg_read(uc, UC_X86_REG_EDX, &regs.edx);
    uc_reg_read(uc, UC_X86_REG_ESP, &regs.esp);
    regs.eip = static_cast<uint32_t>(address);

    auto readFn = [uc](uint32_t a, void* dst, size_t len) { return uc_mem_read(uc, a, dst, len) == UC_ERR_OK; };
    auto writeFn = [uc](uint32_t a, const void* src, size_t len) { return uc_mem_write(uc, a, src, len) == UC_ERR_OK; };

    self->mWin32.dispatchStub(static_cast<uint32_t>(address), regs, readFn, writeFn);
    uc_reg_write(uc, UC_X86_REG_EAX, &regs.eax);
    uc_reg_write(uc, UC_X86_REG_ESP, &regs.esp);
    uc_reg_write(uc, UC_X86_REG_EIP, &regs.eip);
}
#endif

} // namespace fnv3::cpu
