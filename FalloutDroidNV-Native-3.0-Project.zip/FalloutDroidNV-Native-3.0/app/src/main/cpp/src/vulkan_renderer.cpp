#include "fnv3/vulkan_renderer.hpp"
#include <vector>

namespace fnv3::gfx {

VulkanRenderer::~VulkanRenderer() {
    shutdown();
}

bool VulkanRenderer::initialize(std::string& outError) {
#if defined(__ANDROID__) && !defined(FNV_HOST_TEST)
    VkApplicationInfo appInfo{};
    appInfo.sType = VK_STRUCTURE_TYPE_APPLICATION_INFO;
    appInfo.pApplicationName = "FalloutDroidNV-Native-3.0";
    appInfo.applicationVersion = VK_MAKE_VERSION(3, 0, 0);
    appInfo.apiVersion = VK_API_VERSION_1_1;

    const char* exts[] = { VK_KHR_SURFACE_EXTENSION_NAME, VK_KHR_ANDROID_SURFACE_EXTENSION_NAME };
    VkInstanceCreateInfo ci{};
    ci.sType = VK_STRUCTURE_TYPE_INSTANCE_CREATE_INFO;
    ci.pApplicationInfo = &appInfo;
    ci.enabledExtensionCount = 2;
    ci.ppEnabledExtensionNames = exts;

    if (vkCreateInstance(&ci, nullptr, &mInstance) != VK_SUCCESS) {
        outError = "vkCreateInstance failed";
        mStatus.lastError = outError;
        return false;
    }

    uint32_t devCount = 0;
    vkEnumeratePhysicalDevices(mInstance, &devCount, nullptr);
    if (devCount == 0) {
        outError = "No Vulkan physical devices found";
        mStatus.lastError = outError;
        return false;
    }
    std::vector<VkPhysicalDevice> devs(devCount);
    vkEnumeratePhysicalDevices(mInstance, &devCount, devs.data());
    mPhysicalDevice = devs[0];

    VkPhysicalDeviceProperties props{};
    vkGetPhysicalDeviceProperties(mPhysicalDevice, &props);
    mStatus.gpuName = props.deviceName;
    mStatus.initialized = true;
    return true;
#else
    (void)outError;
    mStatus.initialized = true;
    mStatus.gpuName = "HOST_HEADLESS_VULKAN_SKIP";
    return true;
#endif
}

#if defined(__ANDROID__) && !defined(FNV_HOST_TEST)
bool VulkanRenderer::attachSurface(ANativeWindow* window, std::string& outError) {
    if (!mStatus.initialized || !window) {
        outError = "Vulkan not initialized or null window";
        return false;
    }
    VkAndroidSurfaceCreateInfoKHR sci{};
    sci.sType = VK_STRUCTURE_TYPE_ANDROID_SURFACE_CREATE_INFO_KHR;
    sci.window = window;
    if (vkCreateAndroidSurfaceKHR(mInstance, &sci, nullptr, &mSurface) != VK_SUCCESS) {
        outError = "vkCreateAndroidSurfaceKHR failed";
        mStatus.lastError = outError;
        return false;
    }
    mStatus.surfaceAttached = true;
    mStatus.width = static_cast<uint32_t>(ANativeWindow_getWidth(window));
    mStatus.height = static_cast<uint32_t>(ANativeWindow_getHeight(window));
    return true;
}
#endif

void VulkanRenderer::detachSurface() {
#if defined(__ANDROID__) && !defined(FNV_HOST_TEST)
    if (mSurface != VK_NULL_HANDLE && mInstance != VK_NULL_HANDLE) {
        vkDestroySurfaceKHR(mInstance, mSurface, nullptr);
        mSurface = VK_NULL_HANDLE;
    }
#endif
    mStatus.surfaceAttached = false;
}

void VulkanRenderer::renderFrame() {
    // Stage 2: Direct3D 9 -> Vulkan draw-call translation pipeline attaches here
}

void VulkanRenderer::shutdown() {
    detachSurface();
#if defined(__ANDROID__) && !defined(FNV_HOST_TEST)
    if (mDevice != VK_NULL_HANDLE) { vkDestroyDevice(mDevice, nullptr); mDevice = VK_NULL_HANDLE; }
    if (mInstance != VK_NULL_HANDLE) { vkDestroyInstance(mInstance, nullptr); mInstance = VK_NULL_HANDLE; }
#endif
    mStatus.initialized = false;
}

} // namespace fnv3::gfx
