#include "fnv3/win32_compat.hpp"
#include <algorithm>
#include <cctype>
#include <chrono>
#include <cstring>
#include <sstream>
#include <thread>
#include <unordered_set>

namespace fnv3::win32 {

namespace {
const std::unordered_set<std::string>& implementedTable() {
    static const std::unordered_set<std::string> kApis = {
        // kernel32.dll
        "kernel32.dll!gettickcount", "kernel32.dll!queryperformancecounter", "kernel32.dll!queryperformancefrequency",
        "kernel32.dll!virtualalloc", "kernel32.dll!virtualfree", "kernel32.dll!getprocessheap",
        "kernel32.dll!heapcreate", "kernel32.dll!heapalloc", "kernel32.dll!heaprealloc", "kernel32.dll!heapfree",
        "kernel32.dll!tlsalloc", "kernel32.dll!tlsfree", "kernel32.dll!tlsgetvalue", "kernel32.dll!tlssetvalue",
        "kernel32.dll!initializecriticalsection", "kernel32.dll!entercriticalsection",
        "kernel32.dll!leavecriticalsection", "kernel32.dll!deletecriticalsection",
        "kernel32.dll!createeventa", "kernel32.dll!createeventw", "kernel32.dll!setevent", "kernel32.dll!resetevent",
        "kernel32.dll!createmutexa", "kernel32.dll!createmutexw", "kernel32.dll!releasemutex",
        "kernel32.dll!waitforsingleobject", "kernel32.dll!createthread", "kernel32.dll!getcurrentthreadid",
        "kernel32.dll!getcurrentprocessid", "kernel32.dll!sleep", "kernel32.dll!closehandle",
        "kernel32.dll!getlasterror", "kernel32.dll!setlasterror",
        "kernel32.dll!createfilea", "kernel32.dll!readfile", "kernel32.dll!writefile",
        "kernel32.dll!setfilepointer", "kernel32.dll!getfilesize", "kernel32.dll!getfileattributesa",
        "kernel32.dll!getenvironmentvariablea", "kernel32.dll!setenvironmentvariablea",
        "kernel32.dll!getmodulehandlea", "kernel32.dll!loadlibrarya", "kernel32.dll!getprocaddress",
        "kernel32.dll!setunhandledexceptionfilter",
        // user32.dll
        "user32.dll!getasynckeystate", "user32.dll!getkeystate", "user32.dll!getcursorpos",
        "user32.dll!showcursor", "user32.dll!peekmessagea", "user32.dll!getsystemmetrics",
        // advapi32.dll
        "advapi32.dll!regopenkeyexa", "advapi32.dll!regcreatekeyexa", "advapi32.dll!regqueryvalueexa",
        "advapi32.dll!regsetvalueexa", "advapi32.dll!regclosekey",
        // ole32.dll & oleaut32.dll
        "ole32.dll!coinitializeex", "ole32.dll!coinitialize", "ole32.dll!couninitialize", "ole32.dll!cocreateinstance",
        "oleaut32.dll!sysallocstring", "oleaut32.dll!sysfreestring",
        // shell32.dll, ws2_32.dll, winmm.dll, version.dll, shlwapi.dll
        "shell32.dll!shgetfolderpatha",
        "ws2_32.dll!wsastartup", "ws2_32.dll!wsacleanup",
        "winmm.dll!timegettime", "winmm.dll!timebeginperiod", "winmm.dll!timeendperiod",
        "version.dll!getfileversioninfosizea", "version.dll!getfileversioninfoa",
        "shlwapi.dll!pathfileexistsa",
        // DirectInput8, DirectSound8, XAudio2
        "dinput8.dll!directinput8create",
        "dsound.dll!directsoundcreate8",
        "xaudio2_7.dll!xaudio2create"
    };
    return kApis;
}
} // namespace

std::string Win32CompatLayer::toLower(const std::string& s) {
    std::string out = s;
    std::transform(out.begin(), out.end(), out.begin(), [](unsigned char c) { return static_cast<char>(std::tolower(c)); });
    return out;
}

Win32CompatLayer::Win32CompatLayer(audio::AudioMixer& mixer, input::InputEngine& input, fs::GameFilesystem& fs)
    : mMixer(mixer), mInput(input), mFs(fs) {
    // Seed default Fallout: New Vegas registry & environment entries
    mRegStore["HKLM\\SOFTWARE\\Bethesda Softworks\\FalloutNV"]["Installed Path"] = "C:\\Games\\FalloutNV\\";
    mEnvVars["USERPROFILE"] = "C:\\Users\\Courier";
    mEnvVars["APPDATA"] = "C:\\Users\\Courier\\AppData\\Roaming";

    // Pre-register known system DLL pseudo-handles
    uint32_t modBase = 0x70000000u;
    for (const char* dll : {"kernel32.dll", "user32.dll", "advapi32.dll", "ole32.dll", "oleaut32.dll",
                            "shell32.dll", "ws2_32.dll", "winmm.dll", "version.dll", "shlwapi.dll",
                            "dinput8.dll", "dsound.dll", "xaudio2_7.dll"}) {
        mLoadedModules[dll] = modBase;
        modBase += 0x00100000u;
    }
}

bool Win32CompatLayer::isApiImplemented(const std::string& dll, const std::string& funcName) const {
    return implementedTable().count(toLower(dll) + "!" + toLower(funcName)) > 0;
}

uint32_t Win32CompatLayer::registerImportStub(const std::string& dll, const std::string& funcName) {
    std::lock_guard<std::mutex> lock(mStateMtx);
    uint32_t addr = mNextStub;
    mNextStub += kStubStride;
    bool impl = isApiImplemented(dll, funcName);
    mStubs[addr] = ApiStubEntry{addr, dll, funcName, impl};
    return addr;
}

core::ImportValidationReport Win32CompatLayer::validateImports(const core::PeImage& image) const {
    core::ImportValidationReport rep{};
    rep.totalImports = image.imports.size();
    for (const auto& imp : image.imports) {
        if (!imp.byOrdinal && isApiImplemented(imp.dllName, imp.funcName)) {
            ++rep.resolvedImports;
        } else {
            std::string desc = imp.dllName + "!" + (imp.byOrdinal ? ("#" + std::to_string(imp.ordinal)) : imp.funcName);
            rep.missingImports.push_back(std::move(desc));
        }
    }
    return rep;
}

uint32_t Win32CompatLayer::tlsAlloc() {
    std::lock_guard<std::mutex> lock(mStateMtx);
    for (uint32_t i = 0; i < mTlsAllocated.size(); ++i) {
        if (!mTlsAllocated[i]) {
            mTlsAllocated[i] = true;
            for (auto& kv : mThreadTls) kv.second[i] = 0;
            return i;
        }
    }
    return 0xFFFFFFFFu; // TLS_OUT_OF_INDEXES
}

bool Win32CompatLayer::tlsFree(uint32_t index) {
    std::lock_guard<std::mutex> lock(mStateMtx);
    if (index >= mTlsAllocated.size() || !mTlsAllocated[index]) return false;
    mTlsAllocated[index] = false;
    return true;
}

bool Win32CompatLayer::tlsSetValue(uint32_t threadId, uint32_t index, uint32_t value) {
    std::lock_guard<std::mutex> lock(mStateMtx);
    if (index >= mTlsAllocated.size() || !mTlsAllocated[index]) return false;
    mThreadTls[threadId][index] = value;
    return true;
}

uint32_t Win32CompatLayer::tlsGetValue(uint32_t threadId, uint32_t index) const {
    std::lock_guard<std::mutex> lock(mStateMtx);
    if (index >= mTlsAllocated.size() || !mTlsAllocated[index]) return 0;
    auto it = mThreadTls.find(threadId);
    return (it != mThreadTls.end()) ? it->second[index] : 0;
}

uint32_t Win32CompatLayer::createEvent(bool manualReset, bool initialState) {
    std::lock_guard<std::mutex> lock(mStateMtx);
    uint32_t h = mNextHandle++;
    auto ev = std::make_shared<Win32Event>();
    ev->manualReset = manualReset;
    ev->signaled = initialState;
    mEvents[h] = std::move(ev);
    return h;
}

bool Win32CompatLayer::setEvent(uint32_t handle) {
    std::shared_ptr<Win32Event> ev;
    {
        std::lock_guard<std::mutex> lock(mStateMtx);
        auto it = mEvents.find(handle);
        if (it == mEvents.end()) return false;
        ev = it->second;
    }
    {
        std::lock_guard<std::mutex> lk(ev->mtx);
        ev->signaled = true;
    }
    ev->cv.notify_all();
    return true;
}

bool Win32CompatLayer::resetEvent(uint32_t handle) {
    std::shared_ptr<Win32Event> ev;
    {
        std::lock_guard<std::mutex> lock(mStateMtx);
        auto it = mEvents.find(handle);
        if (it == mEvents.end()) return false;
        ev = it->second;
    }
    std::lock_guard<std::mutex> lk(ev->mtx);
    ev->signaled = false;
    return true;
}

uint32_t Win32CompatLayer::waitForSingleObject(uint32_t handle, uint32_t timeoutMs) {
    std::shared_ptr<Win32Event> ev;
    std::shared_ptr<Win32Mutex> mtx;
    {
        std::lock_guard<std::mutex> lock(mStateMtx);
        auto ie = mEvents.find(handle);
        if (ie != mEvents.end()) ev = ie->second;
        auto im = mMutexes.find(handle);
        if (im != mMutexes.end()) mtx = im->second;
    }
    if (ev) {
        std::unique_lock<std::mutex> lk(ev->mtx);
        if (!ev->signaled) {
            if (timeoutMs == 0) return 0x00000102u; // WAIT_TIMEOUT
            if (timeoutMs == 0xFFFFFFFFu) {
                ev->cv.wait(lk, [&] { return ev->signaled; });
            } else if (!ev->cv.wait_for(lk, std::chrono::milliseconds(timeoutMs), [&] { return ev->signaled; })) {
                return 0x00000102u; // WAIT_TIMEOUT
            }
        }
        if (!ev->manualReset) ev->signaled = false;
        return 0u; // WAIT_OBJECT_0
    }
    if (mtx) {
        mtx->mtx.lock();
        ++mtx->lockCount;
        return 0u;
    }
    return 0xFFFFFFFFu; // WAIT_FAILED
}

uint32_t Win32CompatLayer::createMutex(bool initialOwner, uint32_t threadId) {
    std::lock_guard<std::mutex> lock(mStateMtx);
    uint32_t h = mNextHandle++;
    auto m = std::make_shared<Win32Mutex>();
    if (initialOwner) {
        m->mtx.lock();
        m->ownerThreadId = threadId;
        m->lockCount = 1;
    }
    mMutexes[h] = std::move(m);
    return h;
}

bool Win32CompatLayer::releaseMutex(uint32_t handle, uint32_t) {
    std::shared_ptr<Win32Mutex> m;
    {
        std::lock_guard<std::mutex> lock(mStateMtx);
        auto it = mMutexes.find(handle);
        if (it == mMutexes.end()) return false;
        m = it->second;
    }
    if (m->lockCount > 0) {
        --m->lockCount;
        m->mtx.unlock();
        return true;
    }
    return false;
}

void Win32CompatLayer::enterCriticalSection(uint32_t csAddr) {
    std::shared_ptr<std::recursive_mutex> cs;
    {
        std::lock_guard<std::mutex> lock(mStateMtx);
        auto& ptr = mCritSecs[csAddr];
        if (!ptr) ptr = std::make_shared<std::recursive_mutex>();
        cs = ptr;
    }
    cs->lock();
}

void Win32CompatLayer::leaveCriticalSection(uint32_t csAddr) {
    std::shared_ptr<std::recursive_mutex> cs;
    {
        std::lock_guard<std::mutex> lock(mStateMtx);
        auto it = mCritSecs.find(csAddr);
        if (it != mCritSecs.end()) cs = it->second;
    }
    if (cs) cs->unlock();
}

uint32_t Win32CompatLayer::heapAlloc(uint32_t size) {
    std::lock_guard<std::mutex> lock(mStateMtx);
    uint32_t aligned = std::max<uint32_t>(16u, (size + 15u) & ~15u);
    for (auto& b : mHeapBlocks) {
        if (b.free && b.size >= aligned) {
            b.free = false;
            return b.addr;
        }
    }
    uint32_t addr = mNextHeapPtr;
    mNextHeapPtr += aligned;
    mHeapBlocks.push_back(HeapBlock{addr, aligned, false});
    return addr;
}

bool Win32CompatLayer::heapFree(uint32_t addr) {
    std::lock_guard<std::mutex> lock(mStateMtx);
    for (auto& b : mHeapBlocks) {
        if (b.addr == addr && !b.free) {
            b.free = true;
            return true;
        }
    }
    return false;
}

bool Win32CompatLayer::regCreateOrOpenKey(const std::string& fullPath, uint32_t& outHandle) {
    std::lock_guard<std::mutex> lock(mStateMtx);
    uint32_t h = mNextHandle++;
    mOpenRegKeys[h] = fullPath;
    mRegStore[fullPath]; // ensure exists
    outHandle = h;
    return true;
}

bool Win32CompatLayer::regSetString(uint32_t hKey, const std::string& name, const std::string& value) {
    std::lock_guard<std::mutex> lock(mStateMtx);
    auto it = mOpenRegKeys.find(hKey);
    if (it == mOpenRegKeys.end()) return false;
    mRegStore[it->second][name] = value;
    return true;
}

bool Win32CompatLayer::regQueryString(uint32_t hKey, const std::string& name, std::string& outValue) const {
    std::lock_guard<std::mutex> lock(mStateMtx);
    auto it = mOpenRegKeys.find(hKey);
    if (it == mOpenRegKeys.end()) return false;
    auto kit = mRegStore.find(it->second);
    if (kit == mRegStore.end()) return false;
    auto vit = kit->second.find(name);
    if (vit == kit->second.end()) return false;
    outValue = vit->second;
    return true;
}

bool Win32CompatLayer::regCloseKey(uint32_t hKey) {
    std::lock_guard<std::mutex> lock(mStateMtx);
    return mOpenRegKeys.erase(hKey) > 0;
}

void Win32CompatLayer::setEnvVar(const std::string& key, const std::string& val) {
    std::lock_guard<std::mutex> lock(mStateMtx);
    mEnvVars[key] = val;
}

bool Win32CompatLayer::getEnvVar(const std::string& key, std::string& outVal) const {
    std::lock_guard<std::mutex> lock(mStateMtx);
    auto it = mEnvVars.find(key);
    if (it == mEnvVars.end()) return false;
    outVal = it->second;
    return true;
}

dinput::DirectInput8* Win32CompatLayer::createDirectInput8() {
    auto* di = new dinput::DirectInput8(mInput, mComReg);
    mComReg.registerObject(di, 12);
    return di;
}

dsound::DirectSound8* Win32CompatLayer::createDirectSound8() {
    auto* ds = new dsound::DirectSound8(mMixer, mComReg, [this](uint32_t evH) { setEvent(evH); });
    mComReg.registerObject(ds, 12);
    return ds;
}

dsound::XAudio2Engine* Win32CompatLayer::createXAudio2() {
    auto* xa = new dsound::XAudio2Engine(mMixer, mComReg);
    mComReg.registerObject(xa, 16);
    return xa;
}

bool Win32CompatLayer::dispatchStub(uint32_t stubAddr, CpuRegs& regs, const MemReadFn& readMem, const MemWriteFn& writeMem) {
    ApiStubEntry entry{};
    {
        std::lock_guard<std::mutex> lock(mStateMtx);
        auto it = mStubs.find(stubAddr);
        if (it == mStubs.end()) return false;
        entry = it->second;
    }

    uint32_t retAddr = 0;
    if (!readMem(regs.esp, &retAddr, 4)) return false;

    auto arg = [&](uint32_t idx) -> uint32_t {
        uint32_t v = 0;
        readMem(regs.esp + 4u * (idx + 1u), &v, 4);
        return v;
    };

    const std::string fn = toLower(entry.name);

    if (fn == "gettickcount" || fn == "timegettime") {
        auto ms = std::chrono::duration_cast<std::chrono::milliseconds>(
                      std::chrono::steady_clock::now().time_since_epoch()).count();
        regs.eax = static_cast<uint32_t>(ms);
        regs.esp += 4;
        regs.eip = retAddr;
        return true;
    }
    if (fn == "getcurrentthreadid") { regs.eax = 1; regs.esp += 4; regs.eip = retAddr; return true; }
    if (fn == "getcurrentprocessid") { regs.eax = 1000; regs.esp += 4; regs.eip = retAddr; return true; }
    if (fn == "getlasterror") { regs.eax = mLastError; regs.esp += 4; regs.eip = retAddr; return true; }
    if (fn == "setlasterror") { mLastError = arg(0); regs.esp += 8; regs.eip = retAddr; return true; }
    if (fn == "getprocessheap") { regs.eax = 0x1F000000u; regs.esp += 4; regs.eip = retAddr; return true; }
    if (fn == "heapalloc") { regs.eax = heapAlloc(arg(2)); regs.esp += 16; regs.eip = retAddr; return true; }
    if (fn == "heapfree") { regs.eax = heapFree(arg(2)) ? 1u : 0u; regs.esp += 16; regs.eip = retAddr; return true; }
    if (fn == "virtualalloc") { regs.eax = heapAlloc(std::max<uint32_t>(4096u, arg(1))); regs.esp += 20; regs.eip = retAddr; return true; }
    if (fn == "virtualfree") { regs.eax = heapFree(arg(0)) ? 1u : 0u; regs.esp += 16; regs.eip = retAddr; return true; }
    if (fn == "tlsalloc") { regs.eax = tlsAlloc(); regs.esp += 4; regs.eip = retAddr; return true; }
    if (fn == "tlsfree") { regs.eax = tlsFree(arg(0)) ? 1u : 0u; regs.esp += 8; regs.eip = retAddr; return true; }
    if (fn == "tlssetvalue") { regs.eax = tlsSetValue(1, arg(0), arg(1)) ? 1u : 0u; regs.esp += 12; regs.eip = retAddr; return true; }
    if (fn == "tlsgetvalue") { regs.eax = tlsGetValue(1, arg(0)); regs.esp += 8; regs.eip = retAddr; return true; }
    if (fn == "entercriticalsection") { enterCriticalSection(arg(0)); regs.esp += 8; regs.eip = retAddr; return true; }
    if (fn == "leavecriticalsection") { leaveCriticalSection(arg(0)); regs.esp += 8; regs.eip = retAddr; return true; }
    if (fn == "initializecriticalsection" || fn == "deletecriticalsection") { regs.esp += 8; regs.eip = retAddr; return true; }
    if (fn == "setunhandledexceptionfilter") {
        uint32_t prev = mUnhandledExceptionFilter;
        mUnhandledExceptionFilter = arg(0);
        regs.eax = prev;
        regs.esp += 8;
        regs.eip = retAddr;
        return true;
    }
    if (fn == "coinitializeex" || fn == "coinitialize") {
        mComInitialized = true;
        regs.eax = 0; // S_OK
        regs.esp += (fn == "coinitializeex") ? 12 : 8;
        regs.eip = retAddr;
        return true;
    }
    if (fn == "couninitialize") { mComInitialized = false; regs.esp += 4; regs.eip = retAddr; return true; }
    if (fn == "wsastartup") { mWsaInitialized = true; regs.eax = 0; regs.esp += 12; regs.eip = retAddr; return true; }
    if (fn == "wsacleanup") { mWsaInitialized = false; regs.eax = 0; regs.esp += 4; regs.eip = retAddr; return true; }
    if (fn == "getasynckeystate" || fn == "getkeystate") {
        regs.eax = mInput.isKeyDown(static_cast<uint16_t>(arg(0))) ? 0x8001u : 0u;
        regs.esp += 8;
        regs.eip = retAddr;
        return true;
    }
    if (fn == "directinput8create") {
        auto* di = createDirectInput8();
        uint32_t ppOut = arg(3);
        if (ppOut != 0) writeMem(ppOut, &di->guestAddress, 4);
        regs.eax = 0;
        regs.esp += 24;
        regs.eip = retAddr;
        return true;
    }
    if (fn == "directsoundcreate8") {
        auto* ds = createDirectSound8();
        uint32_t ppOut = arg(1);
        if (ppOut != 0) writeMem(ppOut, &ds->guestAddress, 4);
        regs.eax = 0;
        regs.esp += 16;
        regs.eip = retAddr;
        return true;
    }
    if (fn == "xaudio2create") {
        auto* xa = createXAudio2();
        uint32_t ppOut = arg(0);
        if (ppOut != 0) writeMem(ppOut, &xa->guestAddress, 4);
        regs.eax = 0;
        regs.esp += 16;
        regs.eip = retAddr;
        return true;
    }

    // Strict honesty: NEVER fake success for unimplemented imports!
    {
        std::lock_guard<std::mutex> lock(mStateMtx);
        if (mMissingRuntimeCalls.size() < 512) {
            mMissingRuntimeCalls.push_back(entry.dll + "!" + entry.name);
        }
    }
    regs.eax = static_cast<uint32_t>(com::E_NOTIMPL_HR);
    regs.esp += 4;
    regs.eip = retAddr;
    return false;
}

std::vector<std::string> Win32CompatLayer::listImplementedApis() const {
    const auto& tbl = implementedTable();
    std::vector<std::string> out(tbl.begin(), tbl.end());
    std::sort(out.begin(), out.end());
    return out;
}

std::string Win32CompatLayer::buildApiReport() const {
    std::ostringstream os;
    auto impl = listImplementedApis();
    os << "Implemented Win32/COM/DX APIs: " << impl.size() << "\n";
    os << "Registered runtime stubs: " << mStubs.size() << "\n";
    os << "Unimplemented calls hit: " << mMissingRuntimeCalls.size() << "\n";
    return os.str();
}

} // namespace fnv3::win32
