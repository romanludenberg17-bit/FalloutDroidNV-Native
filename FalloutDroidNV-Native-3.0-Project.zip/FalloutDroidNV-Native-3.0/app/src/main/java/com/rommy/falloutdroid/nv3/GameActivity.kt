package com.rommy.falloutdroid.nv3

import android.app.Activity
import android.os.Bundle
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.SurfaceHolder
import android.view.SurfaceView
import android.widget.FrameLayout
import com.rommy.falloutdroid.nv3.controls.HardwareInputHandler
import com.rommy.falloutdroid.nv3.controls.LayoutRepository
import com.rommy.falloutdroid.nv3.controls.PcTouchControllerView
import com.rommy.falloutdroid.nv3.nativebridge.NativeEngine

class GameActivity : Activity(), SurfaceHolder.Callback {
    private lateinit var hwInput: HardwareInputHandler

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val profile = LayoutRepository(this).loadProfile("fnv")
        hwInput = HardwareInputHandler(profile.stickDeadZone)
        NativeEngine.nativeSetMouseConfig(profile.mouseSensitivity, profile.invertX, profile.invertY)
        NativeEngine.nativeSetInputMode(0) // Gameplay relative mouse mode

        val root = FrameLayout(this)
        val surfaceView = SurfaceView(this).apply { holder.addCallback(this@GameActivity) }
        val touchController = PcTouchControllerView(this, profile)
        root.addView(surfaceView)
        root.addView(touchController)
        setContentView(root)
    }

    override fun surfaceCreated(holder: SurfaceHolder) {
        NativeEngine.nativeAttachSurface(holder.surface)
    }

    override fun surfaceChanged(holder: SurfaceHolder, format: Int, width: Int, height: Int) {}

    override fun surfaceDestroyed(holder: SurfaceHolder) {
        NativeEngine.nativeDetachSurface()
    }

    override fun onPause() {
        super.onPause()
        NativeEngine.nativeReleaseAllInput()
    }

    override fun dispatchKeyEvent(event: KeyEvent): Boolean {
        if (hwInput.onKeyEvent(event)) return true
        return super.dispatchKeyEvent(event)
    }

    override fun dispatchGenericMotionEvent(event: MotionEvent): Boolean {
        if (hwInput.onGenericMotionEvent(event)) return true
        return super.dispatchGenericMotionEvent(event)
    }
}
