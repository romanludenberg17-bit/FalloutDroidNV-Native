package com.rommy.falloutdroid.nv3

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.runtime.*
import com.rommy.falloutdroid.nv3.controls.LayoutRepository
import com.rommy.falloutdroid.nv3.nativebridge.NativeEngine
import com.rommy.falloutdroid.nv3.ui.FalloutDroid3App
import com.rommy.falloutdroid.nv3.ui.FalloutDroid3Theme

class MainActivity : ComponentActivity() {
    private var gamePathState = mutableStateOf("")
    private var mountJsonState = mutableStateOf("{}")

    private val folderPicker = registerForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri: Uri? ->
        if (uri != null) {
            val resolved = resolveTreeUriToPath(uri)
            gamePathState.value = resolved
            getSharedPreferences("fnv3_cfg", MODE_PRIVATE).edit().putString("gameDir", resolved).apply()
            mountJsonState.value = NativeEngine.nativeMountGameDir(resolved)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val savedDir = getSharedPreferences("fnv3_cfg", MODE_PRIVATE).getString("gameDir", "") ?: ""
        if (savedDir.isNotEmpty()) {
            gamePathState.value = savedDir
            mountJsonState.value = NativeEngine.nativeMountGameDir(savedDir)
        }
        val layoutRepo = LayoutRepository(this)
        setContent {
            FalloutDroid3Theme {
                FalloutDroid3App(
                    gameDirPath = gamePathState.value,
                    mountStatusJson = mountJsonState.value,
                    layoutRepo = layoutRepo,
                    onPickGameFolder = { folderPicker.launch(null) },
                    onLaunchGame = { startActivity(Intent(this, GameActivity::class.java)) }
                )
            }
        }
    }

    private fun resolveTreeUriToPath(uri: Uri): String {
        val decoded = Uri.decode(uri.toString())
        val idx = decoded.indexOf("/tree/")
        if (idx < 0) return decoded
        val spec = decoded.substring(idx + 6)
        return when {
            spec.startsWith("primary:") -> "/storage/emulated/0/" + spec.removePrefix("primary:")
            spec == "primary" -> "/storage/emulated/0"
            spec.contains(":") -> "/storage/" + spec.replaceFirst(":", "/")
            else -> spec
        }
    }
}
