package com.rommy.falloutdroid.nv3.controls

import org.json.JSONArray
import org.json.JSONObject

enum class BindingKind { KEY, MOUSE_BUTTON, MOUSE_WHEEL }

data class PcBinding(
    val kind: BindingKind,
    val code: Int, // Win32 VK_* for KEY, 0/1/2 for MOUSE_BUTTON, +1/-1 for MOUSE_WHEEL
    val label: String
)

data class TouchElementConfig(
    val id: String,
    val label: String,
    val x: Float,      // normalized 0..1
    val y: Float,      // normalized 0..1
    val size: Float,   // scale 0.6..1.8
    val opacity: Float,// 0.2..1.0
    val visible: Boolean,
    val isStick: Boolean = false,
    val binding: PcBinding
)

data class TouchLayoutProfile(
    val profileName: String,
    val gameId: String,
    val stickDeadZone: Float = 0.18f,
    val mouseSensitivity: Float = 1.4f,
    val invertX: Boolean = false,
    val invertY: Boolean = false,
    val elements: List<TouchElementConfig>
) {
    fun toJson(): String {
        val root = JSONObject()
        root.put("profileName", profileName)
        root.put("gameId", gameId)
        root.put("stickDeadZone", stickDeadZone.toDouble())
        root.put("mouseSensitivity", mouseSensitivity.toDouble())
        root.put("invertX", invertX)
        root.put("invertY", invertY)
        val arr = JSONArray()
        for (e in elements) {
            val o = JSONObject()
            o.put("id", e.id)
            o.put("label", e.label)
            o.put("x", e.x.toDouble())
            o.put("y", e.y.toDouble())
            o.put("size", e.size.toDouble())
            o.put("opacity", e.opacity.toDouble())
            o.put("visible", e.visible)
            o.put("isStick", e.isStick)
            o.put("kind", e.binding.kind.name)
            o.put("code", e.binding.code)
            o.put("bindLabel", e.binding.label)
            arr.put(o)
        }
        root.put("elements", arr)
        return root.toString(2)
    }

    companion object {
        val AVAILABLE_BINDINGS = listOf(
            PcBinding(BindingKind.MOUSE_BUTTON, 0, "LMB (Fire)"),
            PcBinding(BindingKind.MOUSE_BUTTON, 1, "RMB (Aim)"),
            PcBinding(BindingKind.MOUSE_WHEEL, 1, "Wheel Up"),
            PcBinding(BindingKind.MOUSE_WHEEL, -1, "Wheel Down"),
            PcBinding(BindingKind.KEY, 0x45, "E (Use/Take)"),
            PcBinding(BindingKind.KEY, 0x20, "SPACE (Jump)"),
            PcBinding(BindingKind.KEY, 0x52, "R (Reload)"),
            PcBinding(BindingKind.KEY, 0x51, "Q (VATS)"),
            PcBinding(BindingKind.KEY, 0x11, "CTRL (Sneak)"),
            PcBinding(BindingKind.KEY, 0x10, "SHIFT (Run)"),
            PcBinding(BindingKind.KEY, 0x09, "TAB (Pip-Boy)"),
            PcBinding(BindingKind.KEY, 0x46, "F (POV)"),
            PcBinding(BindingKind.KEY, 0x1B, "ESC (Menu)"),
            PcBinding(BindingKind.KEY, 0x74, "F5 (Save)"),
            PcBinding(BindingKind.KEY, 0x78, "F9 (Load)"),
            PcBinding(BindingKind.KEY, 0x54, "T (Wait)"),
            PcBinding(BindingKind.KEY, 0x31, "1 (Weapon 1)"),
            PcBinding(BindingKind.KEY, 0x32, "2 (Weapon 2)"),
            PcBinding(BindingKind.KEY, 0x33, "3 (Weapon 3)")
        )

        fun defaultFalloutNvProfile(gameId: String = "fnv"): TouchLayoutProfile = TouchLayoutProfile(
            profileName = "Fallout Droid PC Standard",
            gameId = gameId,
            elements = listOf(
                TouchElementConfig("wasd", "WASD", 0.14f, 0.72f, 1.0f, 0.80f, true, isStick = true, PcBinding(BindingKind.KEY, 0, "WASD")),
                TouchElementConfig("fire", "FIRE", 0.89f, 0.62f, 1.20f, 0.85f, true, binding = PcBinding(BindingKind.MOUSE_BUTTON, 0, "LMB")),
                TouchElementConfig("aim", "AIM", 0.91f, 0.36f, 1.00f, 0.85f, true, binding = PcBinding(BindingKind.MOUSE_BUTTON, 1, "RMB")),
                TouchElementConfig("use", "USE", 0.76f, 0.83f, 0.95f, 0.85f, true, binding = PcBinding(BindingKind.KEY, 0x45, "E")),
                TouchElementConfig("jump", "JUMP", 0.78f, 0.56f, 0.95f, 0.85f, true, binding = PcBinding(BindingKind.KEY, 0x20, "SPACE")),
                TouchElementConfig("reload", "RELOAD", 0.65f, 0.84f, 0.85f, 0.80f, true, binding = PcBinding(BindingKind.KEY, 0x52, "R")),
                TouchElementConfig("vats", "VATS", 0.67f, 0.62f, 0.95f, 0.85f, true, binding = PcBinding(BindingKind.KEY, 0x51, "Q")),
                TouchElementConfig("sneak", "SNEAK", 0.07f, 0.40f, 0.90f, 0.80f, true, binding = PcBinding(BindingKind.KEY, 0x11, "CTRL")),
                TouchElementConfig("run", "RUN", 0.07f, 0.24f, 0.85f, 0.80f, true, binding = PcBinding(BindingKind.KEY, 0x10, "SHIFT")),
                TouchElementConfig("pipboy", "PIP-BOY", 0.93f, 0.13f, 0.95f, 0.85f, true, binding = PcBinding(BindingKind.KEY, 0x09, "TAB")),
                TouchElementConfig("pov", "POV", 0.84f, 0.13f, 0.85f, 0.80f, true, binding = PcBinding(BindingKind.KEY, 0x46, "F")),
                TouchElementConfig("menu", "MENU", 0.12f, 0.13f, 0.85f, 0.80f, true, binding = PcBinding(BindingKind.KEY, 0x1B, "ESC")),
                TouchElementConfig("save", "SAVE", 0.21f, 0.13f, 0.78f, 0.75f, true, binding = PcBinding(BindingKind.KEY, 0x74, "F5")),
                TouchElementConfig("load", "LOAD", 0.30f, 0.13f, 0.78f, 0.75f, true, binding = PcBinding(BindingKind.KEY, 0x78, "F9")),
                TouchElementConfig("wait", "WAIT", 0.75f, 0.13f, 0.78f, 0.75f, true, binding = PcBinding(BindingKind.KEY, 0x54, "T")),
                TouchElementConfig("take", "TAKE", 0.55f, 0.84f, 0.85f, 0.80f, true, binding = PcBinding(BindingKind.KEY, 0x45, "E"))
            )
        )

        fun fromJson(json: String, fallbackGameId: String = "fnv"): TouchLayoutProfile {
            val root = JSONObject(json)
            val arr = root.getJSONArray("elements")
            val list = mutableListOf<TouchElementConfig>()
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                list += TouchElementConfig(
                    id = o.getString("id"),
                    label = o.getString("label"),
                    x = o.getDouble("x").toFloat(),
                    y = o.getDouble("y").toFloat(),
                    size = o.getDouble("size").toFloat(),
                    opacity = o.getDouble("opacity").toFloat(),
                    visible = o.getBoolean("visible"),
                    isStick = o.optBoolean("isStick", false),
                    binding = PcBinding(
                        kind = BindingKind.valueOf(o.getString("kind")),
                        code = o.getInt("code"),
                        label = o.optString("bindLabel", "")
                    )
                )
            }
            return TouchLayoutProfile(
                profileName = root.optString("profileName", "Custom"),
                gameId = root.optString("gameId", fallbackGameId),
                stickDeadZone = root.optDouble("stickDeadZone", 0.18).toFloat(),
                mouseSensitivity = root.optDouble("mouseSensitivity", 1.4).toFloat(),
                invertX = root.optBoolean("invertX", false),
                invertY = root.optBoolean("invertY", false),
                elements = list
            )
        }
    }
}
