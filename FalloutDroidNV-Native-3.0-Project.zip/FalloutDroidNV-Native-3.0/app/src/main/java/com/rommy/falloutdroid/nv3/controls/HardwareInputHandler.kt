package com.rommy.falloutdroid.nv3.controls

import android.view.InputDevice
import android.view.KeyEvent
import android.view.MotionEvent
import com.rommy.falloutdroid.nv3.nativebridge.NativeEngine

/**
 * Translates Bluetooth Xbox / DualSense / DualShock controllers and physical keyboards
 * into the exact same Win32 PC Input Engine (zero duplicate layers).
 */
class HardwareInputHandler(private val deadZone: Float = 0.18f) {
    fun onKeyEvent(event: KeyEvent): Boolean {
        val pressed = (event.action == KeyEvent.ACTION_DOWN)
        if (event.action != KeyEvent.ACTION_DOWN && event.action != KeyEvent.ACTION_UP) return false
        if (pressed && event.repeatCount > 0) return true

        val vk = when (event.keyCode) {
            // Gamepad Xbox / DualSense / DualShock
            KeyEvent.KEYCODE_BUTTON_A -> 0x45 // E (Use)
            KeyEvent.KEYCODE_BUTTON_B -> 0x09 // TAB (Pip-Boy)
            KeyEvent.KEYCODE_BUTTON_X -> 0x52 // R (Reload)
            KeyEvent.KEYCODE_BUTTON_Y -> 0x20 // SPACE (Jump)
            KeyEvent.KEYCODE_BUTTON_L1 -> 0x51 // Q (VATS)
            KeyEvent.KEYCODE_BUTTON_R1 -> 0x46 // F (POV)
            KeyEvent.KEYCODE_BUTTON_THUMBL -> 0x11 // CTRL (Sneak)
            KeyEvent.KEYCODE_BUTTON_START -> 0x1B // ESC (Menu)
            KeyEvent.KEYCODE_BUTTON_SELECT -> 0x54 // T (Wait)
            // Physical PC Keyboard
            KeyEvent.KEYCODE_W -> 0x57
            KeyEvent.KEYCODE_A -> 0x41
            KeyEvent.KEYCODE_S -> 0x53
            KeyEvent.KEYCODE_D -> 0x44
            KeyEvent.KEYCODE_E -> 0x45
            KeyEvent.KEYCODE_R -> 0x52
            KeyEvent.KEYCODE_Q -> 0x51
            KeyEvent.KEYCODE_F -> 0x46
            KeyEvent.KEYCODE_T -> 0x54
            KeyEvent.KEYCODE_SPACE -> 0x20
            KeyEvent.KEYCODE_TAB -> 0x09
            KeyEvent.KEYCODE_ESCAPE -> 0x1B
            KeyEvent.KEYCODE_SHIFT_LEFT, KeyEvent.KEYCODE_SHIFT_RIGHT -> 0x10
            KeyEvent.KEYCODE_CTRL_LEFT, KeyEvent.KEYCODE_CTRL_RIGHT -> 0x11
            else -> return false
        }
        NativeEngine.nativeKeyEvent(vk, pressed)
        return true
    }

    fun onGenericMotionEvent(event: MotionEvent): Boolean {
        if ((event.source and InputDevice.SOURCE_JOYSTICK) != InputDevice.SOURCE_JOYSTICK) return false
        val lx = event.getAxisValue(MotionEvent.AXIS_X)
        val ly = event.getAxisValue(MotionEvent.AXIS_Y)
        NativeEngine.nativeWasdStick(lx, ly, deadZone)

        val rx = event.getAxisValue(MotionEvent.AXIS_Z)
        val ry = event.getAxisValue(MotionEvent.AXIS_RZ)
        if (kotlin.math.abs(rx) > deadZone || kotlin.math.abs(ry) > deadZone) {
            NativeEngine.nativeTouchpadDelta(rx * 18f, ry * 18f)
        }
        val rTrig = event.getAxisValue(MotionEvent.AXIS_RTRIGGER)
        val lTrig = event.getAxisValue(MotionEvent.AXIS_LTRIGGER)
        NativeEngine.nativeMouseButton(0, rTrig > 0.35f)
        NativeEngine.nativeMouseButton(1, lTrig > 0.35f)
        return true
    }
}
