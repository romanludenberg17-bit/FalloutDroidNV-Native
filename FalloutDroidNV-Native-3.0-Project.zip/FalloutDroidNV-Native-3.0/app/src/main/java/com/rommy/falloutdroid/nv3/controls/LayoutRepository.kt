package com.rommy.falloutdroid.nv3.controls

import android.content.Context

class LayoutRepository(context: Context) {
    private val prefs = context.getSharedPreferences("fnv3_layouts", Context.MODE_PRIVATE)

    fun loadProfile(gameId: String): TouchLayoutProfile {
        val raw = prefs.getString("profile_$gameId", null) ?: return TouchLayoutProfile.defaultFalloutNvProfile(gameId)
        return runCatching { TouchLayoutProfile.fromJson(raw, gameId) }
            .getOrElse { TouchLayoutProfile.defaultFalloutNvProfile(gameId) }
    }

    fun saveProfile(profile: TouchLayoutProfile) {
        prefs.edit().putString("profile_${profile.gameId}", profile.toJson()).apply()
    }

    fun resetProfile(gameId: String): TouchLayoutProfile {
        val def = TouchLayoutProfile.defaultFalloutNvProfile(gameId)
        saveProfile(def)
        return def
    }
}
