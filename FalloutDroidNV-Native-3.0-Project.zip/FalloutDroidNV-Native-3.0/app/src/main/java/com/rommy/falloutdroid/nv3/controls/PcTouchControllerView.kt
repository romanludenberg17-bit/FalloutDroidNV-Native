package com.rommy.falloutdroid.nv3.controls

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.view.MotionEvent
import android.view.View
import com.rommy.falloutdroid.nv3.nativebridge.NativeEngine
import kotlin.math.hypot

/**
 * Brand-new standalone PC Touch Input Engine (NOT an overlay on legacy buttons):
 * - Left WASD virtual stick with configurable dead zone
 * - Right virtual touchpad (relative mouse camera in Gameplay, cursor in Menu, tap = LMB)
 * - Independent multitouch pointer tracking with guaranteed key-up release (zero stuck keys)
 */
class PcTouchControllerView(context: Context, var profile: TouchLayoutProfile) : View(context) {
    private val ringPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE; strokeWidth = 4f; color = Color.parseColor("#FFB840")
    }
    private val fillPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL; color = Color.parseColor("#88120E0A")
    }
    private val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#FFF3D6"); textSize = 26f; textAlign = Paint.Align.CENTER
    }

    private var stickPointerId = -1
    private var stickDx = 0f
    private var stickDy = 0f

    private var touchpadPointerId = -1
    private var lastTouchX = 0f
    private var lastTouchY = 0f
    private var touchDownTime = 0L
    private var touchMovedDist = 0f

    private val activeButtons = HashMap<Int, TouchElementConfig>()

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val w = width.toFloat(); val h = height.toFloat()
        if (w <= 0f || h <= 0f) return

        for (el in profile.elements) {
            if (!el.visible) continue
            val cx = el.x * w
            val cy = el.y * h
            val r = (if (el.isStick) 115f else 54f) * el.size
            val alpha = (el.opacity * 255f).toInt().coerceIn(30, 255)
            ringPaint.alpha = alpha
            fillPaint.alpha = (alpha * 0.65f).toInt()
            textPaint.alpha = alpha

            canvas.drawCircle(cx, cy, r, fillPaint)
            canvas.drawCircle(cx, cy, r, ringPaint)
            if (el.isStick) {
                canvas.drawCircle(cx + stickDx * r * 0.65f, cy + stickDy * r * 0.65f, r * 0.36f, ringPaint)
            } else {
                canvas.drawText(el.label, cx, cy + 9f, textPaint)
            }
        }
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        val w = width.toFloat(); val h = height.toFloat()
        val actionIdx = event.actionIndex
        val pid = event.getPointerId(actionIdx)

        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN, MotionEvent.ACTION_POINTER_DOWN -> {
                val tx = event.getX(actionIdx)
                val ty = event.getY(actionIdx)
                val hit = findHitElement(tx, ty, w, h)
                if (hit != null && hit.isStick && stickPointerId == -1) {
                    stickPointerId = pid
                    updateStick(tx, ty, hit, w, h)
                } else if (hit != null && !hit.isStick) {
                    activeButtons[pid] = hit
                    dispatchBinding(hit.binding, true)
                } else if (touchpadPointerId == -1) {
                    // Right/free area acts as PC Virtual Touchpad
                    touchpadPointerId = pid
                    lastTouchX = tx; lastTouchY = ty
                    touchDownTime = System.currentTimeMillis()
                    touchMovedDist = 0f
                }
                invalidate()
            }
            MotionEvent.ACTION_MOVE -> {
                for (i in 0 until event.pointerCount) {
                    val id = event.getPointerId(i)
                    val tx = event.getX(i); val ty = event.getY(i)
                    if (id == stickPointerId) {
                        val stick = profile.elements.firstOrNull { it.isStick }
                        if (stick != null) updateStick(tx, ty, stick, w, h)
                    } else if (id == touchpadPointerId) {
                        val dx = tx - lastTouchX; val dy = ty - lastTouchY
                        lastTouchX = tx; lastTouchY = ty
                        touchMovedDist += hypot(dx, dy)
                        NativeEngine.nativeTouchpadDelta(dx, dy)
                    }
                }
                invalidate()
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_POINTER_UP -> {
                releasePointer(pid)
                invalidate()
            }
            MotionEvent.ACTION_CANCEL -> {
                stickPointerId = -1; stickDx = 0f; stickDy = 0f
                touchpadPointerId = -1
                activeButtons.clear()
                NativeEngine.nativeReleaseAllInput()
                invalidate()
            }
        }
        return true
    }

    private fun releasePointer(pid: Int) {
        if (pid == stickPointerId) {
            stickPointerId = -1; stickDx = 0f; stickDy = 0f
            NativeEngine.nativeWasdStick(0f, 0f, profile.stickDeadZone)
        } else if (pid == touchpadPointerId) {
            touchpadPointerId = -1
            // Quick tap on touchpad = PC Left Mouse Click (LMB)
            if (touchMovedDist < 18f && (System.currentTimeMillis() - touchDownTime) < 220L) {
                NativeEngine.nativeMouseButton(0, true)
                postDelayed({ NativeEngine.nativeMouseButton(0, false) }, 35L)
            }
        } else {
            activeButtons.remove(pid)?.let { dispatchBinding(it.binding, false) }
        }
    }

    private fun updateStick(tx: Float, ty: Float, stick: TouchElementConfig, w: Float, h: Float) {
        val cx = stick.x * w; val cy = stick.y * h
        val r = 115f * stick.size
        var dx = (tx - cx) / r; var dy = (ty - cy) / r
        val mag = hypot(dx, dy)
        if (mag > 1f) { dx /= mag; dy /= mag }
        stickDx = dx; stickDy = dy
        NativeEngine.nativeWasdStick(dx, dy, profile.stickDeadZone)
    }

    private fun findHitElement(tx: Float, ty: Float, w: Float, h: Float): TouchElementConfig? {
        for (el in profile.elements) {
            if (!el.visible) continue
            val r = (if (el.isStick) 130f else 64f) * el.size
            if (hypot(tx - el.x * w, ty - el.y * h) <= r) return el
        }
        return null
    }

    private fun dispatchBinding(b: PcBinding, pressed: Boolean) {
        when (b.kind) {
            BindingKind.KEY -> NativeEngine.nativeKeyEvent(b.code, pressed)
            BindingKind.MOUSE_BUTTON -> NativeEngine.nativeMouseButton(b.code, pressed)
            BindingKind.MOUSE_WHEEL -> if (pressed) NativeEngine.nativeMouseWheel(b.code)
        }
    }
}
