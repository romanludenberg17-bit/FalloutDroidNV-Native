package com.rommy.falloutdroid.nv3.controls

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import kotlin.math.roundToInt

@Composable
fun TouchLayoutEditorScreen(
    initialProfile: TouchLayoutProfile,
    onSave: (TouchLayoutProfile) -> Unit,
    onReset: () -> TouchLayoutProfile
) {
    var profile by remember { mutableStateOf(initialProfile) }
    var selectedId by remember { mutableStateOf(initialProfile.elements.firstOrNull()?.id ?: "fire") }
    var canvasSize by remember { mutableStateOf(IntSize(1, 1)) }
    var jsonExportPreview by remember { mutableStateOf<String?>(null) }

    val selected = profile.elements.firstOrNull { it.id == selectedId }

    Row(Modifier.fillMaxSize().padding(10.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        Box(
            Modifier
                .weight(1f)
                .fillMaxHeight()
                .background(Color(0xFF100D09), MaterialTheme.shapes.medium)
                .border(1.dp, MaterialTheme.colorScheme.outline, MaterialTheme.shapes.medium)
                .onSizeChanged { canvasSize = it }
        ) {
            profile.elements.forEach { el ->
                val isSel = el.id == selectedId
                val dpSize = (if (el.isStick) 76f else 48f) * el.size
                Box(
                    Modifier
                        .offset {
                            IntOffset(
                                (el.x * canvasSize.width - dpSize * 1.3f).roundToInt(),
                                (el.y * canvasSize.height - dpSize * 1.3f).roundToInt()
                            )
                        }
                        .size(dpSize.dp)
                        .background(
                            Color(0xCC1B150E).copy(alpha = if (el.visible) el.opacity else 0.25f),
                            CircleShape
                        )
                        .border(if (isSel) 3.dp else 1.5.dp, if (isSel) Color.White else MaterialTheme.colorScheme.primary, CircleShape)
                        .pointerInput(el.id) {
                            detectDragGestures(onDragStart = { selectedId = el.id }) { change, drag ->
                                change.consume()
                                val nx = (el.x + drag.x / canvasSize.width.coerceAtLeast(1)).coerceIn(0.04f, 0.96f)
                                val ny = (el.y + drag.y / canvasSize.height.coerceAtLeast(1)).coerceIn(0.06f, 0.94f)
                                profile = profile.copy(elements = profile.elements.map {
                                    if (it.id == el.id) it.copy(x = nx, y = ny) else it
                                })
                            }
                        },
                    contentAlignment = Alignment.Center
                ) {
                    Text(el.label, style = MaterialTheme.typography.labelSmall, color = Color(0xFFFFF3D6))
                }
            }
        }

        Column(Modifier.width(250.dp).fillMaxHeight(), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("PC Layout Editor", style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.primary)
            if (selected != null) {
                Text("${selected.label} (${selected.binding.label})", style = MaterialTheme.typography.bodyMedium)
                Text("Size: ${(selected.size * 100).roundToInt()}%")
                Slider(value = selected.size, onValueChange = { nv ->
                    profile = profile.copy(elements = profile.elements.map { if (it.id == selected.id) it.copy(size = nv) else it })
                }, valueRange = 0.6f..1.6f)
                Text("Opacity: ${(selected.opacity * 100).roundToInt()}%")
                Slider(value = selected.opacity, onValueChange = { nv ->
                    profile = profile.copy(elements = profile.elements.map { if (it.id == selected.id) it.copy(opacity = nv) else it })
                }, valueRange = 0.2f..1.0f)
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("Visible", Modifier.weight(1f))
                    Switch(checked = selected.visible, onCheckedChange = { nv ->
                        profile = profile.copy(elements = profile.elements.map { if (it.id == selected.id) it.copy(visible = nv) else it })
                    })
                }
                if (!selected.isStick) {
                    OutlinedButton(onClick = {
                        val all = TouchLayoutProfile.AVAILABLE_BINDINGS
                        val idx = (all.indexOfFirst { it.code == selected.binding.code && it.kind == selected.binding.kind } + 1) % all.size
                        profile = profile.copy(elements = profile.elements.map { if (it.id == selected.id) it.copy(binding = all[idx]) else it })
                    }, modifier = Modifier.fillMaxWidth()) {
                        Text("Remap Key: ${selected.binding.label}")
                    }
                }
            }
            Spacer(Modifier.weight(1f))
            Button(onClick = { onSave(profile) }, modifier = Modifier.fillMaxWidth()) { Text("Save Profile") }
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                OutlinedButton(onClick = { jsonExportPreview = profile.toJson() }, modifier = Modifier.weight(1f)) { Text("JSON") }
                OutlinedButton(onClick = { profile = onReset() }, modifier = Modifier.weight(1f)) { Text("Reset") }
            }
        }
    }

    if (jsonExportPreview != null) {
        AlertDialog(
            onDismissRequest = { jsonExportPreview = null },
            confirmButton = { TextButton(onClick = { jsonExportPreview = null }) { Text("OK") } },
            title = { Text("Profile JSON") },
            text = { Text(jsonExportPreview!!.take(1200), style = MaterialTheme.typography.bodySmall) }
        )
    }
}
