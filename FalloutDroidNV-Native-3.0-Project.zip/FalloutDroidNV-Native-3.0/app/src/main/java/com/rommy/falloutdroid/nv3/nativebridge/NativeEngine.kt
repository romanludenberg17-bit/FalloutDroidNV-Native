package com.rommy.falloutdroid.nv3.nativebridge

import android.view.Surface

object NativeEngine {
    init {
        System.loadLibrary("fnv3")
    }

    external fun nativeInitAudio(): Boolean
    external fun nativeSetMasterVolume(vol: Float)
    external fun nativeSetCategoryVolume(category: Int, vol: Float)
    external fun nativeTriggerAudioTest(category: Int, freqHz: Float, durationMs: Int)
    external fun nativeGetAudioDiagnosticsJson(): String

    external fun nativeSetInputMode(mode: Int) // 0=Gameplay, 1=Menu
    external fun nativeSetMouseConfig(sensitivity: Float, invertX: Boolean, invertY: Boolean)
    external fun nativeKeyEvent(vkCode: Int, pressed: Boolean)
    external fun nativeWasdStick(normX: Float, normY: Float, deadZone: Float)
    external fun nativeTouchpadDelta(dx: Float, dy: Float)
    external fun nativeMouseButton(button: Int, pressed: Boolean) // 0=LMB, 1=RMB, 2=MMB
    external fun nativeMouseWheel(delta: Int)
    external fun nativeReleaseAllInput()

    external fun nativeMountGameDir(gameRootPath: String): String
    external fun nativeAttachSurface(surface: Surface): Boolean
    external fun nativeDetachSurface()
}
