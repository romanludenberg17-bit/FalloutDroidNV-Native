package com.rommy.falloutdroid.nv3.ui

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.rommy.falloutdroid.nv3.controls.*
import com.rommy.falloutdroid.nv3.nativebridge.NativeEngine

enum class NavTab(val title: String) {
    HOME("Home"),
    LIBRARY("Game Library"),
    GAME_SETTINGS("Game Settings"),
    GRAPHICS("Graphics"),
    AUDIO("Audio"),
    CONTROLS("Controls"),
    CONTROLLER("Controller"),
    PERFORMANCE("Performance"),
    DIAGNOSTICS("Diagnostics"),
    FILES("File Manager")
}

@Composable
fun FalloutDroid3App(
    gameDirPath: String,
    mountStatusJson: String,
    layoutRepo: LayoutRepository,
    onPickGameFolder: () -> Unit,
    onLaunchGame: () -> Unit
) {
    var tab by remember { mutableStateOf(NavTab.HOME) }
    var audioDiag by remember { mutableStateOf("{}") }
    var masterVol by remember { mutableFloatStateOf(1.0f) }
    var sfxVol by remember { mutableFloatStateOf(1.0f) }
    var voiceVol by remember { mutableFloatStateOf(1.0f) }
    var radioVol by remember { mutableFloatStateOf(0.85f) }

    LaunchedEffect(Unit) {
        NativeEngine.nativeInitAudio()
        audioDiag = NativeEngine.nativeGetAudioDiagnosticsJson()
    }

    Row(Modifier.fillMaxSize().padding(8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        NavigationRail(modifier = Modifier.width(148.dp)) {
            Column(Modifier.verticalScroll(rememberScrollState())) {
                NavTab.entries.forEach { item ->
                    NavigationRailItem(
                        selected = tab == item,
                        onClick = {
                            tab = item
                            if (item == NavTab.DIAGNOSTICS) {
                                audioDiag = NativeEngine.nativeGetAudioDiagnosticsJson()
                            }
                        },
                        icon = {},
                        label = { Text(item.title, maxLines = 1) }
                    )
                }
            }
        }

        Surface(
            modifier = Modifier.weight(1f).fillMaxHeight(),
            shape = MaterialTheme.shapes.large,
            tonalElevation = 2.dp
        ) {
            when (tab) {
                NavTab.HOME -> Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text("Fallout Droid NV Native 3.0", style = MaterialTheme.typography.headlineSmall, color = MaterialTheme.colorScheme.primary)
                    Text("Unicorn Engine 2.1.4 + Google Oboe + Vulkan + PC Touch Engine")
                    Text("Game Folder: ${gameDirPath.ifEmpty { "Not selected" }}")
                    Text("Data Verification: $mountStatusJson", style = MaterialTheme.typography.bodySmall)
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        Button(onClick = onLaunchGame) { Text("Launch Viewport / Engine") }
                        OutlinedButton(onClick = onPickGameFolder) { Text("Select Data Folder (SAF)") }
                    }
                }
                NavTab.LIBRARY -> Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Game Library", style = MaterialTheme.typography.titleLarge)
                    Card(Modifier.fillMaxWidth()) {
                        Column(Modifier.padding(14.dp)) {
                            Text("Fallout: New Vegas (User-supplied PC Data)", style = MaterialTheme.typography.titleMedium)
                            Text("Path: ${gameDirPath.ifEmpty { "Unmounted" }}")
                            Text("Status: $mountStatusJson", style = MaterialTheme.typography.bodySmall)
                        }
                    }
                }
                NavTab.GAME_SETTINGS -> Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Game Settings", style = MaterialTheme.typography.titleLarge)
                    Text("Engine: Unicorn 2.1.4 (x86-32) + DirectSound8/3D + XAudio2 + Vulkan")
                    Text("Mouse Mode: Automatic Game (Relative) / Menu (Absolute Cursor)")
                }
                NavTab.GRAPHICS -> Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Graphics (Vulkan Backend)", style = MaterialTheme.typography.titleLarge)
                    Text("Target API: Vulkan 1.1+ (arm64-v8a, Android 10–17)")
                }
                NavTab.AUDIO -> Column(Modifier.padding(16.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Audio Engine (Google Oboe / AAudio)", style = MaterialTheme.typography.titleLarge)
                    Text("Master Volume: ${(masterVol * 100).toInt()}%")
                    Slider(value = masterVol, onValueChange = { masterVol = it; NativeEngine.nativeSetMasterVolume(it) })
                    Text("SFX / Gunshots / UI / Footsteps: ${(sfxVol * 100).toInt()}%")
                    Slider(value = sfxVol, onValueChange = { sfxVol = it; NativeEngine.nativeSetCategoryVolume(1, it); NativeEngine.nativeSetCategoryVolume(0, it) })
                    Text("Dialogue / Voices: ${(voiceVol * 100).toInt()}%")
                    Slider(value = voiceVol, onValueChange = { voiceVol = it; NativeEngine.nativeSetCategoryVolume(8, it) })
                    Text("Music & Radio: ${(radioVol * 100).toInt()}%")
                    Slider(value = radioVol, onValueChange = { radioVol = it; NativeEngine.nativeSetCategoryVolume(5, it); NativeEngine.nativeSetCategoryVolume(6, it) })
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(onClick = { NativeEngine.nativeTriggerAudioTest(1, 330f, 250) }) { Text("Test SFX") }
                        Button(onClick = { NativeEngine.nativeTriggerAudioTest(6, 440f, 350) }) { Text("Test Radio") }
                        Button(onClick = { NativeEngine.nativeTriggerAudioTest(10, 520f, 350) }) { Text("Test 3D Right") }
                    }
                }
                NavTab.CONTROLS -> TouchLayoutEditorScreen(
                    initialProfile = layoutRepo.loadProfile("fnv"),
                    onSave = { layoutRepo.saveProfile(it) },
                    onReset = { layoutRepo.resetProfile("fnv") }
                )
                NavTab.CONTROLLER -> Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Controller & Keyboard Settings", style = MaterialTheme.typography.titleLarge)
                    Text("Supported: Xbox Wireless, DualSense, DualShock 4, Physical USB/BT Keyboards & Mice.")
                    Text("Unified Input Mapping: Hardware -> Win32 VK/DIK -> InputEngine.")
                }
                NavTab.PERFORMANCE -> Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Performance", style = MaterialTheme.typography.titleLarge)
                    Text("CPU Backend: Unicorn Engine 2.1.4 (arm64-v8a JIT)")
                    Text("Audio Buffer: 2x Oboe framesPerBurst @ 48 kHz Stereo Float32")
                }
                NavTab.DIAGNOSTICS -> Column(Modifier.padding(16.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("Audio & Engine Diagnostics", style = MaterialTheme.typography.titleLarge)
                    Button(onClick = { audioDiag = NativeEngine.nativeGetAudioDiagnosticsJson() }) { Text("Refresh Live Audio Telemetry") }
                    Card(Modifier.fillMaxWidth()) {
                        Text(audioDiag, Modifier.padding(12.dp), style = MaterialTheme.typography.bodySmall)
                    }
                }
                NavTab.FILES -> Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("File Manager (BSA / ESM / DLC)", style = MaterialTheme.typography.titleLarge)
                    Text("Current Path: ${gameDirPath.ifEmpty { "None" }}")
                    Text("Mount Report: $mountStatusJson")
                    Button(onClick = onPickGameFolder) { Text("Browse Game Folder (Android SAF)") }
                }
            }
        }
    }
}
