package com.rommy.falloutdroid.nv3.ui

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val FalloutAmberScheme = darkColorScheme(
    primary = Color(0xFFFFB840),
    onPrimary = Color(0xFF1F1400),
    surface = Color(0xFF14100B),
    background = Color(0xFF0B0907),
    onBackground = Color(0xFFFFF3D6),
    onSurface = Color(0xFFFFF3D6),
    outline = Color(0x66FFB840)
)

@Composable
fun FalloutDroid3Theme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = FalloutAmberScheme, content = content)
}
