#include "fnv3/audio_decoder.hpp"
#include "fnv3/com_runtime.hpp"
#include "fnv3/dinput8_compat.hpp"
#include "fnv3/dsound_compat.hpp"
#include "fnv3/engine_core.hpp"
#include <cassert>
#include <cmath>
#include <cstring>
#include <filesystem>
#include <fstream>
#include <iostream>
#include <limits>
#include <thread>
#include <vector>
#include <zlib.h>

using namespace fnv3;

static std::vector<int16_t> makeSine16(uint32_t sr, float hz, uint32_t frames, float amp = 0.5f) {
    std::vector<int16_t> out(frames);
    for (uint32_t i = 0; i < frames; ++i) {
        float s = std::sin(2.0f * 3.14159265f * hz * static_cast<float>(i) / static_cast<float>(sr));
        out[i] = static_cast<int16_t>(s * amp * 32767.0f);
    }
    return out;
}

static std::vector<uint8_t> makeWavFile(uint32_t sr, uint16_t ch, const std::vector<int16_t>& pcm) {
    uint32_t dataBytes = static_cast<uint32_t>(pcm.size() * 2);
    uint32_t riffSize = 36 + dataBytes;
    uint32_t byteRate = sr * ch * 2;
    uint16_t blockAlign = ch * 2;
    uint16_t bits = 16;
    uint16_t fmtTag = 1;
    uint32_t fmtSz = 16;
    std::vector<uint8_t> out;
    auto app = [&](const void* p, size_t n) {
        const auto* b = static_cast<const uint8_t*>(p);
        out.insert(out.end(), b, b + n);
    };
    app("RIFF", 4); app(&riffSize, 4); app("WAVE", 4);
    app("fmt ", 4); app(&fmtSz, 4); app(&fmtTag, 2); app(&ch, 2);
    app(&sr, 4); app(&byteRate, 4); app(&blockAlign, 2); app(&bits, 2);
    app("data", 4); app(&dataBytes, 4); app(pcm.data(), dataBytes);
    return out;
}

// 1. COM object lifetime & AddRef / Release
static void testComLifetime() {
    static bool destroyed = false;
    struct TestObj : public com::ComObject {
        ~TestObj() override { destroyed = true; }
    };
    destroyed = false;
    auto* obj = new TestObj();
    assert(obj->refCount() == 1);
    assert(obj->addRef() == 2);
    assert(obj->release() == 1);
    assert(!destroyed);
    assert(obj->release() == 0);
    assert(destroyed);
    std::cout << "[PASS] 01 testComLifetime\n";
}

// 2. COM QueryInterface (valid & E_NOINTERFACE)
static void testComQueryInterface() {
    audio::AudioMixer mixer(48000);
    input::InputEngine inp;
    fs::GameFilesystem gfs;
    win32::Win32CompatLayer win32(mixer, inp, gfs);

    auto* ds = win32.createDirectSound8();
    com::ComObject* out = nullptr;
    assert(ds->queryInterface(com::IID_IDirectSound8, &out) == com::S_OK_HR && out == ds);
    ds->release();
    assert(ds->queryInterface(com::IID_IXAudio2, &out) == com::E_NOINTERFACE_HR && out == nullptr);

    dsound::DirectSoundBuffer8* buf = nullptr;
    assert(ds->createSoundBuffer(4096, 44100, 1, 16, audio::AudioCategory::WeaponFire, true, &buf) == com::S_OK_HR);
    assert(buf->queryInterface(com::IID_IDirectSound3DBuffer8, &out) == com::S_OK_HR && out == buf);
    buf->release();
    assert(buf->queryInterface(com::IID_IDirectSoundNotify, &out) == com::S_OK_HR && out == buf);
    buf->release();
    buf->release();
    ds->release();
    std::cout << "[PASS] 02 testComQueryInterface\n";
}

// 3. DirectInput8 Keyboard (linked directly to Stage 1 PC InputEngine)
static void testDirectInputKeyboard() {
    audio::AudioMixer mixer(48000);
    input::InputEngine inp;
    fs::GameFilesystem gfs;
    win32::Win32CompatLayer win32(mixer, inp, gfs);

    auto* di = win32.createDirectInput8();
    dinput::DirectInputDevice8* kbd = nullptr;
    assert(di->createDevice(com::GUID_SysKeyboard, &kbd) == com::S_OK_HR);
    assert(kbd->acquire() == com::S_OK_HR);

    inp.setKeyState(input::VK::KEY_W, true);
    inp.setKeyState(input::VK::SPACE, true);

    uint8_t state[256]{};
    assert(kbd->getDeviceState(256, state) == com::S_OK_HR);
    assert(state[0x11] == 0x80); // DIK_W
    assert(state[0x39] == 0x80); // DIK_SPACE

    dinput::DiDeviceObjectData evs[8]{};
    uint32_t cnt = 8;
    assert(kbd->getDeviceData(sizeof(dinput::DiDeviceObjectData), evs, &cnt) == com::S_OK_HR);
    assert(cnt == 2 && evs[0].dwOfs == 0x11 && evs[0].dwData == 0x80);

    kbd->release();
    di->release();
    std::cout << "[PASS] 03 testDirectInputKeyboard\n";
}

// 4. DirectInput8 Mouse (relative delta, wheel, LMB/RMB, Menu freeze)
static void testDirectInputMouse() {
    audio::AudioMixer mixer(48000);
    input::InputEngine inp;
    fs::GameFilesystem gfs;
    win32::Win32CompatLayer win32(mixer, inp, gfs);

    auto* di = win32.createDirectInput8();
    dinput::DirectInputDevice8* mouse = nullptr;
    assert(di->createDevice(com::GUID_SysMouse, &mouse) == com::S_OK_HR);
    mouse->acquire();

    inp.setMode(input::InputMode::Gameplay);
    inp.setMouseConfig(1.5f, false, false);
    inp.onTouchpadDelta(12.0f, -8.0f);
    inp.setMouseButton(0, true);
    inp.onMouseWheel(1);

    dinput::DiMouseState2 ms{};
    assert(mouse->getDeviceState(sizeof(ms), &ms) == com::S_OK_HR);
    assert(ms.lX == 18 && ms.lY == -12 && ms.lZ == 120 && ms.rgbButtons[0] == 0x80);

    mouse->release();
    di->release();
    std::cout << "[PASS] 04 testDirectInputMouse\n";
}

// 5 & 6. DirectSound8 Lock/Unlock + Playback + 3D + IDirectSoundNotify
static void testDirectSoundLockPlaybackAndNotify() {
    audio::AudioMixer mixer(48000);
    input::InputEngine inp;
    fs::GameFilesystem gfs;
    win32::Win32CompatLayer win32(mixer, inp, gfs);

    auto* ds = win32.createDirectSound8();
    dsound::DirectSoundBuffer8* buf = nullptr;
    auto sine = makeSine16(48000, 440.0f, 1024, 0.7f);
    uint32_t byteLen = static_cast<uint32_t>(sine.size() * 2);

    assert(ds->createSoundBuffer(byteLen, 48000, 1, 16, audio::AudioCategory::WeaponFire, true, &buf) == com::S_OK_HR);

    // Wrap-around Lock/Unlock test
    uint8_t* p1 = nullptr; uint8_t* p2 = nullptr;
    uint32_t l1 = 0, l2 = 0;
    assert(buf->lock(byteLen - 128, 256, &p1, &l1, &p2, &l2) == com::S_OK_HR);
    assert(l1 == 128 && l2 == 128 && p1 != nullptr && p2 != nullptr);
    assert(buf->unlock(p1, l1, p2, l2) == com::S_OK_HR);

    // Full Lock/Unlock PCM upload
    assert(buf->lock(0, byteLen, &p1, &l1, &p2, &l2) == com::S_OK_HR);
    std::memcpy(p1, sine.data(), l1);
    assert(buf->unlock(p1, l1, p2, l2) == com::S_OK_HR);

    // Setup IDirectSoundNotify event at half buffer
    uint32_t evH = win32.createEvent(true, false);
    assert(buf->setNotificationPositions({{byteLen / 2, evH}}) == com::S_OK_HR);
    assert(win32.waitForSingleObject(evH, 0) == 0x00000102u); // Not signaled yet

    assert(buf->set3DPosition(5.0f, 0.0f, 0.0f) == com::S_OK_HR);
    assert(buf->play(0) == com::S_OK_HR);

    std::vector<float> out(600 * 2, 0.0f);
    mixer.mixFrames(out.data(), 600);
    buf->pollNotifications();
    assert(win32.waitForSingleObject(evH, 0) == 0u); // WAIT_OBJECT_0 -> notification fired!
    assert(mixer.getDiagnostics().peakLevel > 0.05f);

    buf->release();
    ds->release();
    std::cout << "[PASS] 05-06 testDirectSoundLockPlaybackAndNotify\n";
}

// 7. XAudio2 Source Buffers
static void testXAudio2SourceBuffers() {
    audio::AudioMixer mixer(48000);
    input::InputEngine inp;
    fs::GameFilesystem gfs;
    win32::Win32CompatLayer win32(mixer, inp, gfs);

    auto* xa = win32.createXAudio2();
    dsound::XAudio2SourceVoice* sv = nullptr;
    assert(xa->createSourceVoice(48000, 1, 16, audio::AudioCategory::Radio, &sv) == com::S_OK_HR);
    auto pcm = makeSine16(48000, 520.0f, 2048, 0.6f);
    assert(sv->submitSourceBuffer(pcm.data(), pcm.size() * 2) == com::S_OK_HR);
    assert(sv->setVolume(0.85f) == com::S_OK_HR);
    assert(sv->start() == com::S_OK_HR);

    std::vector<float> out(512 * 2, 0.0f);
    mixer.mixFrames(out.data(), 512);
    assert(mixer.getDiagnostics().rmsLevel > 0.05f);

    sv->release();
    xa->release();
    std::cout << "[PASS] 07 testXAudio2SourceBuffers\n";
}

// 8. Thread Synchronization (Event + Mutex + CriticalSection)
static void testThreadSync() {
    audio::AudioMixer mixer(48000);
    input::InputEngine inp;
    fs::GameFilesystem gfs;
    win32::Win32CompatLayer win32(mixer, inp, gfs);

    uint32_t ev = win32.createEvent(false, false);
    int sharedCounter = 0;
    std::thread worker([&]() {
        win32.enterCriticalSection(0x5000);
        sharedCounter += 42;
        win32.leaveCriticalSection(0x5000);
        win32.setEvent(ev);
    });
    assert(win32.waitForSingleObject(ev, 2000) == 0u);
    worker.join();
    assert(sharedCounter == 42);

    uint32_t mtx = win32.createMutex(true, 1);
    assert(win32.releaseMutex(mtx, 1));
    std::cout << "[PASS] 08 testThreadSync\n";
}

// 9. Thread Local Storage (TLS)
static void testTls() {
    audio::AudioMixer mixer(48000);
    input::InputEngine inp;
    fs::GameFilesystem gfs;
    win32::Win32CompatLayer win32(mixer, inp, gfs);

    uint32_t slot = win32.tlsAlloc();
    assert(slot != 0xFFFFFFFFu);
    assert(win32.tlsSetValue(1, slot, 0xCAFEBABEu));
    assert(win32.tlsSetValue(2, slot, 0xDEADBEEFu));
    assert(win32.tlsGetValue(1, slot) == 0xCAFEBABEu);
    assert(win32.tlsGetValue(2, slot) == 0xDEADBEEFu);
    assert(win32.tlsFree(slot));
    std::cout << "[PASS] 09 testTls\n";
}

// 10. Win32 Registry
static void testRegistry() {
    audio::AudioMixer mixer(48000);
    input::InputEngine inp;
    fs::GameFilesystem gfs;
    win32::Win32CompatLayer win32(mixer, inp, gfs);

    uint32_t hKey = 0;
    assert(win32.regCreateOrOpenKey("HKLM\\SOFTWARE\\Bethesda Softworks\\FalloutNV", hKey));
    std::string val;
    assert(win32.regQueryString(hKey, "Installed Path", val) && val == "C:\\Games\\FalloutNV\\");
    assert(win32.regSetString(hKey, "Language", "English"));
    assert(win32.regQueryString(hKey, "Language", val) && val == "English");
    assert(win32.regCloseKey(hKey));
    std::cout << "[PASS] 10 testRegistry\n";
}

// 11. PE32 Imports, Relocations & Strict Missing-Import Validation
static void testPeImportsAndValidation() {
    audio::AudioMixer mixer(48000);
    input::InputEngine inp;
    fs::GameFilesystem gfs;
    win32::Win32CompatLayer win32(mixer, inp, gfs);

    core::PeImage img{};
    img.imageBase = 0x00400000;
    img.imports.push_back({"kernel32.dll", "VirtualAlloc", false, 0, 0x2000});
    img.imports.push_back({"dsound.dll", "DirectSoundCreate8", false, 0, 0x2004});
    img.imports.push_back({"d3d9.dll", "Direct3DCreate9", false, 0, 0x2008}); // Stage 3 (NOT implemented yet!)
    img.relocations.push_back({0x10, 3});

    auto rep = win32.validateImports(img);
    assert(rep.totalImports == 3);
    assert(rep.resolvedImports == 2);
    assert(rep.missingImports.size() == 1 && rep.missingImports[0] == "d3d9.dll!Direct3DCreate9");

    // Verify relocation math
    std::vector<uint8_t> mapped(0x40, 0);
    uint32_t origPtr = 0x00401234;
    std::memcpy(mapped.data() + 0x10, &origPtr, 4);
    assert(core::PeLoader::applyRelocations(img, 0x10000000, mapped));
    uint32_t relocPtr = 0;
    std::memcpy(&relocPtr, mapped.data() + 0x10, 4);
    assert(relocPtr == 0x10001234);

    // Verify missing API dispatch returns E_NOTIMPL and logs honestly (NEVER fakes success!)
    uint32_t missingStub = win32.registerImportStub("d3d9.dll", "Direct3DCreate9");
    uint32_t stack[4] = {0x00409999, 0, 0, 0};
    win32::CpuRegs regs{}; regs.esp = 0x1000;
    auto rd = [&](uint32_t a, void* d, size_t n){ std::memcpy(d, reinterpret_cast<uint8_t*>(stack) + (a - 0x1000), n); return true; };
    auto wr = [&](uint32_t, const void*, size_t){ return true; };
    assert(!win32.dispatchStub(missingStub, regs, rd, wr));
    assert(regs.eax == static_cast<uint32_t>(com::E_NOTIMPL_HR));
    assert(win32.unimplementedLog().size() == 1);
    std::cout << "[PASS] 11 testPeImportsAndValidation\n";
}

// 12 & 13. Audio Decoder (WAV/PCM + OGG/XWMA/MP3 probing) & Continuous Audio Streaming
static void testAudioDecoderAndStreaming() {
    auto sine = makeSine16(44100, 330.0f, 4410, 0.5f);
    auto wavBytes = makeWavFile(44100, 1, sine);

    audio::DecodedAudio decoded{};
    std::string err;
    assert(audio::AudioDecoder::decodeToPcm(wavBytes, decoded, err));
    assert(decoded.format == audio::AudioFormatKind::WavPcm);
    assert(decoded.sampleRate == 44100 && decoded.channels == 1 && decoded.pcmBytes.size() == sine.size() * 2);

    // Probe OGG Vorbis header
    std::vector<uint8_t> ogg(64, 0);
    std::memcpy(ogg.data(), "OggS", 4);
    ogg[28] = 0x01; std::memcpy(ogg.data() + 29, "vorbis", 6);
    ogg[39] = 2; // stereo
    uint32_t oggSr = 44100; std::memcpy(ogg.data() + 40, &oggSr, 4);
    audio::DecodedAudio oggMeta{};
    assert(audio::AudioDecoder::probeCompressedHeader(ogg, oggMeta, err));
    assert(oggMeta.format == audio::AudioFormatKind::OggVorbis && oggMeta.channels == 2 && oggMeta.sampleRate == 44100);

    // Probe XWMA header
    std::vector<uint8_t> xwma(48, 0);
    std::memcpy(xwma.data(), "RIFF", 4);
    std::memcpy(xwma.data() + 8, "XWMA", 4);
    std::memcpy(xwma.data() + 12, "fmt ", 4);
    uint32_t fsz = 16; std::memcpy(xwma.data() + 16, &fsz, 4);
    uint16_t ch = 2; uint32_t xsr = 48000;
    std::memcpy(xwma.data() + 22, &ch, 2);
    std::memcpy(xwma.data() + 24, &xsr, 4);
    audio::DecodedAudio xwmaMeta{};
    assert(audio::AudioDecoder::probeCompressedHeader(xwma, xwmaMeta, err));
    assert(xwmaMeta.format == audio::AudioFormatKind::Xwma && xwmaMeta.sampleRate == 48000);

    // Probe real MP3 file if present on host
    const std::string sampleMp3 = "/working_dir/c_cd9f79887a79513d/user_uploaded_files/ttl=63d/user_uploaded/21. City of Ruin.mp3";
    if (std::filesystem::exists(sampleMp3)) {
        std::ifstream mf(sampleMp3, std::ios::binary);
        std::vector<uint8_t> head(524288);
        mf.read(reinterpret_cast<char*>(head.data()), static_cast<std::streamsize>(head.size()));
        head.resize(static_cast<size_t>(mf.gcount()));
        audio::DecodedAudio mp3Meta{};
        assert(audio::AudioDecoder::probeCompressedHeader(head, mp3Meta, err));
        assert(mp3Meta.format == audio::AudioFormatKind::Mp3 && mp3Meta.sampleRate > 0);
    }

    // Streaming test through AudioStreamPlayer -> AudioMixer
    audio::AudioMixer mixer(48000);
    audio::AudioStreamPlayer streamer(mixer);
    uint32_t sh = streamer.openStream(decoded, audio::AudioCategory::Music, false);
    assert(sh != 0);
    std::vector<float> out(960 * 2, 0.0f);
    mixer.mixFrames(out.data(), 960);
    assert(mixer.getDiagnostics().rmsLevel > 0.05f);
    std::cout << "[PASS] 12-13 testAudioDecoderAndStreaming (WAV PCM + OGG/XWMA/MP3 probe + streaming)\n";
}

int main() {
    testComLifetime();
    testComQueryInterface();
    testDirectInputKeyboard();
    testDirectInputMouse();
    testDirectSoundLockPlaybackAndNotify();
    testXAudio2SourceBuffers();
    testThreadSync();
    testTls();
    testRegistry();
    testPeImportsAndValidation();
    testAudioDecoderAndStreaming();
    std::cout << "ALL 13 STAGE 2 AUTOMATED TESTS PASSED!\n";
    return 0;
}
