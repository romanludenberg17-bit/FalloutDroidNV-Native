# Reference APK

The separately supplied `FalloutDroidNV-Native-v1.3.2 (1).apk` was inspected as a binary reference only and is intentionally not included in this source repository.

Observed archive entries include `lib/arm64-v8a/libfnv.so` (89,753,615 bytes uncompressed), `classes.dex`, `classes2.dex`, and Android assets. The native library name differs from this project's `libfnv3.so`; do not overwrite or rename one to the other as a substitute for integration.

The reference APK is not treated as a source-code dependency. Its license/provenance and internal ABI must be established before any binary reuse.
