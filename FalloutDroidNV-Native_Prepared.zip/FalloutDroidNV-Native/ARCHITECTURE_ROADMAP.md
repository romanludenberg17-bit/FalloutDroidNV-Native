# FalloutDroidNV-Native — technical roadmap

## Clean-room boundary

This repository contains compatibility/runtime research and does not bundle Bethesda executables, game assets, or proprietary code. The supplied reference APK is treated as a binary behavior/reference artifact only; its native library is not interchangeable with this project's `libfnv3.so`.

## Current scaffold

- Android app shell (`arm64-v8a`, Android 10+), Kotlin/Jetpack Compose UI.
- C++17 / Android NDK / CMake native library target.
- Unicorn Engine 2.1.4 integration for x86 execution experiments.
- PE32 loader and partial Win32/COM compatibility layers.
- Input abstraction with touch and controller-oriented components.
- BSA v104 reader and audio components based on Oboe.
- Vulkan instance/device/surface work is incomplete; no game presentation pipeline exists yet.
- Host C++ tests cover selected compatibility primitives only.

## Remaining milestones

### Stage 1 — reproducible Android build

- [x] Host C++ test target and CI test job.
- [x] Android arm64 Gradle/CMake build workflow.
- [ ] Confirm workflow succeeds on GitHub Actions with the supplied source tree.
- [ ] Validate APK install/launch on a physical Android 10+ device.

### Stage 2 — executable/runtime compatibility

- [ ] Validate PE loader against the actual retail `FalloutNV.exe` supplied by the user.
- [ ] Complete required `kernel32`, `user32`, `advapi32`, `ole32`, registry, threading, TLS, and filesystem behavior.
- [ ] Implement and validate COM vtables and lifetime semantics for all required interfaces.
- [ ] Complete DirectInput, DirectSound/XAudio2, codecs, and streaming behavior.
- [ ] Build import/API coverage reports from observed executable imports and runtime traces.

### Stage 3 — Direct3D 9 to Vulkan

- [ ] Implement `IDirect3D9` / `IDirect3DDevice9` and required resource interfaces.
- [ ] Implement D3D9 resource formats, render targets, depth/stencil, vertex/index buffers, and texture upload.
- [ ] Translate required shader model 2/3 programs to Vulkan-compatible SPIR-V.
- [ ] Create Android Vulkan surface, swapchain, frame synchronization, and present loop.
- [ ] Validate actual game rendering, device loss, resize, and lifecycle behavior.

### Stage 4 — gameplay validation

- [ ] Boot to the main menu using user-provided game files.
- [ ] Validate new/load game, world streaming, dialogue, Pip-Boy, combat, radio, and saves.
- [ ] Validate touch layout editor, mouse-look, keyboard mappings, and Bluetooth controllers.
- [ ] Profile memory, CPU/GPU frame time, audio latency, and thermal stability across supported devices.

## Acceptance criteria

Do not call the project a playable/native port until a retail game install boots to a rendered main menu and completes a repeatable gameplay smoke test on a physical Android device. A successful host test or CI APK build alone does not satisfy this criterion.
