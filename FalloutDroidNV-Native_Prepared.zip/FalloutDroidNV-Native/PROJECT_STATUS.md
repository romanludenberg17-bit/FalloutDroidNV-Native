# Project status — 2026-11-25

## Verified from the supplied source archive

- Android application module: `com.rommy.falloutdroid.nv3`.
- Native target: `libfnv3.so`, C++17, `arm64-v8a`.
- CMake expects Unicorn Engine source at `third_party/unicorn`.
- Host test suite: 13 tests pass in this environment (`make -C tests clean test`).
- GitHub Actions now runs host tests before the Android build, fails fast on pipeline errors, and uploads build diagnostics even when a later step fails.

## Not verified / not implemented

- An Android APK has not been built in this environment.
- No on-device boot or gameplay test has been performed.
- The Vulkan renderer is currently initialization/surface scaffolding; it does not create a usable D3D9 backend, swapchain presentation loop, or render Fallout frames.
- The roadmap's full Win32/COM coverage and Stage 3 D3D9-to-Vulkan implementation remain incomplete.
- The supplied reference APK is not copied into this repository. Its `libfnv.so` is a separate native binary and is not interchangeable with `libfnv3.so`.

Passing host tests is not evidence that the retail game can boot or render. CI success, when available, will prove only that the Android package compiles and packages successfully—not that gameplay works.
