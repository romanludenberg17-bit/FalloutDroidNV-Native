# FalloutDroidNV-Native

Clean-room Android native-port research project for Fallout: New Vegas. The current source tree is an early compatibility/runtime scaffold, **not a playable port**.

## Current scope

- Android app module targeting `arm64-v8a` (Android 10+), Kotlin/Jetpack Compose UI.
- C++17 native library target: `libfnv3.so`.
- x86 PE loading/runtime experiments using Unicorn Engine 2.1.4.
- Win32/COM compatibility layers, input abstraction, BSA reader, and Oboe-based audio components.
- Vulkan initialization work. The current renderer does not yet implement a D3D9 device, draw-call translation, swapchain presentation, or game rendering.
- Host-side C++ regression tests.

No Bethesda game assets or proprietary executable are included. Users must supply their own legally obtained game files.

## Build in GitHub Actions

The `Android Release APK` workflow runs host tests, fetches Unicorn Engine 2.1.4, configures JDK 17 / Gradle 8.9 / Android NDK r27, builds the arm64 release APK, signs it, and uploads diagnostics.

For repeatable update installs, configure repository Actions secrets:

- `RELEASE_KEYSTORE_B64`
- `RELEASE_STORE_PASS`
- `RELEASE_KEY_PASS`
- `RELEASE_KEY_ALIAS`

If these are not configured, CI creates an **ephemeral key**. That APK is suitable for first-install testing only; a later build will use a different signing key and cannot update it in place.

## Run host tests

```bash
make -C tests clean test
```

## Build locally

Open the project in Android Studio with Android SDK 35, NDK `27.2.12479018`, CMake `3.22.1`, and JDK 17 installed. The native build expects Unicorn Engine 2.1.4 at `third_party/unicorn`.

## What is still required before gameplay

1. Complete and validate Win32/COM coverage against the retail executable.
2. Implement Direct3D 9 COM interfaces and D3D9-to-Vulkan resource, shader, and draw-call translation.
3. Add a real swapchain/present loop and render the game's first frame.
4. Verify boot, controls, audio, save/load, and sustained gameplay on physical Android devices.

See [ARCHITECTURE_ROADMAP.md](ARCHITECTURE_ROADMAP.md) and [PROJECT_STATUS.md](PROJECT_STATUS.md).
