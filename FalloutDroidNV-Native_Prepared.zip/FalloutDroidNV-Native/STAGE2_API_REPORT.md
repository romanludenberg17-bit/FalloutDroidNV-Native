# Win32 / COM compatibility inventory (source-level)

This is an inventory of symbols and compatibility paths present in the current source tree. It is **not** proof of complete Win32 behavior or compatibility with the retail game. Many functions are partial stubs and must be validated against the executable and runtime traces.

## Current implementation areas

- `kernel32.dll`: timing, heap/virtual memory, TLS, synchronization, threads, file access, module/import stubs, and error state.
- `user32.dll`: selected keyboard/cursor/message helpers.
- `advapi32.dll`: selected registry operations.
- `ole32.dll` / `oleaut32.dll`: selected COM initialization and automation helpers.
- `shell32.dll`, `ws2_32.dll`, `winmm.dll`, `version.dll`, `shlwapi.dll`: selected compatibility helpers.
- `dinput8.dll`: partial DirectInput8 interfaces wired to the input engine.
- `dsound.dll`: partial DirectSound interfaces wired to the audio mixer.
- `xaudio2_7.dll`: partial XAudio2 source voice path wired to the audio mixer.

## Known major gaps

- `d3d9.dll`: no `Direct3DCreate9`, `IDirect3D9`, or `IDirect3DDevice9` implementation. No D3D9-to-Vulkan translation exists.
- `quartz.dll` / DirectShow: no complete graph interfaces or codec bridge.
- `binkw32.dll`: no Bink playback implementation.
- `steam_api.dll`: no verified Steam API compatibility layer.
- Full Win32 window procedure, GDI, wide-character API coverage, and complete registry/filesystem semantics are not implemented.

## Validation required

1. Inspect imports from a legally obtained retail `FalloutNV.exe` supplied by the user.
2. Compare every imported symbol against an explicit implemented/partial/missing matrix.
3. Exercise each API through the x86 runtime and capture return values, memory effects, and errors.
4. Track unsupported imports and runtime faults as tests; do not count symbol names alone as implemented coverage.
