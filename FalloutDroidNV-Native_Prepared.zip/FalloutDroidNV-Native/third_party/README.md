# Third-party dependencies

The Android build workflow fetches Unicorn Engine tag `2.1.4` into `third_party/unicorn` at build time. The dependency source is intentionally not vendored in this repository. Review the upstream license and dependency changes before updating the pinned tag.
